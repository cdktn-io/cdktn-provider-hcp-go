/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupIamPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The group's resource name in format `iam/organization/<organization_id>/group/<group_name>`. The shortened `<group_name>` version can be used for input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_iam_policy#name GroupIamPolicy#name}
    */
    readonly name: string;
    /**
    * The policy to apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_iam_policy#policy_data GroupIamPolicy#policy_data}
    */
    readonly policyData: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_iam_policy hcp_group_iam_policy}
*/
export declare class GroupIamPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_group_iam_policy";
    /**
    * Generates CDKTN code for importing a GroupIamPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupIamPolicy to import
    * @param importFromId The id of the existing GroupIamPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_iam_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupIamPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_iam_policy hcp_group_iam_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupIamPolicyConfig
    */
    constructor(scope: Construct, id: string, config: GroupIamPolicyConfig);
    get etag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyData?;
    get policyData(): string;
    set policyData(value: string);
    get policyDataInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
