/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsDynamicSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * Vault Secrets application name that owns the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#app_name VaultSecretsDynamicSecret#app_name}
    */
    readonly appName: string;
    /**
    * AWS configuration to generate dynamic credentials by assuming an IAM role. Required if `secret_provider` is `aws`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#aws_assume_role VaultSecretsDynamicSecret#aws_assume_role}
    */
    readonly awsAssumeRole?: VaultSecretsDynamicSecretAwsAssumeRole;
    /**
    * TTL the generated credentials will be valid for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#default_ttl VaultSecretsDynamicSecret#default_ttl}
    */
    readonly defaultTtl?: string;
    /**
    * GCP configuration to generate dynamic credentials by impersonating a service account. Required if `secret_provider` is `gcp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#gcp_impersonate_service_account VaultSecretsDynamicSecret#gcp_impersonate_service_account}
    */
    readonly gcpImpersonateServiceAccount?: VaultSecretsDynamicSecretGcpImpersonateServiceAccount;
    /**
    * The Vault Secrets integration name with the capability to manage the secret's lifecycle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#integration_name VaultSecretsDynamicSecret#integration_name}
    */
    readonly integrationName: string;
    /**
    * The Vault Secrets secret name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#name VaultSecretsDynamicSecret#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#project_id VaultSecretsDynamicSecret#project_id}
    */
    readonly projectId?: string;
    /**
    * The third party platform the dynamic credentials give access to. One of `aws` or `gcp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#secret_provider VaultSecretsDynamicSecret#secret_provider}
    */
    readonly secretProvider: string;
}
export interface VaultSecretsDynamicSecretAwsAssumeRole {
    /**
    * AWS IAM role ARN to assume when generating credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#iam_role_arn VaultSecretsDynamicSecret#iam_role_arn}
    */
    readonly iamRoleArn: string;
}
export declare function vaultSecretsDynamicSecretAwsAssumeRoleToTerraform(struct?: VaultSecretsDynamicSecretAwsAssumeRole | cdktn.IResolvable): any;
export declare function vaultSecretsDynamicSecretAwsAssumeRoleToHclTerraform(struct?: VaultSecretsDynamicSecretAwsAssumeRole | cdktn.IResolvable): any;
export declare class VaultSecretsDynamicSecretAwsAssumeRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsDynamicSecretAwsAssumeRole | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsDynamicSecretAwsAssumeRole | cdktn.IResolvable | undefined);
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
}
export interface VaultSecretsDynamicSecretGcpImpersonateServiceAccount {
    /**
    * GCP service account email to impersonate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#service_account_email VaultSecretsDynamicSecret#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function vaultSecretsDynamicSecretGcpImpersonateServiceAccountToTerraform(struct?: VaultSecretsDynamicSecretGcpImpersonateServiceAccount | cdktn.IResolvable): any;
export declare function vaultSecretsDynamicSecretGcpImpersonateServiceAccountToHclTerraform(struct?: VaultSecretsDynamicSecretGcpImpersonateServiceAccount | cdktn.IResolvable): any;
export declare class VaultSecretsDynamicSecretGcpImpersonateServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsDynamicSecretGcpImpersonateServiceAccount | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsDynamicSecretGcpImpersonateServiceAccount | cdktn.IResolvable | undefined);
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret hcp_vault_secrets_dynamic_secret}
*/
export declare class VaultSecretsDynamicSecret extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_dynamic_secret";
    /**
    * Generates CDKTN code for importing a VaultSecretsDynamicSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsDynamicSecret to import
    * @param importFromId The id of the existing VaultSecretsDynamicSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsDynamicSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_dynamic_secret hcp_vault_secrets_dynamic_secret} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsDynamicSecretConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsDynamicSecretConfig);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    private _awsAssumeRole;
    get awsAssumeRole(): VaultSecretsDynamicSecretAwsAssumeRoleOutputReference;
    putAwsAssumeRole(value: VaultSecretsDynamicSecretAwsAssumeRole): void;
    resetAwsAssumeRole(): void;
    get awsAssumeRoleInput(): cdktn.IResolvable | VaultSecretsDynamicSecretAwsAssumeRole | undefined;
    private _defaultTtl?;
    get defaultTtl(): string;
    set defaultTtl(value: string);
    resetDefaultTtl(): void;
    get defaultTtlInput(): string | undefined;
    private _gcpImpersonateServiceAccount;
    get gcpImpersonateServiceAccount(): VaultSecretsDynamicSecretGcpImpersonateServiceAccountOutputReference;
    putGcpImpersonateServiceAccount(value: VaultSecretsDynamicSecretGcpImpersonateServiceAccount): void;
    resetGcpImpersonateServiceAccount(): void;
    get gcpImpersonateServiceAccountInput(): cdktn.IResolvable | VaultSecretsDynamicSecretGcpImpersonateServiceAccount | undefined;
    private _integrationName?;
    get integrationName(): string;
    set integrationName(value: string);
    get integrationNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _secretProvider?;
    get secretProvider(): string;
    set secretProvider(value: string);
    get secretProviderInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
