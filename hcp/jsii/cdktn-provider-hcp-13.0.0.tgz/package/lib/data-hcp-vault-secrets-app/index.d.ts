/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpVaultSecretsAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Vault Secrets application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_secrets_app#app_name DataHcpVaultSecretsApp#app_name}
    */
    readonly appName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_secrets_app hcp_vault_secrets_app}
*/
export declare class DataHcpVaultSecretsApp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_vault_secrets_app";
    /**
    * Generates CDKTN code for importing a DataHcpVaultSecretsApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpVaultSecretsApp to import
    * @param importFromId The id of the existing DataHcpVaultSecretsApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_secrets_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpVaultSecretsApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_secrets_app hcp_vault_secrets_app} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpVaultSecretsAppConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpVaultSecretsAppConfig);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    get id(): string;
    get organizationId(): string;
    get projectId(): string;
    private _secrets;
    get secrets(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
