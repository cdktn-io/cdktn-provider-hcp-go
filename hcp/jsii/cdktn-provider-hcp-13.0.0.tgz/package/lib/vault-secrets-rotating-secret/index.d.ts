/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsRotatingSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * Vault Secrets application name that owns the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#app_name VaultSecretsRotatingSecret#app_name}
    */
    readonly appName: string;
    /**
    * AWS configuration to manage the access key rotation for the given IAM user. Required if `secret_provider` is `aws`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#aws_access_keys VaultSecretsRotatingSecret#aws_access_keys}
    */
    readonly awsAccessKeys?: VaultSecretsRotatingSecretAwsAccessKeys;
    /**
    * Azure configuration to manage the application password rotation for the given application. Required if `secret_provider` is `Azure`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#azure_application_password VaultSecretsRotatingSecret#azure_application_password}
    */
    readonly azureApplicationPassword?: VaultSecretsRotatingSecretAzureApplicationPassword;
    /**
    * Confluent configuration to manage the cloud api key rotation for the given service account. Required if `secret_provider` is `confluent`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#confluent_service_account VaultSecretsRotatingSecret#confluent_service_account}
    */
    readonly confluentServiceAccount?: VaultSecretsRotatingSecretConfluentServiceAccount;
    /**
    * GCP configuration to manage the service account key rotation for the given service account. Required if `secret_provider` is `gcp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#gcp_service_account_key VaultSecretsRotatingSecret#gcp_service_account_key}
    */
    readonly gcpServiceAccountKey?: VaultSecretsRotatingSecretGcpServiceAccountKey;
    /**
    * The Vault Secrets integration name with the capability to manage the secret's lifecycle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#integration_name VaultSecretsRotatingSecret#integration_name}
    */
    readonly integrationName: string;
    /**
    * MongoDB Atlas configuration to manage the user password rotation on the given database. Required if `secret_provider` is `mongodb_atlas`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#mongodb_atlas_user VaultSecretsRotatingSecret#mongodb_atlas_user}
    */
    readonly mongodbAtlasUser?: VaultSecretsRotatingSecretMongodbAtlasUser;
    /**
    * The Vault Secrets secret name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#name VaultSecretsRotatingSecret#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#project_id VaultSecretsRotatingSecret#project_id}
    */
    readonly projectId?: string;
    /**
    * Name of the rotation policy that governs the rotation of the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#rotation_policy_name VaultSecretsRotatingSecret#rotation_policy_name}
    */
    readonly rotationPolicyName: string;
    /**
    * The third party platform the dynamic credentials give access to. One of `aws` or `gcp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#secret_provider VaultSecretsRotatingSecret#secret_provider}
    */
    readonly secretProvider: string;
    /**
    * Twilio configuration to manage the api key rotation on the given account. Required if `secret_provider` is `twilio`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#twilio_api_key VaultSecretsRotatingSecret#twilio_api_key}
    */
    readonly twilioApiKey?: VaultSecretsRotatingSecretTwilioApiKey;
}
export interface VaultSecretsRotatingSecretAwsAccessKeys {
    /**
    * AWS IAM username to rotate the access keys for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#iam_username VaultSecretsRotatingSecret#iam_username}
    */
    readonly iamUsername: string;
}
export declare function vaultSecretsRotatingSecretAwsAccessKeysToTerraform(struct?: VaultSecretsRotatingSecretAwsAccessKeys | cdktn.IResolvable): any;
export declare function vaultSecretsRotatingSecretAwsAccessKeysToHclTerraform(struct?: VaultSecretsRotatingSecretAwsAccessKeys | cdktn.IResolvable): any;
export declare class VaultSecretsRotatingSecretAwsAccessKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsRotatingSecretAwsAccessKeys | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsRotatingSecretAwsAccessKeys | cdktn.IResolvable | undefined);
    private _iamUsername?;
    get iamUsername(): string;
    set iamUsername(value: string);
    get iamUsernameInput(): string | undefined;
}
export interface VaultSecretsRotatingSecretAzureApplicationPassword {
    /**
    * Application client ID to rotate the application password for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#app_client_id VaultSecretsRotatingSecret#app_client_id}
    */
    readonly appClientId: string;
    /**
    * Application object ID to rotate the application password for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#app_object_id VaultSecretsRotatingSecret#app_object_id}
    */
    readonly appObjectId: string;
}
export declare function vaultSecretsRotatingSecretAzureApplicationPasswordToTerraform(struct?: VaultSecretsRotatingSecretAzureApplicationPassword | cdktn.IResolvable): any;
export declare function vaultSecretsRotatingSecretAzureApplicationPasswordToHclTerraform(struct?: VaultSecretsRotatingSecretAzureApplicationPassword | cdktn.IResolvable): any;
export declare class VaultSecretsRotatingSecretAzureApplicationPasswordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsRotatingSecretAzureApplicationPassword | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsRotatingSecretAzureApplicationPassword | cdktn.IResolvable | undefined);
    private _appClientId?;
    get appClientId(): string;
    set appClientId(value: string);
    get appClientIdInput(): string | undefined;
    private _appObjectId?;
    get appObjectId(): string;
    set appObjectId(value: string);
    get appObjectIdInput(): string | undefined;
}
export interface VaultSecretsRotatingSecretConfluentServiceAccount {
    /**
    * Confluent service account to rotate the cloud api key for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#service_account_id VaultSecretsRotatingSecret#service_account_id}
    */
    readonly serviceAccountId: string;
}
export declare function vaultSecretsRotatingSecretConfluentServiceAccountToTerraform(struct?: VaultSecretsRotatingSecretConfluentServiceAccount | cdktn.IResolvable): any;
export declare function vaultSecretsRotatingSecretConfluentServiceAccountToHclTerraform(struct?: VaultSecretsRotatingSecretConfluentServiceAccount | cdktn.IResolvable): any;
export declare class VaultSecretsRotatingSecretConfluentServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsRotatingSecretConfluentServiceAccount | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsRotatingSecretConfluentServiceAccount | cdktn.IResolvable | undefined);
    private _serviceAccountId?;
    get serviceAccountId(): string;
    set serviceAccountId(value: string);
    get serviceAccountIdInput(): string | undefined;
}
export interface VaultSecretsRotatingSecretGcpServiceAccountKey {
    /**
    * GCP service account email to impersonate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#service_account_email VaultSecretsRotatingSecret#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function vaultSecretsRotatingSecretGcpServiceAccountKeyToTerraform(struct?: VaultSecretsRotatingSecretGcpServiceAccountKey | cdktn.IResolvable): any;
export declare function vaultSecretsRotatingSecretGcpServiceAccountKeyToHclTerraform(struct?: VaultSecretsRotatingSecretGcpServiceAccountKey | cdktn.IResolvable): any;
export declare class VaultSecretsRotatingSecretGcpServiceAccountKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsRotatingSecretGcpServiceAccountKey | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsRotatingSecretGcpServiceAccountKey | cdktn.IResolvable | undefined);
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
export interface VaultSecretsRotatingSecretMongodbAtlasUser {
    /**
    * MongoDB Atlas database or cluster name to rotate the username and password for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#database_name VaultSecretsRotatingSecret#database_name}
    */
    readonly databaseName: string;
    /**
    * MongoDB Atlas project ID to rotate the username and password for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#project_id VaultSecretsRotatingSecret#project_id}
    */
    readonly projectId: string;
    /**
    * MongoDB Atlas roles to assign to the rotating user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#roles VaultSecretsRotatingSecret#roles}
    */
    readonly roles: string[];
}
export declare function vaultSecretsRotatingSecretMongodbAtlasUserToTerraform(struct?: VaultSecretsRotatingSecretMongodbAtlasUser | cdktn.IResolvable): any;
export declare function vaultSecretsRotatingSecretMongodbAtlasUserToHclTerraform(struct?: VaultSecretsRotatingSecretMongodbAtlasUser | cdktn.IResolvable): any;
export declare class VaultSecretsRotatingSecretMongodbAtlasUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsRotatingSecretMongodbAtlasUser | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsRotatingSecretMongodbAtlasUser | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    get rolesInput(): string[] | undefined;
}
export interface VaultSecretsRotatingSecretTwilioApiKey {
}
export declare function vaultSecretsRotatingSecretTwilioApiKeyToTerraform(struct?: VaultSecretsRotatingSecretTwilioApiKey | cdktn.IResolvable): any;
export declare function vaultSecretsRotatingSecretTwilioApiKeyToHclTerraform(struct?: VaultSecretsRotatingSecretTwilioApiKey | cdktn.IResolvable): any;
export declare class VaultSecretsRotatingSecretTwilioApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsRotatingSecretTwilioApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsRotatingSecretTwilioApiKey | cdktn.IResolvable | undefined);
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret hcp_vault_secrets_rotating_secret}
*/
export declare class VaultSecretsRotatingSecret extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_rotating_secret";
    /**
    * Generates CDKTN code for importing a VaultSecretsRotatingSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsRotatingSecret to import
    * @param importFromId The id of the existing VaultSecretsRotatingSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsRotatingSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_rotating_secret hcp_vault_secrets_rotating_secret} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsRotatingSecretConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsRotatingSecretConfig);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    private _awsAccessKeys;
    get awsAccessKeys(): VaultSecretsRotatingSecretAwsAccessKeysOutputReference;
    putAwsAccessKeys(value: VaultSecretsRotatingSecretAwsAccessKeys): void;
    resetAwsAccessKeys(): void;
    get awsAccessKeysInput(): cdktn.IResolvable | VaultSecretsRotatingSecretAwsAccessKeys | undefined;
    private _azureApplicationPassword;
    get azureApplicationPassword(): VaultSecretsRotatingSecretAzureApplicationPasswordOutputReference;
    putAzureApplicationPassword(value: VaultSecretsRotatingSecretAzureApplicationPassword): void;
    resetAzureApplicationPassword(): void;
    get azureApplicationPasswordInput(): cdktn.IResolvable | VaultSecretsRotatingSecretAzureApplicationPassword | undefined;
    private _confluentServiceAccount;
    get confluentServiceAccount(): VaultSecretsRotatingSecretConfluentServiceAccountOutputReference;
    putConfluentServiceAccount(value: VaultSecretsRotatingSecretConfluentServiceAccount): void;
    resetConfluentServiceAccount(): void;
    get confluentServiceAccountInput(): cdktn.IResolvable | VaultSecretsRotatingSecretConfluentServiceAccount | undefined;
    private _gcpServiceAccountKey;
    get gcpServiceAccountKey(): VaultSecretsRotatingSecretGcpServiceAccountKeyOutputReference;
    putGcpServiceAccountKey(value: VaultSecretsRotatingSecretGcpServiceAccountKey): void;
    resetGcpServiceAccountKey(): void;
    get gcpServiceAccountKeyInput(): cdktn.IResolvable | VaultSecretsRotatingSecretGcpServiceAccountKey | undefined;
    private _integrationName?;
    get integrationName(): string;
    set integrationName(value: string);
    get integrationNameInput(): string | undefined;
    private _mongodbAtlasUser;
    get mongodbAtlasUser(): VaultSecretsRotatingSecretMongodbAtlasUserOutputReference;
    putMongodbAtlasUser(value: VaultSecretsRotatingSecretMongodbAtlasUser): void;
    resetMongodbAtlasUser(): void;
    get mongodbAtlasUserInput(): cdktn.IResolvable | VaultSecretsRotatingSecretMongodbAtlasUser | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _rotationPolicyName?;
    get rotationPolicyName(): string;
    set rotationPolicyName(value: string);
    get rotationPolicyNameInput(): string | undefined;
    private _secretProvider?;
    get secretProvider(): string;
    set secretProvider(value: string);
    get secretProviderInput(): string | undefined;
    private _twilioApiKey;
    get twilioApiKey(): VaultSecretsRotatingSecretTwilioApiKeyOutputReference;
    putTwilioApiKey(value: VaultSecretsRotatingSecretTwilioApiKey): void;
    resetTwilioApiKey(): void;
    get twilioApiKeyInput(): cdktn.IResolvable | VaultSecretsRotatingSecretTwilioApiKey | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
