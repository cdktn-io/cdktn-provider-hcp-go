/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsForwardingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the DNS forwarding configuration this rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#dns_forwarding_id DnsForwardingRule#dns_forwarding_id}
    */
    readonly dnsForwardingId: string;
    /**
    * The domain name for which DNS forwarding rule needs to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#domain_name DnsForwardingRule#domain_name}
    */
    readonly domainName: string;
    /**
    * The ID of the HVN that this DNS forwarding rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#hvn_id DnsForwardingRule#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#id DnsForwardingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The IP addresses of the target customer network inbound endpoints to which the DNS requests for the above domain will be forwarded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#inbound_endpoint_ips DnsForwardingRule#inbound_endpoint_ips}
    */
    readonly inboundEndpointIps: string[];
    /**
    *
    * The ID of the HCP project where the DNS forwarding rule is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#project_id DnsForwardingRule#project_id}
    */
    readonly projectId?: string;
    /**
    * The ID of the DNS forwarding rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#rule_id DnsForwardingRule#rule_id}
    */
    readonly ruleId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#timeouts DnsForwardingRule#timeouts}
    */
    readonly timeouts?: DnsForwardingRuleTimeouts;
}
export interface DnsForwardingRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#create DnsForwardingRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#default DnsForwardingRule#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#delete DnsForwardingRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#read DnsForwardingRule#read}
    */
    readonly read?: string;
}
export declare function dnsForwardingRuleTimeoutsToTerraform(struct?: DnsForwardingRuleTimeouts | cdktn.IResolvable): any;
export declare function dnsForwardingRuleTimeoutsToHclTerraform(struct?: DnsForwardingRuleTimeouts | cdktn.IResolvable): any;
export declare class DnsForwardingRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DnsForwardingRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DnsForwardingRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule hcp_dns_forwarding_rule}
*/
export declare class DnsForwardingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_dns_forwarding_rule";
    /**
    * Generates CDKTN code for importing a DnsForwardingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsForwardingRule to import
    * @param importFromId The id of the existing DnsForwardingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsForwardingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/dns_forwarding_rule hcp_dns_forwarding_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsForwardingRuleConfig
    */
    constructor(scope: Construct, id: string, config: DnsForwardingRuleConfig);
    get createdAt(): string;
    private _dnsForwardingId?;
    get dnsForwardingId(): string;
    set dnsForwardingId(value: string);
    get dnsForwardingIdInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inboundEndpointIps?;
    get inboundEndpointIps(): string[];
    set inboundEndpointIps(value: string[]);
    get inboundEndpointIpsInput(): string[] | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    private _timeouts;
    get timeouts(): DnsForwardingRuleTimeoutsOutputReference;
    putTimeouts(value: DnsForwardingRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DnsForwardingRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
