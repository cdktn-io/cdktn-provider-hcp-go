/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConsulClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Enables automatic HVN to HVN peering when creating a secondary cluster in a federation. The alternative to using the auto-accept feature is to create an [`hcp_hvn_peering_connection`](hvn_peering_connection.md) resource that explicitly defines the HVN resources that are allowed to communicate with each other.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#auto_hvn_to_hvn_peering ConsulCluster#auto_hvn_to_hvn_peering}
    */
    readonly autoHvnToHvnPeering?: boolean | cdktn.IResolvable;
    /**
    * The ID of the HCP Consul cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#cluster_id ConsulCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Denotes the Consul connect feature should be enabled for this cluster.  Default to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#connect_enabled ConsulCluster#connect_enabled}
    */
    readonly connectEnabled?: boolean | cdktn.IResolvable;
    /**
    * The Consul data center name of the cluster. If not specified, it is defaulted to the value of `cluster_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#datacenter ConsulCluster#datacenter}
    */
    readonly datacenter?: string;
    /**
    * The ID of the HVN this HCP Consul cluster is associated to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#hvn_id ConsulCluster#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#id ConsulCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The minimum Consul patch version of the cluster. Allows only the rightmost version component to increment (E.g: `1.13.0` will allow installation of `1.13.2` and `1.13.3` etc., but not `1.14.0`). If not specified, it is defaulted to the version that is currently recommended by HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#min_consul_version ConsulCluster#min_consul_version}
    */
    readonly minConsulVersion?: string;
    /**
    * The `self_link` of the HCP Consul cluster which is the primary in the federation setup with this HCP Consul cluster. If not specified, it is a standalone cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#primary_link ConsulCluster#primary_link}
    */
    readonly primaryLink?: string;
    /**
    *
    * The ID of the HCP project where the HCP Consul cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#project_id ConsulCluster#project_id}
    */
    readonly projectId?: string;
    /**
    * Denotes that the cluster has a public endpoint for the Consul UI. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#public_endpoint ConsulCluster#public_endpoint}
    */
    readonly publicEndpoint?: boolean | cdktn.IResolvable;
    /**
    * The t-shirt size representation of each server VM that this Consul cluster is provisioned with. Valid option for development tier - `x_small`. Valid options for other tiers - `small`, `medium`, `large`. For more details - https://cloud.hashicorp.com/pricing/consul. Upgrading the size of a cluster after creation is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#size ConsulCluster#size}
    */
    readonly size?: string;
    /**
    * The tier that the HCP Consul cluster will be provisioned as.  Only `development`, `standard`, `plus`, and `premium` are available at this time. See [pricing information](https://www.hashicorp.com/products/consul/pricing).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#tier ConsulCluster#tier}
    */
    readonly tier: string;
    /**
    * ip_allowlist block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#ip_allowlist ConsulCluster#ip_allowlist}
    */
    readonly ipAllowlist?: ConsulClusterIpAllowlistStruct[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#timeouts ConsulCluster#timeouts}
    */
    readonly timeouts?: ConsulClusterTimeouts;
}
export interface ConsulClusterIpAllowlistStruct {
    /**
    * IP address range in CIDR notation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#address ConsulCluster#address}
    */
    readonly address: string;
    /**
    * Description to help identify source (maximum 255 chars).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#description ConsulCluster#description}
    */
    readonly description?: string;
}
export declare function consulClusterIpAllowlistStructToTerraform(struct?: ConsulClusterIpAllowlistStruct | cdktn.IResolvable): any;
export declare function consulClusterIpAllowlistStructToHclTerraform(struct?: ConsulClusterIpAllowlistStruct | cdktn.IResolvable): any;
export declare class ConsulClusterIpAllowlistStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConsulClusterIpAllowlistStruct | cdktn.IResolvable | undefined;
    set internalValue(value: ConsulClusterIpAllowlistStruct | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
}
export declare class ConsulClusterIpAllowlistStructList extends cdktn.ComplexList {
    internalValue?: ConsulClusterIpAllowlistStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConsulClusterIpAllowlistStructOutputReference;
}
export interface ConsulClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#create ConsulCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#default ConsulCluster#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#delete ConsulCluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#update ConsulCluster#update}
    */
    readonly update?: string;
}
export declare function consulClusterTimeoutsToTerraform(struct?: ConsulClusterTimeouts | cdktn.IResolvable): any;
export declare function consulClusterTimeoutsToHclTerraform(struct?: ConsulClusterTimeouts | cdktn.IResolvable): any;
export declare class ConsulClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConsulClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ConsulClusterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster hcp_consul_cluster}
*/
export declare class ConsulCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_consul_cluster";
    /**
    * Generates CDKTN code for importing a ConsulCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConsulCluster to import
    * @param importFromId The id of the existing ConsulCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConsulCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/consul_cluster hcp_consul_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConsulClusterConfig
    */
    constructor(scope: Construct, id: string, config: ConsulClusterConfig);
    private _autoHvnToHvnPeering?;
    get autoHvnToHvnPeering(): boolean | cdktn.IResolvable;
    set autoHvnToHvnPeering(value: boolean | cdktn.IResolvable);
    resetAutoHvnToHvnPeering(): void;
    get autoHvnToHvnPeeringInput(): boolean | cdktn.IResolvable | undefined;
    get cloudProvider(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _connectEnabled?;
    get connectEnabled(): boolean | cdktn.IResolvable;
    set connectEnabled(value: boolean | cdktn.IResolvable);
    resetConnectEnabled(): void;
    get connectEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get consulAutomaticUpgrades(): cdktn.IResolvable;
    get consulCaFile(): string;
    get consulConfigFile(): string;
    get consulPrivateEndpointUrl(): string;
    get consulPublicEndpointUrl(): string;
    get consulRootTokenAccessorId(): string;
    get consulRootTokenSecretId(): string;
    get consulSnapshotInterval(): string;
    get consulSnapshotRetention(): string;
    get consulVersion(): string;
    private _datacenter?;
    get datacenter(): string;
    set datacenter(value: string);
    resetDatacenter(): void;
    get datacenterInput(): string | undefined;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _minConsulVersion?;
    get minConsulVersion(): string;
    set minConsulVersion(value: string);
    resetMinConsulVersion(): void;
    get minConsulVersionInput(): string | undefined;
    get organizationId(): string;
    private _primaryLink?;
    get primaryLink(): string;
    set primaryLink(value: string);
    resetPrimaryLink(): void;
    get primaryLinkInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _publicEndpoint?;
    get publicEndpoint(): boolean | cdktn.IResolvable;
    set publicEndpoint(value: boolean | cdktn.IResolvable);
    resetPublicEndpoint(): void;
    get publicEndpointInput(): boolean | cdktn.IResolvable | undefined;
    get region(): string;
    get scale(): number;
    get selfLink(): string;
    private _size?;
    get size(): string;
    set size(value: string);
    resetSize(): void;
    get sizeInput(): string | undefined;
    get state(): string;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    get tierInput(): string | undefined;
    private _ipAllowlist;
    get ipAllowlist(): ConsulClusterIpAllowlistStructList;
    putIpAllowlist(value: ConsulClusterIpAllowlistStruct[] | cdktn.IResolvable): void;
    resetIpAllowlist(): void;
    get ipAllowlistInput(): cdktn.IResolvable | ConsulClusterIpAllowlistStruct[] | undefined;
    private _timeouts;
    get timeouts(): ConsulClusterTimeoutsOutputReference;
    putTimeouts(value: ConsulClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ConsulClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
