/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsIntegrationTwilioConfig extends cdktn.TerraformMetaArguments {
    /**
    * Capabilities enabled for the integration. See the Vault Secrets documentation for the list of supported capabilities per provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#capabilities VaultSecretsIntegrationTwilio#capabilities}
    */
    readonly capabilities: string[];
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#name VaultSecretsIntegrationTwilio#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#project_id VaultSecretsIntegrationTwilio#project_id}
    */
    readonly projectId?: string;
    /**
    * Twilio API key parts used to authenticate against the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#static_credential_details VaultSecretsIntegrationTwilio#static_credential_details}
    */
    readonly staticCredentialDetails?: VaultSecretsIntegrationTwilioStaticCredentialDetails;
}
export interface VaultSecretsIntegrationTwilioStaticCredentialDetails {
    /**
    * Account SID for the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#account_sid VaultSecretsIntegrationTwilio#account_sid}
    */
    readonly accountSid: string;
    /**
    * Api key secret used with the api key SID to authenticate against the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#api_key_secret VaultSecretsIntegrationTwilio#api_key_secret}
    */
    readonly apiKeySecret: string;
    /**
    * Api key SID to authenticate against the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#api_key_sid VaultSecretsIntegrationTwilio#api_key_sid}
    */
    readonly apiKeySid: string;
}
export declare function vaultSecretsIntegrationTwilioStaticCredentialDetailsToTerraform(struct?: VaultSecretsIntegrationTwilioStaticCredentialDetails | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationTwilioStaticCredentialDetailsToHclTerraform(struct?: VaultSecretsIntegrationTwilioStaticCredentialDetails | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationTwilioStaticCredentialDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationTwilioStaticCredentialDetails | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationTwilioStaticCredentialDetails | cdktn.IResolvable | undefined);
    private _accountSid?;
    get accountSid(): string;
    set accountSid(value: string);
    get accountSidInput(): string | undefined;
    private _apiKeySecret?;
    get apiKeySecret(): string;
    set apiKeySecret(value: string);
    get apiKeySecretInput(): string | undefined;
    private _apiKeySid?;
    get apiKeySid(): string;
    set apiKeySid(value: string);
    get apiKeySidInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio hcp_vault_secrets_integration_twilio}
*/
export declare class VaultSecretsIntegrationTwilio extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_integration_twilio";
    /**
    * Generates CDKTN code for importing a VaultSecretsIntegrationTwilio resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsIntegrationTwilio to import
    * @param importFromId The id of the existing VaultSecretsIntegrationTwilio that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsIntegrationTwilio to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/vault_secrets_integration_twilio hcp_vault_secrets_integration_twilio} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsIntegrationTwilioConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsIntegrationTwilioConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    private _staticCredentialDetails;
    get staticCredentialDetails(): VaultSecretsIntegrationTwilioStaticCredentialDetailsOutputReference;
    putStaticCredentialDetails(value: VaultSecretsIntegrationTwilioStaticCredentialDetails): void;
    resetStaticCredentialDetails(): void;
    get staticCredentialDetailsInput(): cdktn.IResolvable | VaultSecretsIntegrationTwilioStaticCredentialDetails | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
