/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaypointAddOnDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * A longer description of the Add-on Definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#description WaypointAddOnDefinition#description}
    */
    readonly description: string;
    /**
    * List of labels attached to this Add-on Definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#labels WaypointAddOnDefinition#labels}
    */
    readonly labels?: string[];
    /**
    * The name of the Add-on Definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#name WaypointAddOnDefinition#name}
    */
    readonly name: string;
    /**
    * The ID of the HCP project where the Waypoint Add-on Definition is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#project_id WaypointAddOnDefinition#project_id}
    */
    readonly projectId?: string;
    /**
    * The markdown template for the Add-on Definition README (markdown format supported).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#readme_markdown_template WaypointAddOnDefinition#readme_markdown_template}
    */
    readonly readmeMarkdownTemplate?: string;
    /**
    * A short summary of the Add-on Definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#summary WaypointAddOnDefinition#summary}
    */
    readonly summary: string;
    /**
    * The ID of the Terraform agent pool to use for running Terraform operations. This is only applicable when the execution mode is set to 'agent'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#terraform_agent_pool_id WaypointAddOnDefinition#terraform_agent_pool_id}
    */
    readonly terraformAgentPoolId?: string;
    /**
    * Terraform Cloud Workspace details. If not provided, defaults to the HCP Terraform project of the associated application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#terraform_cloud_workspace_details WaypointAddOnDefinition#terraform_cloud_workspace_details}
    */
    readonly terraformCloudWorkspaceDetails?: WaypointAddOnDefinitionTerraformCloudWorkspaceDetails;
    /**
    * The execution mode of the HCP Terraform workspaces for add-ons using this add-on definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#terraform_execution_mode WaypointAddOnDefinition#terraform_execution_mode}
    */
    readonly terraformExecutionMode?: string;
    /**
    * The ID of the Terraform no-code module to use for running Terraform operations. This is in the format of 'nocode-<ID>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#terraform_no_code_module_id WaypointAddOnDefinition#terraform_no_code_module_id}
    */
    readonly terraformNoCodeModuleId: string;
    /**
    * Terraform Cloud no-code Module Source, expected to be in one of the following formats: "app.terraform.io/hcp_waypoint_example/ecs-advanced-microservice/aws" or "private/hcp_waypoint_example/ecs-advanced-microservice/aws".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#terraform_no_code_module_source WaypointAddOnDefinition#terraform_no_code_module_source}
    */
    readonly terraformNoCodeModuleSource: string;
    /**
    * The ID of the Terraform Cloud Project to create workspaces in. The ID is found on the Terraform Cloud Project settings page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#terraform_project_id WaypointAddOnDefinition#terraform_project_id}
    */
    readonly terraformProjectId: string;
    /**
    * List of variable options for the Add-on Definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#variable_options WaypointAddOnDefinition#variable_options}
    */
    readonly variableOptions?: WaypointAddOnDefinitionVariableOptions[] | cdktn.IResolvable;
}
export interface WaypointAddOnDefinitionTerraformCloudWorkspaceDetails {
    /**
    * Name of the Terraform Cloud Project
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#name WaypointAddOnDefinition#name}
    */
    readonly name: string;
    /**
    * Terraform Cloud Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#terraform_project_id WaypointAddOnDefinition#terraform_project_id}
    */
    readonly terraformProjectId: string;
}
export declare function waypointAddOnDefinitionTerraformCloudWorkspaceDetailsToTerraform(struct?: WaypointAddOnDefinitionTerraformCloudWorkspaceDetails | cdktn.IResolvable): any;
export declare function waypointAddOnDefinitionTerraformCloudWorkspaceDetailsToHclTerraform(struct?: WaypointAddOnDefinitionTerraformCloudWorkspaceDetails | cdktn.IResolvable): any;
export declare class WaypointAddOnDefinitionTerraformCloudWorkspaceDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WaypointAddOnDefinitionTerraformCloudWorkspaceDetails | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointAddOnDefinitionTerraformCloudWorkspaceDetails | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _terraformProjectId?;
    get terraformProjectId(): string;
    set terraformProjectId(value: string);
    get terraformProjectIdInput(): string | undefined;
}
export interface WaypointAddOnDefinitionVariableOptions {
    /**
    * Variable name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#name WaypointAddOnDefinition#name}
    */
    readonly name: string;
    /**
    * List of options
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#options WaypointAddOnDefinition#options}
    */
    readonly options?: string[];
    /**
    * Whether the variable is editable by the user creating an add-on. If options are provided, then the user may only use those options, regardless of this setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#user_editable WaypointAddOnDefinition#user_editable}
    */
    readonly userEditable?: boolean | cdktn.IResolvable;
    /**
    * Variable type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#variable_type WaypointAddOnDefinition#variable_type}
    */
    readonly variableType: string;
}
export declare function waypointAddOnDefinitionVariableOptionsToTerraform(struct?: WaypointAddOnDefinitionVariableOptions | cdktn.IResolvable): any;
export declare function waypointAddOnDefinitionVariableOptionsToHclTerraform(struct?: WaypointAddOnDefinitionVariableOptions | cdktn.IResolvable): any;
export declare class WaypointAddOnDefinitionVariableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointAddOnDefinitionVariableOptions | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointAddOnDefinitionVariableOptions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options?;
    get options(): string[];
    set options(value: string[]);
    resetOptions(): void;
    get optionsInput(): string[] | undefined;
    private _userEditable?;
    get userEditable(): boolean | cdktn.IResolvable;
    set userEditable(value: boolean | cdktn.IResolvable);
    resetUserEditable(): void;
    get userEditableInput(): boolean | cdktn.IResolvable | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    get variableTypeInput(): string | undefined;
}
export declare class WaypointAddOnDefinitionVariableOptionsList extends cdktn.ComplexList {
    internalValue?: WaypointAddOnDefinitionVariableOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointAddOnDefinitionVariableOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition hcp_waypoint_add_on_definition}
*/
export declare class WaypointAddOnDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_waypoint_add_on_definition";
    /**
    * Generates CDKTN code for importing a WaypointAddOnDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaypointAddOnDefinition to import
    * @param importFromId The id of the existing WaypointAddOnDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaypointAddOnDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_add_on_definition hcp_waypoint_add_on_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaypointAddOnDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: WaypointAddOnDefinitionConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _readmeMarkdownTemplate?;
    get readmeMarkdownTemplate(): string;
    set readmeMarkdownTemplate(value: string);
    resetReadmeMarkdownTemplate(): void;
    get readmeMarkdownTemplateInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    get summaryInput(): string | undefined;
    private _terraformAgentPoolId?;
    get terraformAgentPoolId(): string;
    set terraformAgentPoolId(value: string);
    resetTerraformAgentPoolId(): void;
    get terraformAgentPoolIdInput(): string | undefined;
    private _terraformCloudWorkspaceDetails;
    get terraformCloudWorkspaceDetails(): WaypointAddOnDefinitionTerraformCloudWorkspaceDetailsOutputReference;
    putTerraformCloudWorkspaceDetails(value: WaypointAddOnDefinitionTerraformCloudWorkspaceDetails): void;
    resetTerraformCloudWorkspaceDetails(): void;
    get terraformCloudWorkspaceDetailsInput(): cdktn.IResolvable | WaypointAddOnDefinitionTerraformCloudWorkspaceDetails | undefined;
    private _terraformExecutionMode?;
    get terraformExecutionMode(): string;
    set terraformExecutionMode(value: string);
    resetTerraformExecutionMode(): void;
    get terraformExecutionModeInput(): string | undefined;
    private _terraformNoCodeModuleId?;
    get terraformNoCodeModuleId(): string;
    set terraformNoCodeModuleId(value: string);
    get terraformNoCodeModuleIdInput(): string | undefined;
    private _terraformNoCodeModuleSource?;
    get terraformNoCodeModuleSource(): string;
    set terraformNoCodeModuleSource(value: string);
    get terraformNoCodeModuleSourceInput(): string | undefined;
    private _terraformProjectId?;
    get terraformProjectId(): string;
    set terraformProjectId(value: string);
    get terraformProjectIdInput(): string | undefined;
    private _variableOptions;
    get variableOptions(): WaypointAddOnDefinitionVariableOptionsList;
    putVariableOptions(value: WaypointAddOnDefinitionVariableOptions[] | cdktn.IResolvable): void;
    resetVariableOptions(): void;
    get variableOptionsInput(): cdktn.IResolvable | WaypointAddOnDefinitionVariableOptions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
