/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpVaultPluginConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Vault cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#cluster_id DataHcpVaultPlugin#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#id DataHcpVaultPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the plugin - Valid options for plugin name - 'venafi-pki-backend'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#plugin_name DataHcpVaultPlugin#plugin_name}
    */
    readonly pluginName: string;
    /**
    * The type of the plugin - Valid options for plugin type - 'SECRET', 'AUTH', 'DATABASE'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#plugin_type DataHcpVaultPlugin#plugin_type}
    */
    readonly pluginType: string;
    /**
    *
    * The ID of the HCP project where the HCP Vault cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#project_id DataHcpVaultPlugin#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#timeouts DataHcpVaultPlugin#timeouts}
    */
    readonly timeouts?: DataHcpVaultPluginTimeouts;
}
export interface DataHcpVaultPluginTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#default DataHcpVaultPlugin#default}
    */
    readonly default?: string;
}
export declare function dataHcpVaultPluginTimeoutsToTerraform(struct?: DataHcpVaultPluginTimeouts | cdktn.IResolvable): any;
export declare function dataHcpVaultPluginTimeoutsToHclTerraform(struct?: DataHcpVaultPluginTimeouts | cdktn.IResolvable): any;
export declare class DataHcpVaultPluginTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpVaultPluginTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpVaultPluginTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin hcp_vault_plugin}
*/
export declare class DataHcpVaultPlugin extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_vault_plugin";
    /**
    * Generates CDKTN code for importing a DataHcpVaultPlugin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpVaultPlugin to import
    * @param importFromId The id of the existing DataHcpVaultPlugin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpVaultPlugin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_plugin hcp_vault_plugin} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpVaultPluginConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpVaultPluginConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    get pluginNameInput(): string | undefined;
    private _pluginType?;
    get pluginType(): string;
    set pluginType(value: string);
    get pluginTypeInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataHcpVaultPluginTimeoutsOutputReference;
    putTimeouts(value: DataHcpVaultPluginTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpVaultPluginTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
