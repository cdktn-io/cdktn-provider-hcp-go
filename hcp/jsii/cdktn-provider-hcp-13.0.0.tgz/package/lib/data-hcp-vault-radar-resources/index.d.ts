/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpVaultRadarResourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP project where Vault Radar is located. If not specified, the project specified in the HCP Provider config block will be used, if configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_radar_resources#project_id DataHcpVaultRadarResources#project_id}
    */
    readonly projectId?: string;
    /**
    * Applies a filter to the radar resources based on their URIs. The filter uses the SQL LIKE operator, which allows for wildcard matching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_radar_resources#uri_like_filter DataHcpVaultRadarResources#uri_like_filter}
    */
    readonly uriLikeFilter: DataHcpVaultRadarResourcesUriLikeFilter;
}
export interface DataHcpVaultRadarResourcesResources {
}
export declare function dataHcpVaultRadarResourcesResourcesToTerraform(struct?: DataHcpVaultRadarResourcesResources): any;
export declare function dataHcpVaultRadarResourcesResourcesToHclTerraform(struct?: DataHcpVaultRadarResourcesResources): any;
export declare class DataHcpVaultRadarResourcesResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpVaultRadarResourcesResources | undefined;
    set internalValue(value: DataHcpVaultRadarResourcesResources | undefined);
    get connectionUrl(): string;
    get dataSourceName(): string;
    get dataSourceType(): string;
    get description(): string;
    get detectorType(): string;
    get hcpResourceName(): string;
    get hcpResourceStatus(): string;
    get id(): string;
    get name(): string;
    get state(): string;
    get uri(): string;
    get visibility(): string;
}
export declare class DataHcpVaultRadarResourcesResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpVaultRadarResourcesResourcesOutputReference;
}
export interface DataHcpVaultRadarResourcesUriLikeFilter {
    /**
    * If true, the uri like filter will be case insensitive. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_radar_resources#case_insensitive DataHcpVaultRadarResources#case_insensitive}
    */
    readonly caseInsensitive?: boolean | cdktn.IResolvable;
    /**
    * URI like filters to apply radar resources. Each entry in the list will act like an or condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_radar_resources#values DataHcpVaultRadarResources#values}
    */
    readonly values: string[];
}
export declare function dataHcpVaultRadarResourcesUriLikeFilterToTerraform(struct?: DataHcpVaultRadarResourcesUriLikeFilter | cdktn.IResolvable): any;
export declare function dataHcpVaultRadarResourcesUriLikeFilterToHclTerraform(struct?: DataHcpVaultRadarResourcesUriLikeFilter | cdktn.IResolvable): any;
export declare class DataHcpVaultRadarResourcesUriLikeFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpVaultRadarResourcesUriLikeFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpVaultRadarResourcesUriLikeFilter | cdktn.IResolvable | undefined);
    private _caseInsensitive?;
    get caseInsensitive(): boolean | cdktn.IResolvable;
    set caseInsensitive(value: boolean | cdktn.IResolvable);
    resetCaseInsensitive(): void;
    get caseInsensitiveInput(): boolean | cdktn.IResolvable | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_radar_resources hcp_vault_radar_resources}
*/
export declare class DataHcpVaultRadarResources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_vault_radar_resources";
    /**
    * Generates CDKTN code for importing a DataHcpVaultRadarResources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpVaultRadarResources to import
    * @param importFromId The id of the existing DataHcpVaultRadarResources that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_radar_resources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpVaultRadarResources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/vault_radar_resources hcp_vault_radar_resources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpVaultRadarResourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpVaultRadarResourcesConfig);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _resources;
    get resources(): DataHcpVaultRadarResourcesResourcesList;
    private _uriLikeFilter;
    get uriLikeFilter(): DataHcpVaultRadarResourcesUriLikeFilterOutputReference;
    putUriLikeFilter(value: DataHcpVaultRadarResourcesUriLikeFilter): void;
    get uriLikeFilterInput(): cdktn.IResolvable | DataHcpVaultRadarResourcesUriLikeFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
