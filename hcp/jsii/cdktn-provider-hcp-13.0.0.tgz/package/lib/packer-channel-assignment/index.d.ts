/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PackerChannelAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The slug of the HCP Packer bucket where the channel is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#bucket_name PackerChannelAssignment#bucket_name}
    */
    readonly bucketName: string;
    /**
    * The name of the HCP Packer channel being managed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#channel_name PackerChannelAssignment#channel_name}
    */
    readonly channelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#id PackerChannelAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the channel is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#project_id PackerChannelAssignment#project_id}
    */
    readonly projectId?: string;
    /**
    * The fingerprint of the version assigned to the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#version_fingerprint PackerChannelAssignment#version_fingerprint}
    */
    readonly versionFingerprint?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#timeouts PackerChannelAssignment#timeouts}
    */
    readonly timeouts?: PackerChannelAssignmentTimeouts;
}
export interface PackerChannelAssignmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#create PackerChannelAssignment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#default PackerChannelAssignment#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#delete PackerChannelAssignment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#update PackerChannelAssignment#update}
    */
    readonly update?: string;
}
export declare function packerChannelAssignmentTimeoutsToTerraform(struct?: PackerChannelAssignmentTimeouts | cdktn.IResolvable): any;
export declare function packerChannelAssignmentTimeoutsToHclTerraform(struct?: PackerChannelAssignmentTimeouts | cdktn.IResolvable): any;
export declare class PackerChannelAssignmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PackerChannelAssignmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PackerChannelAssignmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment hcp_packer_channel_assignment}
*/
export declare class PackerChannelAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_packer_channel_assignment";
    /**
    * Generates CDKTN code for importing a PackerChannelAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PackerChannelAssignment to import
    * @param importFromId The id of the existing PackerChannelAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PackerChannelAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_channel_assignment hcp_packer_channel_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PackerChannelAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: PackerChannelAssignmentConfig);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _channelName?;
    get channelName(): string;
    set channelName(value: string);
    get channelNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _versionFingerprint?;
    get versionFingerprint(): string;
    set versionFingerprint(value: string);
    resetVersionFingerprint(): void;
    get versionFingerprintInput(): string | undefined;
    private _timeouts;
    get timeouts(): PackerChannelAssignmentTimeoutsOutputReference;
    putTimeouts(value: PackerChannelAssignmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PackerChannelAssignmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
