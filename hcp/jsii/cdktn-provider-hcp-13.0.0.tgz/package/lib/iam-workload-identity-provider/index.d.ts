/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IamWorkloadIdentityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#aws IamWorkloadIdentityProvider#aws}
    */
    readonly aws?: IamWorkloadIdentityProviderAws;
    /**
    * conditional_access is a hashicorp/go-bexpr string that is evaluated when exchanging tokens. It restricts which upstream identities are allowed to access the service principal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#conditional_access IamWorkloadIdentityProvider#conditional_access}
    */
    readonly conditionalAccess: string;
    /**
    * A description for the workload identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#description IamWorkloadIdentityProvider#description}
    */
    readonly description?: string;
    /**
    * The workload identity provider's name. Ideally, this should be descriptive of the workload being federated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#name IamWorkloadIdentityProvider#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#oidc IamWorkloadIdentityProvider#oidc}
    */
    readonly oidc?: IamWorkloadIdentityProviderOidc;
    /**
    * The service principal's resource name for which the workload identity provider will be created for. Only service principals created within a project are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#service_principal IamWorkloadIdentityProvider#service_principal}
    */
    readonly servicePrincipal: string;
}
export interface IamWorkloadIdentityProviderAws {
    /**
    * The AWS Account ID that is allowed to exchange workload identities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#account_id IamWorkloadIdentityProvider#account_id}
    */
    readonly accountId: string;
}
export declare function iamWorkloadIdentityProviderAwsToTerraform(struct?: IamWorkloadIdentityProviderAws | cdktn.IResolvable): any;
export declare function iamWorkloadIdentityProviderAwsToHclTerraform(struct?: IamWorkloadIdentityProviderAws | cdktn.IResolvable): any;
export declare class IamWorkloadIdentityProviderAwsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IamWorkloadIdentityProviderAws | cdktn.IResolvable | undefined;
    set internalValue(value: IamWorkloadIdentityProviderAws | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
}
export interface IamWorkloadIdentityProviderOidc {
    /**
    * allowed_audiences is the set of audiences set on the access token that are allowed to exchange identities. The access token must have an audience that is contained in this set. If no audience is set, the default allowed audience will be the resource name of the WorkloadIdentityProvider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#allowed_audiences IamWorkloadIdentityProvider#allowed_audiences}
    */
    readonly allowedAudiences?: string[];
    /**
    * The URL of the OIDC Issuer that is allowed to exchange workload identities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#issuer_uri IamWorkloadIdentityProvider#issuer_uri}
    */
    readonly issuerUri: string;
}
export declare function iamWorkloadIdentityProviderOidcToTerraform(struct?: IamWorkloadIdentityProviderOidc | cdktn.IResolvable): any;
export declare function iamWorkloadIdentityProviderOidcToHclTerraform(struct?: IamWorkloadIdentityProviderOidc | cdktn.IResolvable): any;
export declare class IamWorkloadIdentityProviderOidcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IamWorkloadIdentityProviderOidc | cdktn.IResolvable | undefined;
    set internalValue(value: IamWorkloadIdentityProviderOidc | cdktn.IResolvable | undefined);
    private _allowedAudiences?;
    get allowedAudiences(): string[];
    set allowedAudiences(value: string[]);
    resetAllowedAudiences(): void;
    get allowedAudiencesInput(): string[] | undefined;
    private _issuerUri?;
    get issuerUri(): string;
    set issuerUri(value: string);
    get issuerUriInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider hcp_iam_workload_identity_provider}
*/
export declare class IamWorkloadIdentityProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_iam_workload_identity_provider";
    /**
    * Generates CDKTN code for importing a IamWorkloadIdentityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IamWorkloadIdentityProvider to import
    * @param importFromId The id of the existing IamWorkloadIdentityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IamWorkloadIdentityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/iam_workload_identity_provider hcp_iam_workload_identity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IamWorkloadIdentityProviderConfig
    */
    constructor(scope: Construct, id: string, config: IamWorkloadIdentityProviderConfig);
    private _aws;
    get aws(): IamWorkloadIdentityProviderAwsOutputReference;
    putAws(value: IamWorkloadIdentityProviderAws): void;
    resetAws(): void;
    get awsInput(): cdktn.IResolvable | IamWorkloadIdentityProviderAws | undefined;
    private _conditionalAccess?;
    get conditionalAccess(): string;
    set conditionalAccess(value: string);
    get conditionalAccessInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _oidc;
    get oidc(): IamWorkloadIdentityProviderOidcOutputReference;
    putOidc(value: IamWorkloadIdentityProviderOidc): void;
    resetOidc(): void;
    get oidcInput(): cdktn.IResolvable | IamWorkloadIdentityProviderOidc | undefined;
    get resourceId(): string;
    get resourceName(): string;
    private _servicePrincipal?;
    get servicePrincipal(): string;
    set servicePrincipal(value: string);
    get servicePrincipalInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
