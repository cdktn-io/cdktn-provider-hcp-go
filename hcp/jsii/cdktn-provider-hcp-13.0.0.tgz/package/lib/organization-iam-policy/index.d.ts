/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OrganizationIamPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The policy to apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/organization_iam_policy#policy_data OrganizationIamPolicy#policy_data}
    */
    readonly policyData: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/organization_iam_policy hcp_organization_iam_policy}
*/
export declare class OrganizationIamPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_organization_iam_policy";
    /**
    * Generates CDKTN code for importing a OrganizationIamPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrganizationIamPolicy to import
    * @param importFromId The id of the existing OrganizationIamPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/organization_iam_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrganizationIamPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/organization_iam_policy hcp_organization_iam_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationIamPolicyConfig
    */
    constructor(scope: Construct, id: string, config: OrganizationIamPolicyConfig);
    get etag(): string;
    private _policyData?;
    get policyData(): string;
    set policyData(value: string);
    get policyDataInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
