/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaypointTfcConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Waypoint Project ID to associate with the TFC config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_tfc_config#project_id WaypointTfcConfig#project_id}
    */
    readonly projectId?: string;
    /**
    * The Terraform Cloud Organization with which the token is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_tfc_config#tfc_org_name WaypointTfcConfig#tfc_org_name}
    */
    readonly tfcOrgName: string;
    /**
    * Terraform Cloud team token. The token must include permissions to manage workspaces and applications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_tfc_config#token WaypointTfcConfig#token}
    */
    readonly token: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_tfc_config hcp_waypoint_tfc_config}
*/
export declare class WaypointTfcConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_waypoint_tfc_config";
    /**
    * Generates CDKTN code for importing a WaypointTfcConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaypointTfcConfig to import
    * @param importFromId The id of the existing WaypointTfcConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_tfc_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaypointTfcConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/waypoint_tfc_config hcp_waypoint_tfc_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaypointTfcConfigConfig
    */
    constructor(scope: Construct, id: string, config: WaypointTfcConfigConfig);
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _tfcOrgName?;
    get tfcOrgName(): string;
    set tfcOrgName(value: string);
    get tfcOrgNameInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
