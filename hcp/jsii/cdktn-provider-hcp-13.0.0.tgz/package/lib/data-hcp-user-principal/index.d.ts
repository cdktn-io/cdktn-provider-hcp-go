/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpUserPrincipalConfig extends cdktn.TerraformMetaArguments {
    /**
    * The user's email. Can not be combined with user_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/user_principal#email DataHcpUserPrincipal#email}
    */
    readonly email?: string;
    /**
    * The user's unique identifier. Can not be combined with email.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/user_principal#user_id DataHcpUserPrincipal#user_id}
    */
    readonly userId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/user_principal hcp_user_principal}
*/
export declare class DataHcpUserPrincipal extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_user_principal";
    /**
    * Generates CDKTN code for importing a DataHcpUserPrincipal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpUserPrincipal to import
    * @param importFromId The id of the existing DataHcpUserPrincipal that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/user_principal#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpUserPrincipal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/data-sources/user_principal hcp_user_principal} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpUserPrincipalConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpUserPrincipalConfig);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
