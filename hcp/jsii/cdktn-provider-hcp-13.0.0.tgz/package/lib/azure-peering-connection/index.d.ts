/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AzurePeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the forwarded traffic originating from the peered VNet is allowed in the HVN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#allow_forwarded_traffic AzurePeeringConnection#allow_forwarded_traffic}
    */
    readonly allowForwardedTraffic?: boolean | cdktn.IResolvable;
    /**
    * The `self_link` of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#hvn_link AzurePeeringConnection#hvn_link}
    */
    readonly hvnLink: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#id AzurePeeringConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource group name of the peer VNet in Azure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#peer_resource_group_name AzurePeeringConnection#peer_resource_group_name}
    */
    readonly peerResourceGroupName: string;
    /**
    * The subscription ID of the peer VNet in Azure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#peer_subscription_id AzurePeeringConnection#peer_subscription_id}
    */
    readonly peerSubscriptionId: string;
    /**
    * The tenant ID of the peer VNet in Azure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#peer_tenant_id AzurePeeringConnection#peer_tenant_id}
    */
    readonly peerTenantId: string;
    /**
    * The name of the peer VNet in Azure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#peer_vnet_name AzurePeeringConnection#peer_vnet_name}
    */
    readonly peerVnetName: string;
    /**
    * The region of the peer VNet in Azure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#peer_vnet_region AzurePeeringConnection#peer_vnet_region}
    */
    readonly peerVnetRegion: string;
    /**
    * The ID of the peering connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#peering_id AzurePeeringConnection#peering_id}
    */
    readonly peeringId: string;
    /**
    * If the HVN should use the gateway of the peered VNet
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#use_remote_gateways AzurePeeringConnection#use_remote_gateways}
    */
    readonly useRemoteGateways?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#timeouts AzurePeeringConnection#timeouts}
    */
    readonly timeouts?: AzurePeeringConnectionTimeouts;
}
export interface AzurePeeringConnectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#create AzurePeeringConnection#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#default AzurePeeringConnection#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#delete AzurePeeringConnection#delete}
    */
    readonly delete?: string;
}
export declare function azurePeeringConnectionTimeoutsToTerraform(struct?: AzurePeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare function azurePeeringConnectionTimeoutsToHclTerraform(struct?: AzurePeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare class AzurePeeringConnectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AzurePeeringConnectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AzurePeeringConnectionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection hcp_azure_peering_connection}
*/
export declare class AzurePeeringConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_azure_peering_connection";
    /**
    * Generates CDKTN code for importing a AzurePeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AzurePeeringConnection to import
    * @param importFromId The id of the existing AzurePeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AzurePeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/azure_peering_connection hcp_azure_peering_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AzurePeeringConnectionConfig
    */
    constructor(scope: Construct, id: string, config: AzurePeeringConnectionConfig);
    private _allowForwardedTraffic?;
    get allowForwardedTraffic(): boolean | cdktn.IResolvable;
    set allowForwardedTraffic(value: boolean | cdktn.IResolvable);
    resetAllowForwardedTraffic(): void;
    get allowForwardedTrafficInput(): boolean | cdktn.IResolvable | undefined;
    get applicationId(): string;
    get azurePeeringId(): string;
    get createdAt(): string;
    get expiresAt(): string;
    private _hvnLink?;
    get hvnLink(): string;
    set hvnLink(value: string);
    get hvnLinkInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _peerResourceGroupName?;
    get peerResourceGroupName(): string;
    set peerResourceGroupName(value: string);
    get peerResourceGroupNameInput(): string | undefined;
    private _peerSubscriptionId?;
    get peerSubscriptionId(): string;
    set peerSubscriptionId(value: string);
    get peerSubscriptionIdInput(): string | undefined;
    private _peerTenantId?;
    get peerTenantId(): string;
    set peerTenantId(value: string);
    get peerTenantIdInput(): string | undefined;
    private _peerVnetName?;
    get peerVnetName(): string;
    set peerVnetName(value: string);
    get peerVnetNameInput(): string | undefined;
    private _peerVnetRegion?;
    get peerVnetRegion(): string;
    set peerVnetRegion(value: string);
    get peerVnetRegionInput(): string | undefined;
    private _peeringId?;
    get peeringId(): string;
    set peeringId(value: string);
    get peeringIdInput(): string | undefined;
    get projectId(): string;
    get selfLink(): string;
    get state(): string;
    private _useRemoteGateways?;
    get useRemoteGateways(): boolean | cdktn.IResolvable;
    set useRemoteGateways(value: boolean | cdktn.IResolvable);
    resetUseRemoteGateways(): void;
    get useRemoteGatewaysInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AzurePeeringConnectionTimeoutsOutputReference;
    putTimeouts(value: AzurePeeringConnectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AzurePeeringConnectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
