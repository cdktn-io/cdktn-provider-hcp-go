/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PackerBucketConfig extends cdktn.TerraformMetaArguments {
    /**
    * The bucket's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_bucket#name PackerBucket#name}
    */
    readonly name: string;
    /**
    * The ID of the project to create the bucket under. If unspecified, the bucket will be created in the project the provider is configured with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_bucket#project_id PackerBucket#project_id}
    */
    readonly projectId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_bucket hcp_packer_bucket}
*/
export declare class PackerBucket extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_packer_bucket";
    /**
    * Generates CDKTN code for importing a PackerBucket resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PackerBucket to import
    * @param importFromId The id of the existing PackerBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PackerBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/packer_bucket hcp_packer_bucket} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PackerBucketConfig
    */
    constructor(scope: Construct, id: string, config: PackerBucketConfig);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
