/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotificationsWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * The webhook configuration used to deliver event payloads.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#config NotificationsWebhook#config}
    */
    readonly config: NotificationsWebhookConfigA;
    /**
    * The webhook's description. Descriptions are useful for helping others understand the purpose of the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#description NotificationsWebhook#description}
    */
    readonly description?: string;
    /**
    * Indicates if the webhook should receive payloads for the subscribed events. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#enabled NotificationsWebhook#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The webhook's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#name NotificationsWebhook#name}
    */
    readonly name: string;
    /**
    * The ID of the project to create the webhook under. If unspecified, the webhook will be created in the project the provider is configured with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#project_id NotificationsWebhook#project_id}
    */
    readonly projectId?: string;
    /**
    * Set of events to subscribe the webhook to all resources or a specific resource in the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#subscriptions NotificationsWebhook#subscriptions}
    */
    readonly subscriptions?: NotificationsWebhookSubscriptions[] | cdktn.IResolvable;
}
export interface NotificationsWebhookConfigA {
    /**
    * The arbitrary secret that HCP uses to sign all its webhook requests. This is a write-only field, it is written once and not visible thereafter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#hmac_key NotificationsWebhook#hmac_key}
    */
    readonly hmacKey?: string;
    /**
    * The HTTP or HTTPS destination URL that HCP delivers the event payloads to.
    * The destination must be able to use the HCP webhook
    * [payload](https://developer.hashicorp.com/hcp/docs/hcp/admin/projects/webhooks#webhook-payload).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#url NotificationsWebhook#url}
    */
    readonly url: string;
}
export declare function notificationsWebhookConfigAToTerraform(struct?: NotificationsWebhookConfigA | cdktn.IResolvable): any;
export declare function notificationsWebhookConfigAToHclTerraform(struct?: NotificationsWebhookConfigA | cdktn.IResolvable): any;
export declare class NotificationsWebhookConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationsWebhookConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationsWebhookConfigA | cdktn.IResolvable | undefined);
    private _hmacKey?;
    get hmacKey(): string;
    set hmacKey(value: string);
    resetHmacKey(): void;
    get hmacKeyInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface NotificationsWebhookSubscriptionsEvents {
    /**
    * The list of event actions subscribed for the resource type set as the [source](#source). For example, `["create", "update"]`. When the action is '*', it means that the webhook is subscribed to all event actions for the event source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#actions NotificationsWebhook#actions}
    */
    readonly actions: string[];
    /**
    * The resource type of the source of the event. For example, `hashicorp.packer.version`. Event source might not be the same type as the resource that the webhook is subscribed to ([resource_id](#resource_id)) if the event is from a descendant resource. For example, webhooks are subscribed to a `hashicorp.packer.registry` and receive events for descendent resources such as a `hashicorp.packer.version`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#source NotificationsWebhook#source}
    */
    readonly source: string;
}
export declare function notificationsWebhookSubscriptionsEventsToTerraform(struct?: NotificationsWebhookSubscriptionsEvents | cdktn.IResolvable): any;
export declare function notificationsWebhookSubscriptionsEventsToHclTerraform(struct?: NotificationsWebhookSubscriptionsEvents | cdktn.IResolvable): any;
export declare class NotificationsWebhookSubscriptionsEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationsWebhookSubscriptionsEvents | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationsWebhookSubscriptionsEvents | cdktn.IResolvable | undefined);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    get actionsInput(): string[] | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class NotificationsWebhookSubscriptionsEventsList extends cdktn.ComplexList {
    internalValue?: NotificationsWebhookSubscriptionsEvents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationsWebhookSubscriptionsEventsOutputReference;
}
export interface NotificationsWebhookSubscriptions {
    /**
    * The information about the events of a webhook subscription. The service that owns the resource is responsible for maintaining events. Refer to the service's webhook documentation for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#events NotificationsWebhook#events}
    */
    readonly events: NotificationsWebhookSubscriptionsEvents[] | cdktn.IResolvable;
    /**
    * Refers to the resource the webhook is subscribed to. If not set, the webhook subscribes to the emitted events listed in events for any resource in the webhook's project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#resource_id NotificationsWebhook#resource_id}
    */
    readonly resourceId?: string;
}
export declare function notificationsWebhookSubscriptionsToTerraform(struct?: NotificationsWebhookSubscriptions | cdktn.IResolvable): any;
export declare function notificationsWebhookSubscriptionsToHclTerraform(struct?: NotificationsWebhookSubscriptions | cdktn.IResolvable): any;
export declare class NotificationsWebhookSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationsWebhookSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationsWebhookSubscriptions | cdktn.IResolvable | undefined);
    private _events;
    get events(): NotificationsWebhookSubscriptionsEventsList;
    putEvents(value: NotificationsWebhookSubscriptionsEvents[] | cdktn.IResolvable): void;
    get eventsInput(): cdktn.IResolvable | NotificationsWebhookSubscriptionsEvents[] | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
}
export declare class NotificationsWebhookSubscriptionsList extends cdktn.ComplexList {
    internalValue?: NotificationsWebhookSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationsWebhookSubscriptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook hcp_notifications_webhook}
*/
export declare class NotificationsWebhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_notifications_webhook";
    /**
    * Generates CDKTN code for importing a NotificationsWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationsWebhook to import
    * @param importFromId The id of the existing NotificationsWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationsWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/notifications_webhook hcp_notifications_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationsWebhookConfig
    */
    constructor(scope: Construct, id: string, config: NotificationsWebhookConfig);
    private _config;
    get config(): NotificationsWebhookConfigAOutputReference;
    putConfig(value: NotificationsWebhookConfigA): void;
    get configInput(): cdktn.IResolvable | NotificationsWebhookConfigA | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    private _subscriptions;
    get subscriptions(): NotificationsWebhookSubscriptionsList;
    putSubscriptions(value: NotificationsWebhookSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | NotificationsWebhookSubscriptions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
