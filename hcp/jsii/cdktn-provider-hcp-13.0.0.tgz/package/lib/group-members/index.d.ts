/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupMembersConfig extends cdktn.TerraformMetaArguments {
    /**
    * The group's resource name in the format `iam/organization/<organization_id>/group/<name>`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_members#group GroupMembers#group}
    */
    readonly group: string;
    /**
    * A list of user principal IDs to add to the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_members#members GroupMembers#members}
    */
    readonly members: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_members hcp_group_members}
*/
export declare class GroupMembers extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_group_members";
    /**
    * Generates CDKTN code for importing a GroupMembers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupMembers to import
    * @param importFromId The id of the existing GroupMembers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_members#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupMembers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/group_members hcp_group_members} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupMembersConfig
    */
    constructor(scope: Construct, id: string, config: GroupMembersConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    get membersInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
