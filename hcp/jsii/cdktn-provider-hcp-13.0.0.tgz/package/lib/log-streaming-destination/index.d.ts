/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogStreamingDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#cloudwatch LogStreamingDestination#cloudwatch}
    */
    readonly cloudwatch?: LogStreamingDestinationCloudwatch;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#datadog LogStreamingDestination#datadog}
    */
    readonly datadog?: LogStreamingDestinationDatadog;
    /**
    * The HCP Log Streaming Destination’s name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#name LogStreamingDestination#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#splunk_cloud LogStreamingDestination#splunk_cloud}
    */
    readonly splunkCloud?: LogStreamingDestinationSplunkCloud;
}
export interface LogStreamingDestinationCloudwatch {
    /**
    * The external_id to provide when assuming the aws IAM role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#external_id LogStreamingDestination#external_id}
    */
    readonly externalId: string;
    /**
    * The log_group_name of the CloudWatch destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#log_group_name LogStreamingDestination#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The region the CloudWatch destination is set up to stream to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#region LogStreamingDestination#region}
    */
    readonly region: string;
    /**
    * The role_arn that will be assumed to stream logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#role_arn LogStreamingDestination#role_arn}
    */
    readonly roleArn: string;
}
export declare function logStreamingDestinationCloudwatchToTerraform(struct?: LogStreamingDestinationCloudwatch | cdktn.IResolvable): any;
export declare function logStreamingDestinationCloudwatchToHclTerraform(struct?: LogStreamingDestinationCloudwatch | cdktn.IResolvable): any;
export declare class LogStreamingDestinationCloudwatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogStreamingDestinationCloudwatch | cdktn.IResolvable | undefined;
    set internalValue(value: LogStreamingDestinationCloudwatch | cdktn.IResolvable | undefined);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    get externalIdInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface LogStreamingDestinationDatadog {
    /**
    * The value for the DD-API-KEY to send when making requests to DataDog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#api_key LogStreamingDestination#api_key}
    */
    readonly apiKey: string;
    /**
    * The value for the DD-APPLICATION-KEY to send when making requests to DataDog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#application_key LogStreamingDestination#application_key}
    */
    readonly applicationKey?: string;
    /**
    * The Datadog endpoint to send logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#endpoint LogStreamingDestination#endpoint}
    */
    readonly endpoint: string;
}
export declare function logStreamingDestinationDatadogToTerraform(struct?: LogStreamingDestinationDatadog | cdktn.IResolvable): any;
export declare function logStreamingDestinationDatadogToHclTerraform(struct?: LogStreamingDestinationDatadog | cdktn.IResolvable): any;
export declare class LogStreamingDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogStreamingDestinationDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: LogStreamingDestinationDatadog | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _applicationKey?;
    get applicationKey(): string;
    set applicationKey(value: string);
    resetApplicationKey(): void;
    get applicationKeyInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
}
export interface LogStreamingDestinationSplunkCloud {
    /**
    * The Splunk Cloud endpoint to send logs to. Streaming to free trial instances is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#endpoint LogStreamingDestination#endpoint}
    */
    readonly endpoint: string;
    /**
    * The authentication token that will be used by the platform to access Splunk Cloud.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#token LogStreamingDestination#token}
    */
    readonly token: string;
}
export declare function logStreamingDestinationSplunkCloudToTerraform(struct?: LogStreamingDestinationSplunkCloud | cdktn.IResolvable): any;
export declare function logStreamingDestinationSplunkCloudToHclTerraform(struct?: LogStreamingDestinationSplunkCloud | cdktn.IResolvable): any;
export declare class LogStreamingDestinationSplunkCloudOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogStreamingDestinationSplunkCloud | cdktn.IResolvable | undefined;
    set internalValue(value: LogStreamingDestinationSplunkCloud | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination hcp_log_streaming_destination}
*/
export declare class LogStreamingDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_log_streaming_destination";
    /**
    * Generates CDKTN code for importing a LogStreamingDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogStreamingDestination to import
    * @param importFromId The id of the existing LogStreamingDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogStreamingDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.113.0/docs/resources/log_streaming_destination hcp_log_streaming_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogStreamingDestinationConfig
    */
    constructor(scope: Construct, id: string, config: LogStreamingDestinationConfig);
    private _cloudwatch;
    get cloudwatch(): LogStreamingDestinationCloudwatchOutputReference;
    putCloudwatch(value: LogStreamingDestinationCloudwatch): void;
    resetCloudwatch(): void;
    get cloudwatchInput(): cdktn.IResolvable | LogStreamingDestinationCloudwatch | undefined;
    private _datadog;
    get datadog(): LogStreamingDestinationDatadogOutputReference;
    putDatadog(value: LogStreamingDestinationDatadog): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | LogStreamingDestinationDatadog | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _splunkCloud;
    get splunkCloud(): LogStreamingDestinationSplunkCloudOutputReference;
    putSplunkCloud(value: LogStreamingDestinationSplunkCloud): void;
    resetSplunkCloud(): void;
    get splunkCloudInput(): cdktn.IResolvable | LogStreamingDestinationSplunkCloud | undefined;
    get streamingDestinationId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
