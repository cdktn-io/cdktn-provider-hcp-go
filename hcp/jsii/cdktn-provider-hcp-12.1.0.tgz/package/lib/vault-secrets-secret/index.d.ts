/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the application the secret can be found in
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_secret#app_name VaultSecretsSecret#app_name}
    */
    readonly appName: string;
    /**
    * The ID of the HCP project where the HCP Vault Secrets secret is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_secret#project_id VaultSecretsSecret#project_id}
    */
    readonly projectId?: string;
    /**
    * The name of the secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_secret#secret_name VaultSecretsSecret#secret_name}
    */
    readonly secretName: string;
    /**
    * The value of the secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_secret#secret_value VaultSecretsSecret#secret_value}
    */
    readonly secretValue: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_secret hcp_vault_secrets_secret}
*/
export declare class VaultSecretsSecret extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_secret";
    /**
    * Generates CDKTN code for importing a VaultSecretsSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsSecret to import
    * @param importFromId The id of the existing VaultSecretsSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_secret hcp_vault_secrets_secret} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsSecretConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsSecretConfig);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    get id(): string;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _secretValue?;
    get secretValue(): string;
    set secretValue(value: string);
    get secretValueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
