/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpVaultSecretsRotatingSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Vault Secrets application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/vault_secrets_rotating_secret#app_name DataHcpVaultSecretsRotatingSecret#app_name}
    */
    readonly appName: string;
    /**
    * The name of the Vault Secrets secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/vault_secrets_rotating_secret#secret_name DataHcpVaultSecretsRotatingSecret#secret_name}
    */
    readonly secretName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/vault_secrets_rotating_secret hcp_vault_secrets_rotating_secret}
*/
export declare class DataHcpVaultSecretsRotatingSecret extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_vault_secrets_rotating_secret";
    /**
    * Generates CDKTN code for importing a DataHcpVaultSecretsRotatingSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpVaultSecretsRotatingSecret to import
    * @param importFromId The id of the existing DataHcpVaultSecretsRotatingSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/vault_secrets_rotating_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpVaultSecretsRotatingSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/vault_secrets_rotating_secret hcp_vault_secrets_rotating_secret} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpVaultSecretsRotatingSecretConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpVaultSecretsRotatingSecretConfig);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    get id(): string;
    get organizationId(): string;
    get projectId(): string;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    get secretProvider(): string;
    private _secretValues;
    get secretValues(): cdktn.StringMap;
    get secretVersion(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
