/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpDnsForwardingConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the DNS forwarding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding#dns_forwarding_id DataHcpDnsForwarding#dns_forwarding_id}
    */
    readonly dnsForwardingId: string;
    /**
    * The ID of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding#hvn_id DataHcpDnsForwarding#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding#id DataHcpDnsForwarding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the HCP project where the DNS forwarding is located. If not specified, the project specified in the HCP Provider config block will be used, if configured. If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding#project_id DataHcpDnsForwarding#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding#timeouts DataHcpDnsForwarding#timeouts}
    */
    readonly timeouts?: DataHcpDnsForwardingTimeouts;
}
export interface DataHcpDnsForwardingForwardingRules {
}
export declare function dataHcpDnsForwardingForwardingRulesToTerraform(struct?: DataHcpDnsForwardingForwardingRules): any;
export declare function dataHcpDnsForwardingForwardingRulesToHclTerraform(struct?: DataHcpDnsForwardingForwardingRules): any;
export declare class DataHcpDnsForwardingForwardingRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpDnsForwardingForwardingRules | undefined;
    set internalValue(value: DataHcpDnsForwardingForwardingRules | undefined);
    get domainName(): string;
    get inboundEndpointIps(): string[];
    get ruleId(): string;
}
export declare class DataHcpDnsForwardingForwardingRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpDnsForwardingForwardingRulesOutputReference;
}
export interface DataHcpDnsForwardingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding#read DataHcpDnsForwarding#read}
    */
    readonly read?: string;
}
export declare function dataHcpDnsForwardingTimeoutsToTerraform(struct?: DataHcpDnsForwardingTimeouts | cdktn.IResolvable): any;
export declare function dataHcpDnsForwardingTimeoutsToHclTerraform(struct?: DataHcpDnsForwardingTimeouts | cdktn.IResolvable): any;
export declare class DataHcpDnsForwardingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpDnsForwardingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpDnsForwardingTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding hcp_dns_forwarding}
*/
export declare class DataHcpDnsForwarding extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_dns_forwarding";
    /**
    * Generates CDKTN code for importing a DataHcpDnsForwarding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpDnsForwarding to import
    * @param importFromId The id of the existing DataHcpDnsForwarding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpDnsForwarding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/dns_forwarding hcp_dns_forwarding} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpDnsForwardingConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpDnsForwardingConfig);
    get connectionType(): string;
    get createdAt(): string;
    private _dnsForwardingId?;
    get dnsForwardingId(): string;
    set dnsForwardingId(value: string);
    get dnsForwardingIdInput(): string | undefined;
    private _forwardingRules;
    get forwardingRules(): DataHcpDnsForwardingForwardingRulesList;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    get peeringId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    get updatedAt(): string;
    private _timeouts;
    get timeouts(): DataHcpDnsForwardingTimeoutsOutputReference;
    putTimeouts(value: DataHcpDnsForwardingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpDnsForwardingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
