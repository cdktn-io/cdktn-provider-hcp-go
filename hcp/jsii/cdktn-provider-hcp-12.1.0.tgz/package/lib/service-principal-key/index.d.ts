/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServicePrincipalKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A map of arbitrary string key/value pairs that will force recreation of the key when they change, enabling key based on external conditions such as a rotating timestamp. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/service_principal_key#rotate_triggers ServicePrincipalKey#rotate_triggers}
    */
    readonly rotateTriggers?: {
        [key: string]: string;
    };
    /**
    * The service principal's resource name for which a key should be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/service_principal_key#service_principal ServicePrincipalKey#service_principal}
    */
    readonly servicePrincipal: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/service_principal_key hcp_service_principal_key}
*/
export declare class ServicePrincipalKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_service_principal_key";
    /**
    * Generates CDKTN code for importing a ServicePrincipalKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServicePrincipalKey to import
    * @param importFromId The id of the existing ServicePrincipalKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/service_principal_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServicePrincipalKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/service_principal_key hcp_service_principal_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServicePrincipalKeyConfig
    */
    constructor(scope: Construct, id: string, config: ServicePrincipalKeyConfig);
    get clientId(): string;
    get clientSecret(): string;
    get resourceName(): string;
    private _rotateTriggers?;
    get rotateTriggers(): {
        [key: string]: string;
    };
    set rotateTriggers(value: {
        [key: string]: string;
    });
    resetRotateTriggers(): void;
    get rotateTriggersInput(): {
        [key: string]: string;
    } | undefined;
    private _servicePrincipal?;
    get servicePrincipal(): string;
    set servicePrincipal(value: string);
    get servicePrincipalInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
