/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpHvnConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn#hvn_id DataHcpHvn#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn#id DataHcpHvn#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the HVN is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn#project_id DataHcpHvn#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn#timeouts DataHcpHvn#timeouts}
    */
    readonly timeouts?: DataHcpHvnTimeouts;
}
export interface DataHcpHvnTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn#default DataHcpHvn#default}
    */
    readonly default?: string;
}
export declare function dataHcpHvnTimeoutsToTerraform(struct?: DataHcpHvnTimeouts | cdktn.IResolvable): any;
export declare function dataHcpHvnTimeoutsToHclTerraform(struct?: DataHcpHvnTimeouts | cdktn.IResolvable): any;
export declare class DataHcpHvnTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpHvnTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpHvnTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn hcp_hvn}
*/
export declare class DataHcpHvn extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_hvn";
    /**
    * Generates CDKTN code for importing a DataHcpHvn resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpHvn to import
    * @param importFromId The id of the existing DataHcpHvn that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpHvn to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/hvn hcp_hvn} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpHvnConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpHvnConfig);
    get cidrBlock(): string;
    get cloudProvider(): string;
    get createdAt(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get providerAccountId(): string;
    get region(): string;
    get selfLink(): string;
    get state(): string;
    private _timeouts;
    get timeouts(): DataHcpHvnTimeoutsOutputReference;
    putTimeouts(value: DataHcpHvnTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpHvnTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
