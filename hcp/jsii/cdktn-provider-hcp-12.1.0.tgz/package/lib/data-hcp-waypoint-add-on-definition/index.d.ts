/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpWaypointAddOnDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Add-on Definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_add_on_definition#id DataHcpWaypointAddOnDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Add-on Definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_add_on_definition#name DataHcpWaypointAddOnDefinition#name}
    */
    readonly name?: string;
    /**
    * The ID of the HCP project where the Waypoint Add-on Definition is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_add_on_definition#project_id DataHcpWaypointAddOnDefinition#project_id}
    */
    readonly projectId?: string;
}
export interface DataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetails {
}
export declare function dataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetailsToTerraform(struct?: DataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetails): any;
export declare function dataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetailsToHclTerraform(struct?: DataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetails): any;
export declare class DataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetails | undefined;
    set internalValue(value: DataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetails | undefined);
    get name(): string;
    get terraformProjectId(): string;
}
export interface DataHcpWaypointAddOnDefinitionVariableOptions {
}
export declare function dataHcpWaypointAddOnDefinitionVariableOptionsToTerraform(struct?: DataHcpWaypointAddOnDefinitionVariableOptions): any;
export declare function dataHcpWaypointAddOnDefinitionVariableOptionsToHclTerraform(struct?: DataHcpWaypointAddOnDefinitionVariableOptions): any;
export declare class DataHcpWaypointAddOnDefinitionVariableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpWaypointAddOnDefinitionVariableOptions | undefined;
    set internalValue(value: DataHcpWaypointAddOnDefinitionVariableOptions | undefined);
    get name(): string;
    get options(): string[];
    get userEditable(): cdktn.IResolvable;
    get variableType(): string;
}
export declare class DataHcpWaypointAddOnDefinitionVariableOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpWaypointAddOnDefinitionVariableOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_add_on_definition hcp_waypoint_add_on_definition}
*/
export declare class DataHcpWaypointAddOnDefinition extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_waypoint_add_on_definition";
    /**
    * Generates CDKTN code for importing a DataHcpWaypointAddOnDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpWaypointAddOnDefinition to import
    * @param importFromId The id of the existing DataHcpWaypointAddOnDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_add_on_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpWaypointAddOnDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_add_on_definition hcp_waypoint_add_on_definition} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpWaypointAddOnDefinitionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpWaypointAddOnDefinitionConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labels(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get readmeMarkdownTemplate(): string;
    get summary(): string;
    get terraformAgentPoolId(): string;
    private _terraformCloudWorkspaceDetails;
    get terraformCloudWorkspaceDetails(): DataHcpWaypointAddOnDefinitionTerraformCloudWorkspaceDetailsOutputReference;
    get terraformExecutionMode(): string;
    get terraformNoCodeModuleId(): string;
    get terraformNoCodeModuleSource(): string;
    private _variableOptions;
    get variableOptions(): DataHcpWaypointAddOnDefinitionVariableOptionsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
