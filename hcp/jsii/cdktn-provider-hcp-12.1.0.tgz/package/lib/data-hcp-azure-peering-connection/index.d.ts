/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpAzurePeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The `self_link` of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection#hvn_link DataHcpAzurePeeringConnection#hvn_link}
    */
    readonly hvnLink: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection#id DataHcpAzurePeeringConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the peering connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection#peering_id DataHcpAzurePeeringConnection#peering_id}
    */
    readonly peeringId: string;
    /**
    * If `true`, Terraform will wait for the peering connection to reach an `ACTIVE` state before continuing. Default `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection#wait_for_active_state DataHcpAzurePeeringConnection#wait_for_active_state}
    */
    readonly waitForActiveState?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection#timeouts DataHcpAzurePeeringConnection#timeouts}
    */
    readonly timeouts?: DataHcpAzurePeeringConnectionTimeouts;
}
export interface DataHcpAzurePeeringConnectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection#read DataHcpAzurePeeringConnection#read}
    */
    readonly read?: string;
}
export declare function dataHcpAzurePeeringConnectionTimeoutsToTerraform(struct?: DataHcpAzurePeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare function dataHcpAzurePeeringConnectionTimeoutsToHclTerraform(struct?: DataHcpAzurePeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare class DataHcpAzurePeeringConnectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpAzurePeeringConnectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpAzurePeeringConnectionTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection hcp_azure_peering_connection}
*/
export declare class DataHcpAzurePeeringConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_azure_peering_connection";
    /**
    * Generates CDKTN code for importing a DataHcpAzurePeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpAzurePeeringConnection to import
    * @param importFromId The id of the existing DataHcpAzurePeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpAzurePeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/azure_peering_connection hcp_azure_peering_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpAzurePeeringConnectionConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpAzurePeeringConnectionConfig);
    get allowForwardedTraffic(): cdktn.IResolvable;
    get applicationId(): string;
    get azurePeeringId(): string;
    get createdAt(): string;
    get expiresAt(): string;
    private _hvnLink?;
    get hvnLink(): string;
    set hvnLink(value: string);
    get hvnLinkInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    get peerResourceGroupName(): string;
    get peerSubscriptionId(): string;
    get peerTenantId(): string;
    get peerVnetName(): string;
    get peerVnetRegion(): string;
    private _peeringId?;
    get peeringId(): string;
    set peeringId(value: string);
    get peeringIdInput(): string | undefined;
    get projectId(): string;
    get selfLink(): string;
    get state(): string;
    get useRemoteGateways(): cdktn.IResolvable;
    private _waitForActiveState?;
    get waitForActiveState(): boolean | cdktn.IResolvable;
    set waitForActiveState(value: boolean | cdktn.IResolvable);
    resetWaitForActiveState(): void;
    get waitForActiveStateInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): DataHcpAzurePeeringConnectionTimeoutsOutputReference;
    putTimeouts(value: DataHcpAzurePeeringConnectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpAzurePeeringConnectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
