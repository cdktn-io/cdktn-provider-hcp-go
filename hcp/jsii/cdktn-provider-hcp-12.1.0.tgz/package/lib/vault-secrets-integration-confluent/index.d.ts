/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsIntegrationConfluentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Capabilities enabled for the integration. See the Vault Secrets documentation for the list of supported capabilities per provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent#capabilities VaultSecretsIntegrationConfluent#capabilities}
    */
    readonly capabilities: string[];
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent#name VaultSecretsIntegrationConfluent#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent#project_id VaultSecretsIntegrationConfluent#project_id}
    */
    readonly projectId?: string;
    /**
    * Confluent API key used to authenticate for cloud apis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent#static_credential_details VaultSecretsIntegrationConfluent#static_credential_details}
    */
    readonly staticCredentialDetails?: VaultSecretsIntegrationConfluentStaticCredentialDetails;
}
export interface VaultSecretsIntegrationConfluentStaticCredentialDetails {
    /**
    * Public key used alongside the private key to authenticate for cloud apis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent#cloud_api_key_id VaultSecretsIntegrationConfluent#cloud_api_key_id}
    */
    readonly cloudApiKeyId: string;
    /**
    * Private key used alongside the public key to authenticate for cloud apis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent#cloud_api_secret VaultSecretsIntegrationConfluent#cloud_api_secret}
    */
    readonly cloudApiSecret: string;
}
export declare function vaultSecretsIntegrationConfluentStaticCredentialDetailsToTerraform(struct?: VaultSecretsIntegrationConfluentStaticCredentialDetails | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationConfluentStaticCredentialDetailsToHclTerraform(struct?: VaultSecretsIntegrationConfluentStaticCredentialDetails | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationConfluentStaticCredentialDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationConfluentStaticCredentialDetails | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationConfluentStaticCredentialDetails | cdktn.IResolvable | undefined);
    private _cloudApiKeyId?;
    get cloudApiKeyId(): string;
    set cloudApiKeyId(value: string);
    get cloudApiKeyIdInput(): string | undefined;
    private _cloudApiSecret?;
    get cloudApiSecret(): string;
    set cloudApiSecret(value: string);
    get cloudApiSecretInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent hcp_vault_secrets_integration_confluent}
*/
export declare class VaultSecretsIntegrationConfluent extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_integration_confluent";
    /**
    * Generates CDKTN code for importing a VaultSecretsIntegrationConfluent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsIntegrationConfluent to import
    * @param importFromId The id of the existing VaultSecretsIntegrationConfluent that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsIntegrationConfluent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_confluent hcp_vault_secrets_integration_confluent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsIntegrationConfluentConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsIntegrationConfluentConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    private _staticCredentialDetails;
    get staticCredentialDetails(): VaultSecretsIntegrationConfluentStaticCredentialDetailsOutputReference;
    putStaticCredentialDetails(value: VaultSecretsIntegrationConfluentStaticCredentialDetails): void;
    resetStaticCredentialDetails(): void;
    get staticCredentialDetailsInput(): cdktn.IResolvable | VaultSecretsIntegrationConfluentStaticCredentialDetails | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
