/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultClusterAdminTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Vault cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#cluster_id VaultClusterAdminToken#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#id VaultClusterAdminToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the HCP Vault cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#project_id VaultClusterAdminToken#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#timeouts VaultClusterAdminToken#timeouts}
    */
    readonly timeouts?: VaultClusterAdminTokenTimeouts;
}
export interface VaultClusterAdminTokenTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#create VaultClusterAdminToken#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#delete VaultClusterAdminToken#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#read VaultClusterAdminToken#read}
    */
    readonly read?: string;
}
export declare function vaultClusterAdminTokenTimeoutsToTerraform(struct?: VaultClusterAdminTokenTimeouts | cdktn.IResolvable): any;
export declare function vaultClusterAdminTokenTimeoutsToHclTerraform(struct?: VaultClusterAdminTokenTimeouts | cdktn.IResolvable): any;
export declare class VaultClusterAdminTokenTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultClusterAdminTokenTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: VaultClusterAdminTokenTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token hcp_vault_cluster_admin_token}
*/
export declare class VaultClusterAdminToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_cluster_admin_token";
    /**
    * Generates CDKTN code for importing a VaultClusterAdminToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultClusterAdminToken to import
    * @param importFromId The id of the existing VaultClusterAdminToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultClusterAdminToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_cluster_admin_token hcp_vault_cluster_admin_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultClusterAdminTokenConfig
    */
    constructor(scope: Construct, id: string, config: VaultClusterAdminTokenConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get token(): string;
    private _timeouts;
    get timeouts(): VaultClusterAdminTokenTimeoutsOutputReference;
    putTimeouts(value: VaultClusterAdminTokenTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | VaultClusterAdminTokenTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
