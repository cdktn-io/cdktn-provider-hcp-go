/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpWaypointTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of actions by 'ID' to assign to this Template. Applications created from this Template will have these actions assigned to them. Only 'ID' is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_template#actions DataHcpWaypointTemplate#actions}
    */
    readonly actions?: string[];
    /**
    * The ID of the Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_template#id DataHcpWaypointTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_template#name DataHcpWaypointTemplate#name}
    */
    readonly name?: string;
    /**
    * The ID of the HCP project where the Waypoint Template is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_template#project_id DataHcpWaypointTemplate#project_id}
    */
    readonly projectId?: string;
}
export interface DataHcpWaypointTemplateTerraformCloudWorkspaceDetails {
}
export declare function dataHcpWaypointTemplateTerraformCloudWorkspaceDetailsToTerraform(struct?: DataHcpWaypointTemplateTerraformCloudWorkspaceDetails): any;
export declare function dataHcpWaypointTemplateTerraformCloudWorkspaceDetailsToHclTerraform(struct?: DataHcpWaypointTemplateTerraformCloudWorkspaceDetails): any;
export declare class DataHcpWaypointTemplateTerraformCloudWorkspaceDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpWaypointTemplateTerraformCloudWorkspaceDetails | undefined;
    set internalValue(value: DataHcpWaypointTemplateTerraformCloudWorkspaceDetails | undefined);
    get name(): string;
    get terraformProjectId(): string;
}
export interface DataHcpWaypointTemplateVariableOptions {
}
export declare function dataHcpWaypointTemplateVariableOptionsToTerraform(struct?: DataHcpWaypointTemplateVariableOptions): any;
export declare function dataHcpWaypointTemplateVariableOptionsToHclTerraform(struct?: DataHcpWaypointTemplateVariableOptions): any;
export declare class DataHcpWaypointTemplateVariableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpWaypointTemplateVariableOptions | undefined;
    set internalValue(value: DataHcpWaypointTemplateVariableOptions | undefined);
    get name(): string;
    get options(): string[];
    get userEditable(): cdktn.IResolvable;
    get variableType(): string;
}
export declare class DataHcpWaypointTemplateVariableOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpWaypointTemplateVariableOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_template hcp_waypoint_template}
*/
export declare class DataHcpWaypointTemplate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_waypoint_template";
    /**
    * Generates CDKTN code for importing a DataHcpWaypointTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpWaypointTemplate to import
    * @param importFromId The id of the existing DataHcpWaypointTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpWaypointTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_template hcp_waypoint_template} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpWaypointTemplateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpWaypointTemplateConfig);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    resetActions(): void;
    get actionsInput(): string[] | undefined;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labels(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get readmeMarkdownTemplate(): string;
    get summary(): string;
    get terraformAgentPoolId(): string;
    private _terraformCloudWorkspaceDetails;
    get terraformCloudWorkspaceDetails(): DataHcpWaypointTemplateTerraformCloudWorkspaceDetailsOutputReference;
    get terraformExecutionMode(): string;
    get terraformNoCodeModuleId(): string;
    get terraformNoCodeModuleSource(): string;
    private _variableOptions;
    get variableOptions(): DataHcpWaypointTemplateVariableOptionsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
