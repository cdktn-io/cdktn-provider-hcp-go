/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PackerChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the HCP Packer Registry bucket where the channel should be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#bucket_name PackerChannel#bucket_name}
    */
    readonly bucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#id PackerChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the channel being managed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#name PackerChannel#name}
    */
    readonly name: string;
    /**
    *
    * The ID of the HCP project where this channel is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#project_id PackerChannel#project_id}
    */
    readonly projectId?: string;
    /**
    * If true, the channel is only visible to users with permission to create and manage it. If false, the channel is visible to every member of the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#restricted PackerChannel#restricted}
    */
    readonly restricted?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#timeouts PackerChannel#timeouts}
    */
    readonly timeouts?: PackerChannelTimeouts;
}
export interface PackerChannelTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#create PackerChannel#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#default PackerChannel#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#delete PackerChannel#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#update PackerChannel#update}
    */
    readonly update?: string;
}
export declare function packerChannelTimeoutsToTerraform(struct?: PackerChannelTimeouts | cdktn.IResolvable): any;
export declare function packerChannelTimeoutsToHclTerraform(struct?: PackerChannelTimeouts | cdktn.IResolvable): any;
export declare class PackerChannelTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PackerChannelTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PackerChannelTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel hcp_packer_channel}
*/
export declare class PackerChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_packer_channel";
    /**
    * Generates CDKTN code for importing a PackerChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PackerChannel to import
    * @param importFromId The id of the existing PackerChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PackerChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_channel hcp_packer_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PackerChannelConfig
    */
    constructor(scope: Construct, id: string, config: PackerChannelConfig);
    get authorId(): string;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get managed(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _restricted?;
    get restricted(): boolean | cdktn.IResolvable;
    set restricted(value: boolean | cdktn.IResolvable);
    resetRestricted(): void;
    get restrictedInput(): boolean | cdktn.IResolvable | undefined;
    get updatedAt(): string;
    private _timeouts;
    get timeouts(): PackerChannelTimeoutsOutputReference;
    putTimeouts(value: PackerChannelTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PackerChannelTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
