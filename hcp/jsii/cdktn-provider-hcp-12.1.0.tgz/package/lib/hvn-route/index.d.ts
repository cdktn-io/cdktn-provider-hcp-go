/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HvnRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * The destination CIDR of the HVN route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#destination_cidr HvnRoute#destination_cidr}
    */
    readonly destinationCidr: string;
    /**
    * The `self_link` of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#hvn_link HvnRoute#hvn_link}
    */
    readonly hvnLink: string;
    /**
    * The ID of the HVN route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#hvn_route_id HvnRoute#hvn_route_id}
    */
    readonly hvnRouteId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#id HvnRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the HCP project where the HVN route is located. Always matches the project ID in `hvn_link`. Setting this attribute is deprecated, but it will remain usable in read-only form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#project_id HvnRoute#project_id}
    */
    readonly projectId?: string;
    /**
    * A unique URL identifying the target of the HVN route. Examples of the target: [`aws_network_peering`](aws_network_peering.md), [`aws_transit_gateway_attachment`](aws_transit_gateway_attachment.md)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#target_link HvnRoute#target_link}
    */
    readonly targetLink: string;
    /**
    * azure_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#azure_config HvnRoute#azure_config}
    */
    readonly azureConfig?: HvnRouteAzureConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#timeouts HvnRoute#timeouts}
    */
    readonly timeouts?: HvnRouteTimeouts;
}
export interface HvnRouteAzureConfig {
    /**
    * Contains the IP address packets should be forwarded to. Next hop values are only allowed in routes where the next hop type is VIRTUAL_APPLIANCE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#next_hop_ip_address HvnRoute#next_hop_ip_address}
    */
    readonly nextHopIpAddress?: string;
    /**
    * The type of Azure hop the packet should be sent to. Valid options for Next Hop Type - `VIRTUAL_APPLIANCE` or `VIRTUAL_NETWORK_GATEWAY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#next_hop_type HvnRoute#next_hop_type}
    */
    readonly nextHopType: string;
}
export declare function hvnRouteAzureConfigToTerraform(struct?: HvnRouteAzureConfigOutputReference | HvnRouteAzureConfig): any;
export declare function hvnRouteAzureConfigToHclTerraform(struct?: HvnRouteAzureConfigOutputReference | HvnRouteAzureConfig): any;
export declare class HvnRouteAzureConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HvnRouteAzureConfig | undefined;
    set internalValue(value: HvnRouteAzureConfig | undefined);
    private _nextHopIpAddress?;
    get nextHopIpAddress(): string;
    set nextHopIpAddress(value: string);
    resetNextHopIpAddress(): void;
    get nextHopIpAddressInput(): string | undefined;
    private _nextHopType?;
    get nextHopType(): string;
    set nextHopType(value: string);
    get nextHopTypeInput(): string | undefined;
}
export interface HvnRouteTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#create HvnRoute#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#default HvnRoute#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#delete HvnRoute#delete}
    */
    readonly delete?: string;
}
export declare function hvnRouteTimeoutsToTerraform(struct?: HvnRouteTimeouts | cdktn.IResolvable): any;
export declare function hvnRouteTimeoutsToHclTerraform(struct?: HvnRouteTimeouts | cdktn.IResolvable): any;
export declare class HvnRouteTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HvnRouteTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: HvnRouteTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route hcp_hvn_route}
*/
export declare class HvnRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_hvn_route";
    /**
    * Generates CDKTN code for importing a HvnRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HvnRoute to import
    * @param importFromId The id of the existing HvnRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HvnRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/hvn_route hcp_hvn_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HvnRouteConfig
    */
    constructor(scope: Construct, id: string, config: HvnRouteConfig);
    get createdAt(): string;
    private _destinationCidr?;
    get destinationCidr(): string;
    set destinationCidr(value: string);
    get destinationCidrInput(): string | undefined;
    private _hvnLink?;
    get hvnLink(): string;
    set hvnLink(value: string);
    get hvnLinkInput(): string | undefined;
    private _hvnRouteId?;
    get hvnRouteId(): string;
    set hvnRouteId(value: string);
    get hvnRouteIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    private _targetLink?;
    get targetLink(): string;
    set targetLink(value: string);
    get targetLinkInput(): string | undefined;
    private _azureConfig;
    get azureConfig(): HvnRouteAzureConfigOutputReference;
    putAzureConfig(value: HvnRouteAzureConfig): void;
    resetAzureConfig(): void;
    get azureConfigInput(): HvnRouteAzureConfig | undefined;
    private _timeouts;
    get timeouts(): HvnRouteTimeoutsOutputReference;
    putTimeouts(value: HvnRouteTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | HvnRouteTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
