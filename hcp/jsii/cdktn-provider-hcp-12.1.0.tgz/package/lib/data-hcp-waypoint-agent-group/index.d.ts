/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpWaypointAgentGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Agent Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_agent_group#name DataHcpWaypointAgentGroup#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_agent_group hcp_waypoint_agent_group}
*/
export declare class DataHcpWaypointAgentGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_waypoint_agent_group";
    /**
    * Generates CDKTN code for importing a DataHcpWaypointAgentGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpWaypointAgentGroup to import
    * @param importFromId The id of the existing DataHcpWaypointAgentGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_agent_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpWaypointAgentGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/waypoint_agent_group hcp_waypoint_agent_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpWaypointAgentGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpWaypointAgentGroupConfig);
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    get projectId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
