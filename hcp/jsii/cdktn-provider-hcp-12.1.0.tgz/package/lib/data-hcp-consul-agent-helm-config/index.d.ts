/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpConsulAgentHelmConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Consul cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#cluster_id DataHcpConsulAgentHelmConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Denotes that the gossip ports should be exposed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#expose_gossip_ports DataHcpConsulAgentHelmConfig#expose_gossip_ports}
    */
    readonly exposeGossipPorts?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#id DataHcpConsulAgentHelmConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The FQDN for the Kubernetes API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#kubernetes_endpoint DataHcpConsulAgentHelmConfig#kubernetes_endpoint}
    */
    readonly kubernetesEndpoint: string;
    /**
    *
    * The ID of the HCP project where the HCP Consul cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#project_id DataHcpConsulAgentHelmConfig#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#timeouts DataHcpConsulAgentHelmConfig#timeouts}
    */
    readonly timeouts?: DataHcpConsulAgentHelmConfigTimeouts;
}
export interface DataHcpConsulAgentHelmConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#default DataHcpConsulAgentHelmConfig#default}
    */
    readonly default?: string;
}
export declare function dataHcpConsulAgentHelmConfigTimeoutsToTerraform(struct?: DataHcpConsulAgentHelmConfigTimeouts | cdktn.IResolvable): any;
export declare function dataHcpConsulAgentHelmConfigTimeoutsToHclTerraform(struct?: DataHcpConsulAgentHelmConfigTimeouts | cdktn.IResolvable): any;
export declare class DataHcpConsulAgentHelmConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpConsulAgentHelmConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpConsulAgentHelmConfigTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config hcp_consul_agent_helm_config}
*/
export declare class DataHcpConsulAgentHelmConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_consul_agent_helm_config";
    /**
    * Generates CDKTN code for importing a DataHcpConsulAgentHelmConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpConsulAgentHelmConfig to import
    * @param importFromId The id of the existing DataHcpConsulAgentHelmConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpConsulAgentHelmConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_agent_helm_config hcp_consul_agent_helm_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpConsulAgentHelmConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpConsulAgentHelmConfigConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get config(): string;
    private _exposeGossipPorts?;
    get exposeGossipPorts(): boolean | cdktn.IResolvable;
    set exposeGossipPorts(value: boolean | cdktn.IResolvable);
    resetExposeGossipPorts(): void;
    get exposeGossipPortsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kubernetesEndpoint?;
    get kubernetesEndpoint(): string;
    set kubernetesEndpoint(value: string);
    get kubernetesEndpointInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataHcpConsulAgentHelmConfigTimeoutsOutputReference;
    putTimeouts(value: DataHcpConsulAgentHelmConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpConsulAgentHelmConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
