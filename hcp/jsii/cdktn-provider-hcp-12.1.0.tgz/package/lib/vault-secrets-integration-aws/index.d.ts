/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsIntegrationAwsConfig extends cdktn.TerraformMetaArguments {
    /**
    * AWS IAM key pair used to authenticate against the target AWS account. Cannot be used with `federated_workload_identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#access_keys VaultSecretsIntegrationAws#access_keys}
    */
    readonly accessKeys?: VaultSecretsIntegrationAwsAccessKeysA;
    /**
    * Capabilities enabled for the integration. See the Vault Secrets documentation for the list of supported capabilities per provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#capabilities VaultSecretsIntegrationAws#capabilities}
    */
    readonly capabilities: string[];
    /**
    * (Recommended) Federated identity configuration to authenticate against the target AWS account. Cannot be used with `access_keys`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#federated_workload_identity VaultSecretsIntegrationAws#federated_workload_identity}
    */
    readonly federatedWorkloadIdentity?: VaultSecretsIntegrationAwsFederatedWorkloadIdentityA;
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#name VaultSecretsIntegrationAws#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#project_id VaultSecretsIntegrationAws#project_id}
    */
    readonly projectId?: string;
}
export interface VaultSecretsIntegrationAwsAccessKeysA {
    /**
    * Key ID used with the secret key to authenticate against the target AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#access_key_id VaultSecretsIntegrationAws#access_key_id}
    */
    readonly accessKeyId: string;
    /**
    * Secret key used with the key ID to authenticate against the target AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#secret_access_key VaultSecretsIntegrationAws#secret_access_key}
    */
    readonly secretAccessKey: string;
}
export declare function vaultSecretsIntegrationAwsAccessKeysAToTerraform(struct?: VaultSecretsIntegrationAwsAccessKeysA | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAwsAccessKeysAToHclTerraform(struct?: VaultSecretsIntegrationAwsAccessKeysA | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAwsAccessKeysAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAwsAccessKeysA | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAwsAccessKeysA | cdktn.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    get secretAccessKeyInput(): string | undefined;
}
export interface VaultSecretsIntegrationAwsFederatedWorkloadIdentityA {
    /**
    * Audience configured on the AWS IAM identity provider to federate access with HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#audience VaultSecretsIntegrationAws#audience}
    */
    readonly audience: string;
    /**
    * AWS IAM role ARN the integration will assume to carry operations for the appropriate capabilities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#role_arn VaultSecretsIntegrationAws#role_arn}
    */
    readonly roleArn: string;
}
export declare function vaultSecretsIntegrationAwsFederatedWorkloadIdentityAToTerraform(struct?: VaultSecretsIntegrationAwsFederatedWorkloadIdentityA | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAwsFederatedWorkloadIdentityAToHclTerraform(struct?: VaultSecretsIntegrationAwsFederatedWorkloadIdentityA | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAwsFederatedWorkloadIdentityAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAwsFederatedWorkloadIdentityA | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAwsFederatedWorkloadIdentityA | cdktn.IResolvable | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    get audienceInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws hcp_vault_secrets_integration_aws}
*/
export declare class VaultSecretsIntegrationAws extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_integration_aws";
    /**
    * Generates CDKTN code for importing a VaultSecretsIntegrationAws resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsIntegrationAws to import
    * @param importFromId The id of the existing VaultSecretsIntegrationAws that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsIntegrationAws to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_integration_aws hcp_vault_secrets_integration_aws} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsIntegrationAwsConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsIntegrationAwsConfig);
    private _accessKeys;
    get accessKeys(): VaultSecretsIntegrationAwsAccessKeysAOutputReference;
    putAccessKeys(value: VaultSecretsIntegrationAwsAccessKeysA): void;
    resetAccessKeys(): void;
    get accessKeysInput(): cdktn.IResolvable | VaultSecretsIntegrationAwsAccessKeysA | undefined;
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _federatedWorkloadIdentity;
    get federatedWorkloadIdentity(): VaultSecretsIntegrationAwsFederatedWorkloadIdentityAOutputReference;
    putFederatedWorkloadIdentity(value: VaultSecretsIntegrationAwsFederatedWorkloadIdentityA): void;
    resetFederatedWorkloadIdentity(): void;
    get federatedWorkloadIdentityInput(): cdktn.IResolvable | VaultSecretsIntegrationAwsFederatedWorkloadIdentityA | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
