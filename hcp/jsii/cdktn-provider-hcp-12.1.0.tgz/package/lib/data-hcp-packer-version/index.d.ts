/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpPackerVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the HCP Packer Bucket where the Version is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/packer_version#bucket_name DataHcpPackerVersion#bucket_name}
    */
    readonly bucketName: string;
    /**
    *
    * The name of the HCP Packer Channel the Version is assigned to.
    * The version currently assigned to the Channel will be fetched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/packer_version#channel_name DataHcpPackerVersion#channel_name}
    */
    readonly channelName: string;
    /**
    * The ID of the HCP Organization where the Version is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/packer_version#project_id DataHcpPackerVersion#project_id}
    */
    readonly projectId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/packer_version hcp_packer_version}
*/
export declare class DataHcpPackerVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_packer_version";
    /**
    * Generates CDKTN code for importing a DataHcpPackerVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpPackerVersion to import
    * @param importFromId The id of the existing DataHcpPackerVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/packer_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpPackerVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/packer_version hcp_packer_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpPackerVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpPackerVersionConfig);
    get authorId(): string;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _channelName?;
    get channelName(): string;
    set channelName(value: string);
    get channelNameInput(): string | undefined;
    get createdAt(): string;
    get fingerprint(): string;
    get id(): string;
    get name(): string;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get revokeAt(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
