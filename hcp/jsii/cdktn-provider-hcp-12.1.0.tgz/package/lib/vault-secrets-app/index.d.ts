/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Vault Secrets App name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_app#app_name VaultSecretsApp#app_name}
    */
    readonly appName: string;
    /**
    * The Vault Secrets app description
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_app#description VaultSecretsApp#description}
    */
    readonly description?: string;
    /**
    * The ID of the HCP project where the HCP Vault Secrets app is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_app#project_id VaultSecretsApp#project_id}
    */
    readonly projectId?: string;
    /**
    * Set of sync names to associate with this app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_app#sync_names VaultSecretsApp#sync_names}
    */
    readonly syncNames?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_app hcp_vault_secrets_app}
*/
export declare class VaultSecretsApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_app";
    /**
    * Generates CDKTN code for importing a VaultSecretsApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsApp to import
    * @param importFromId The id of the existing VaultSecretsApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/vault_secrets_app hcp_vault_secrets_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsAppConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsAppConfig);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceName(): string;
    private _syncNames?;
    get syncNames(): string[];
    set syncNames(value: string[]);
    resetSyncNames(): void;
    get syncNamesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
