/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PackerRunTaskConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#id PackerRunTask#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the HCP Packer Registry is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#project_id PackerRunTask#project_id}
    */
    readonly projectId?: string;
    /**
    * If true, the HMAC Key (`hmac_key`) will be regenerated during `terraform apply`. While set to true, the key will be regenerated on every `terraform apply` until `regenerate_hmac` is set to false or removed from the config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#regenerate_hmac PackerRunTask#regenerate_hmac}
    */
    readonly regenerateHmac?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#timeouts PackerRunTask#timeouts}
    */
    readonly timeouts?: PackerRunTaskTimeouts;
}
export interface PackerRunTaskTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#create PackerRunTask#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#default PackerRunTask#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#delete PackerRunTask#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#update PackerRunTask#update}
    */
    readonly update?: string;
}
export declare function packerRunTaskTimeoutsToTerraform(struct?: PackerRunTaskTimeouts | cdktn.IResolvable): any;
export declare function packerRunTaskTimeoutsToHclTerraform(struct?: PackerRunTaskTimeouts | cdktn.IResolvable): any;
export declare class PackerRunTaskTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PackerRunTaskTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PackerRunTaskTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task hcp_packer_run_task}
*/
export declare class PackerRunTask extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_packer_run_task";
    /**
    * Generates CDKTN code for importing a PackerRunTask resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PackerRunTask to import
    * @param importFromId The id of the existing PackerRunTask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PackerRunTask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/resources/packer_run_task hcp_packer_run_task} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PackerRunTaskConfig = {}
    */
    constructor(scope: Construct, id: string, config?: PackerRunTaskConfig);
    get endpointUrl(): string;
    get hmacKey(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _regenerateHmac?;
    get regenerateHmac(): boolean | cdktn.IResolvable;
    set regenerateHmac(value: boolean | cdktn.IResolvable);
    resetRegenerateHmac(): void;
    get regenerateHmacInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): PackerRunTaskTimeoutsOutputReference;
    putTimeouts(value: PackerRunTaskTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PackerRunTaskTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
