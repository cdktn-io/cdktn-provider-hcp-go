/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpConsulClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Consul cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster#cluster_id DataHcpConsulCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster#id DataHcpConsulCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the HCP Consul cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster#project_id DataHcpConsulCluster#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster#timeouts DataHcpConsulCluster#timeouts}
    */
    readonly timeouts?: DataHcpConsulClusterTimeouts;
}
export interface DataHcpConsulClusterIpAllowlistStruct {
}
export declare function dataHcpConsulClusterIpAllowlistStructToTerraform(struct?: DataHcpConsulClusterIpAllowlistStruct): any;
export declare function dataHcpConsulClusterIpAllowlistStructToHclTerraform(struct?: DataHcpConsulClusterIpAllowlistStruct): any;
export declare class DataHcpConsulClusterIpAllowlistStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpConsulClusterIpAllowlistStruct | undefined;
    set internalValue(value: DataHcpConsulClusterIpAllowlistStruct | undefined);
    get address(): string;
    get description(): string;
}
export declare class DataHcpConsulClusterIpAllowlistStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpConsulClusterIpAllowlistStructOutputReference;
}
export interface DataHcpConsulClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster#default DataHcpConsulCluster#default}
    */
    readonly default?: string;
}
export declare function dataHcpConsulClusterTimeoutsToTerraform(struct?: DataHcpConsulClusterTimeouts | cdktn.IResolvable): any;
export declare function dataHcpConsulClusterTimeoutsToHclTerraform(struct?: DataHcpConsulClusterTimeouts | cdktn.IResolvable): any;
export declare class DataHcpConsulClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpConsulClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpConsulClusterTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster hcp_consul_cluster}
*/
export declare class DataHcpConsulCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_consul_cluster";
    /**
    * Generates CDKTN code for importing a DataHcpConsulCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpConsulCluster to import
    * @param importFromId The id of the existing DataHcpConsulCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpConsulCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.112.0/docs/data-sources/consul_cluster hcp_consul_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpConsulClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpConsulClusterConfig);
    get autoHvnToHvnPeering(): cdktn.IResolvable;
    get cloudProvider(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get connectEnabled(): cdktn.IResolvable;
    get consulAutomaticUpgrades(): cdktn.IResolvable;
    get consulCaFile(): string;
    get consulConfigFile(): string;
    get consulPrivateEndpointUrl(): string;
    get consulPublicEndpointUrl(): string;
    get consulSnapshotInterval(): string;
    get consulSnapshotRetention(): string;
    get consulVersion(): string;
    get datacenter(): string;
    get hvnId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAllowlist;
    get ipAllowlist(): DataHcpConsulClusterIpAllowlistStructList;
    get organizationId(): string;
    get primaryLink(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get publicEndpoint(): cdktn.IResolvable;
    get region(): string;
    get scale(): number;
    get selfLink(): string;
    get size(): string;
    get state(): string;
    get tier(): string;
    private _timeouts;
    get timeouts(): DataHcpConsulClusterTimeoutsOutputReference;
    putTimeouts(value: DataHcpConsulClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpConsulClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
