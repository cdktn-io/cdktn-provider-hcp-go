/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultRadarSecretManagerVaultDedicatedConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates if the auth method has read and write access to the secrets engine. Defaults to false. Set this to true if you want to copy secrets to this secret manager as part of remediation process. (see https://developer.hashicorp.com/hcp/docs/vault-radar/remediate-secrets/copy-secrets)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#access_read_write VaultRadarSecretManagerVaultDedicated#access_read_write}
    */
    readonly accessReadWrite?: boolean | cdktn.IResolvable;
    /**
    * Configuration for AppRole Push-based authentication. Only one authentication method may be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#approle_push VaultRadarSecretManagerVaultDedicated#approle_push}
    */
    readonly approlePush?: VaultRadarSecretManagerVaultDedicatedApprolePush;
    /**
    * Configuration for Kubernetes-based authentication. Only one authentication method may be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#kubernetes VaultRadarSecretManagerVaultDedicated#kubernetes}
    */
    readonly kubernetes?: VaultRadarSecretManagerVaultDedicatedKubernetes;
    /**
    * The ID of the HCP project where Vault Radar is located. If not specified, the project specified in the HCP Provider config block will be used, if configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#project_id VaultRadarSecretManagerVaultDedicated#project_id}
    */
    readonly projectId?: string;
    /**
    * Configuration for token-based authentication. Only one authentication method may be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token VaultRadarSecretManagerVaultDedicated#token}
    */
    readonly token?: VaultRadarSecretManagerVaultDedicatedToken;
    /**
    * Specify the URL of the Vault instance without protocol. Example: 'acme-public-vault-abc.def.z1.hashicorp.cloud:8200'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#vault_url VaultRadarSecretManagerVaultDedicated#vault_url}
    */
    readonly vaultUrl: string;
}
export interface VaultRadarSecretManagerVaultDedicatedApprolePush {
    /**
    * Mount path of the AppRole auth method in Vault. Example 'approle'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
    */
    readonly mountPath: string;
    /**
    * Environment variable containing the AppRole role ID. Example: 'VAULT_APPROLE_ROLE_ID'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_id_env_var VaultRadarSecretManagerVaultDedicated#role_id_env_var}
    */
    readonly roleIdEnvVar: string;
    /**
    * Environment variable containing the AppRole secret ID. Example: 'VAULT_APPROLE_SECRET_ID'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#secret_id_env_var VaultRadarSecretManagerVaultDedicated#secret_id_env_var}
    */
    readonly secretIdEnvVar: string;
}
export declare function vaultRadarSecretManagerVaultDedicatedApprolePushToTerraform(struct?: VaultRadarSecretManagerVaultDedicatedApprolePush | cdktn.IResolvable): any;
export declare function vaultRadarSecretManagerVaultDedicatedApprolePushToHclTerraform(struct?: VaultRadarSecretManagerVaultDedicatedApprolePush | cdktn.IResolvable): any;
export declare class VaultRadarSecretManagerVaultDedicatedApprolePushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultRadarSecretManagerVaultDedicatedApprolePush | cdktn.IResolvable | undefined;
    set internalValue(value: VaultRadarSecretManagerVaultDedicatedApprolePush | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _roleIdEnvVar?;
    get roleIdEnvVar(): string;
    set roleIdEnvVar(value: string);
    get roleIdEnvVarInput(): string | undefined;
    private _secretIdEnvVar?;
    get secretIdEnvVar(): string;
    set secretIdEnvVar(value: string);
    get secretIdEnvVarInput(): string | undefined;
}
export interface VaultRadarSecretManagerVaultDedicatedKubernetes {
    /**
    * Mount path where the Kubernetes auth method is enabled in Vault. Example 'kubernetes'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
    */
    readonly mountPath: string;
    /**
    * Kubernetes authentication role configured in Vault.  Example 'vault-radar-role'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_name VaultRadarSecretManagerVaultDedicated#role_name}
    */
    readonly roleName: string;
}
export declare function vaultRadarSecretManagerVaultDedicatedKubernetesToTerraform(struct?: VaultRadarSecretManagerVaultDedicatedKubernetes | cdktn.IResolvable): any;
export declare function vaultRadarSecretManagerVaultDedicatedKubernetesToHclTerraform(struct?: VaultRadarSecretManagerVaultDedicatedKubernetes | cdktn.IResolvable): any;
export declare class VaultRadarSecretManagerVaultDedicatedKubernetesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultRadarSecretManagerVaultDedicatedKubernetes | cdktn.IResolvable | undefined;
    set internalValue(value: VaultRadarSecretManagerVaultDedicatedKubernetes | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    get roleNameInput(): string | undefined;
}
export interface VaultRadarSecretManagerVaultDedicatedToken {
    /**
    * Environment variable name containing the Vault token. Example: 'VAULT_TOKEN'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token_env_var VaultRadarSecretManagerVaultDedicated#token_env_var}
    */
    readonly tokenEnvVar: string;
}
export declare function vaultRadarSecretManagerVaultDedicatedTokenToTerraform(struct?: VaultRadarSecretManagerVaultDedicatedToken | cdktn.IResolvable): any;
export declare function vaultRadarSecretManagerVaultDedicatedTokenToHclTerraform(struct?: VaultRadarSecretManagerVaultDedicatedToken | cdktn.IResolvable): any;
export declare class VaultRadarSecretManagerVaultDedicatedTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultRadarSecretManagerVaultDedicatedToken | cdktn.IResolvable | undefined;
    set internalValue(value: VaultRadarSecretManagerVaultDedicatedToken | cdktn.IResolvable | undefined);
    private _tokenEnvVar?;
    get tokenEnvVar(): string;
    set tokenEnvVar(value: string);
    get tokenEnvVarInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated hcp_vault_radar_secret_manager_vault_dedicated}
*/
export declare class VaultRadarSecretManagerVaultDedicated extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_radar_secret_manager_vault_dedicated";
    /**
    * Generates CDKTN code for importing a VaultRadarSecretManagerVaultDedicated resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultRadarSecretManagerVaultDedicated to import
    * @param importFromId The id of the existing VaultRadarSecretManagerVaultDedicated that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultRadarSecretManagerVaultDedicated to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated hcp_vault_radar_secret_manager_vault_dedicated} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultRadarSecretManagerVaultDedicatedConfig
    */
    constructor(scope: Construct, id: string, config: VaultRadarSecretManagerVaultDedicatedConfig);
    private _accessReadWrite?;
    get accessReadWrite(): boolean | cdktn.IResolvable;
    set accessReadWrite(value: boolean | cdktn.IResolvable);
    resetAccessReadWrite(): void;
    get accessReadWriteInput(): boolean | cdktn.IResolvable | undefined;
    private _approlePush;
    get approlePush(): VaultRadarSecretManagerVaultDedicatedApprolePushOutputReference;
    putApprolePush(value: VaultRadarSecretManagerVaultDedicatedApprolePush): void;
    resetApprolePush(): void;
    get approlePushInput(): cdktn.IResolvable | VaultRadarSecretManagerVaultDedicatedApprolePush | undefined;
    get id(): string;
    private _kubernetes;
    get kubernetes(): VaultRadarSecretManagerVaultDedicatedKubernetesOutputReference;
    putKubernetes(value: VaultRadarSecretManagerVaultDedicatedKubernetes): void;
    resetKubernetes(): void;
    get kubernetesInput(): cdktn.IResolvable | VaultRadarSecretManagerVaultDedicatedKubernetes | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _token;
    get token(): VaultRadarSecretManagerVaultDedicatedTokenOutputReference;
    putToken(value: VaultRadarSecretManagerVaultDedicatedToken): void;
    resetToken(): void;
    get tokenInput(): cdktn.IResolvable | VaultRadarSecretManagerVaultDedicatedToken | undefined;
    private _vaultUrl?;
    get vaultUrl(): string;
    set vaultUrl(value: string);
    get vaultUrlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
