/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsSyncConfig extends cdktn.TerraformMetaArguments {
    /**
    * Configuration parameters used to determine the sync destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#gitlab_config VaultSecretsSync#gitlab_config}
    */
    readonly gitlabConfig?: VaultSecretsSyncGitlabConfig;
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#integration_name VaultSecretsSync#integration_name}
    */
    readonly integrationName: string;
    /**
    * The Vault Secrets Sync name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#name VaultSecretsSync#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#project_id VaultSecretsSync#project_id}
    */
    readonly projectId?: string;
}
export interface VaultSecretsSyncGitlabConfig {
    /**
    * ID of the group, if the scope is GROUP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#group_id VaultSecretsSync#group_id}
    */
    readonly groupId?: string;
    /**
    * ID of the project, if the scope is PROJECT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#project_id VaultSecretsSync#project_id}
    */
    readonly projectId?: string;
    /**
    * The scope to which sync applies. Defaults to GROUP. The valid options are GROUP and PROJECT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#scope VaultSecretsSync#scope}
    */
    readonly scope?: string;
}
export declare function vaultSecretsSyncGitlabConfigToTerraform(struct?: VaultSecretsSyncGitlabConfig | cdktn.IResolvable): any;
export declare function vaultSecretsSyncGitlabConfigToHclTerraform(struct?: VaultSecretsSyncGitlabConfig | cdktn.IResolvable): any;
export declare class VaultSecretsSyncGitlabConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsSyncGitlabConfig | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsSyncGitlabConfig | cdktn.IResolvable | undefined);
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync hcp_vault_secrets_sync}
*/
export declare class VaultSecretsSync extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_sync";
    /**
    * Generates CDKTN code for importing a VaultSecretsSync resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsSync to import
    * @param importFromId The id of the existing VaultSecretsSync that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsSync to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_sync hcp_vault_secrets_sync} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsSyncConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsSyncConfig);
    private _gitlabConfig;
    get gitlabConfig(): VaultSecretsSyncGitlabConfigOutputReference;
    putGitlabConfig(value: VaultSecretsSyncGitlabConfig): void;
    resetGitlabConfig(): void;
    get gitlabConfigInput(): cdktn.IResolvable | VaultSecretsSyncGitlabConfig | undefined;
    private _integrationName?;
    get integrationName(): string;
    set integrationName(value: string);
    get integrationNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
