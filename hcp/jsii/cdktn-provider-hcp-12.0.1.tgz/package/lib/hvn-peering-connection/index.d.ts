/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HvnPeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique URL of one of the HVNs being peered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#hvn_1 HvnPeeringConnection#hvn_1}
    */
    readonly hvn1: string;
    /**
    * The unique URL of one of the HVNs being peered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#hvn_2 HvnPeeringConnection#hvn_2}
    */
    readonly hvn2: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#id HvnPeeringConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the HCP project where HVN peering connection is located. Always matches hvn_1's project ID. Setting this attribute is deprecated, but it will remain usable in read-only form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#project_id HvnPeeringConnection#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#timeouts HvnPeeringConnection#timeouts}
    */
    readonly timeouts?: HvnPeeringConnectionTimeouts;
}
export interface HvnPeeringConnectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#create HvnPeeringConnection#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#default HvnPeeringConnection#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#delete HvnPeeringConnection#delete}
    */
    readonly delete?: string;
}
export declare function hvnPeeringConnectionTimeoutsToTerraform(struct?: HvnPeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare function hvnPeeringConnectionTimeoutsToHclTerraform(struct?: HvnPeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare class HvnPeeringConnectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HvnPeeringConnectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: HvnPeeringConnectionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection hcp_hvn_peering_connection}
*/
export declare class HvnPeeringConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_hvn_peering_connection";
    /**
    * Generates CDKTN code for importing a HvnPeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HvnPeeringConnection to import
    * @param importFromId The id of the existing HvnPeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HvnPeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/hvn_peering_connection hcp_hvn_peering_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HvnPeeringConnectionConfig
    */
    constructor(scope: Construct, id: string, config: HvnPeeringConnectionConfig);
    get createdAt(): string;
    get expiresAt(): string;
    private _hvn1?;
    get hvn1(): string;
    set hvn1(value: string);
    get hvn1Input(): string | undefined;
    private _hvn2?;
    get hvn2(): string;
    set hvn2(value: string);
    get hvn2Input(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    get peeringId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    private _timeouts;
    get timeouts(): HvnPeeringConnectionTimeoutsOutputReference;
    putTimeouts(value: HvnPeeringConnectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | HvnPeeringConnectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
