/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpHvnPeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique URL of one of the HVNs being peered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#hvn_1 DataHcpHvnPeeringConnection#hvn_1}
    */
    readonly hvn1: string;
    /**
    * The unique URL of one of the HVNs being peered. Setting this attribute is deprecated, but it will remain usable in read-only form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#hvn_2 DataHcpHvnPeeringConnection#hvn_2}
    */
    readonly hvn2?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#id DataHcpHvnPeeringConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the peering connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#peering_id DataHcpHvnPeeringConnection#peering_id}
    */
    readonly peeringId: string;
    /**
    * The ID of the HCP project where the HVN peering connection is located. Always matches hvn_1's project ID. Setting this attribute is deprecated, but it will remain usable in read-only form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#project_id DataHcpHvnPeeringConnection#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#timeouts DataHcpHvnPeeringConnection#timeouts}
    */
    readonly timeouts?: DataHcpHvnPeeringConnectionTimeouts;
}
export interface DataHcpHvnPeeringConnectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#default DataHcpHvnPeeringConnection#default}
    */
    readonly default?: string;
}
export declare function dataHcpHvnPeeringConnectionTimeoutsToTerraform(struct?: DataHcpHvnPeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare function dataHcpHvnPeeringConnectionTimeoutsToHclTerraform(struct?: DataHcpHvnPeeringConnectionTimeouts | cdktn.IResolvable): any;
export declare class DataHcpHvnPeeringConnectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpHvnPeeringConnectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpHvnPeeringConnectionTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection hcp_hvn_peering_connection}
*/
export declare class DataHcpHvnPeeringConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_hvn_peering_connection";
    /**
    * Generates CDKTN code for importing a DataHcpHvnPeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpHvnPeeringConnection to import
    * @param importFromId The id of the existing DataHcpHvnPeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpHvnPeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/hvn_peering_connection hcp_hvn_peering_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpHvnPeeringConnectionConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpHvnPeeringConnectionConfig);
    get createdAt(): string;
    get expiresAt(): string;
    private _hvn1?;
    get hvn1(): string;
    set hvn1(value: string);
    get hvn1Input(): string | undefined;
    private _hvn2?;
    get hvn2(): string;
    set hvn2(value: string);
    resetHvn2(): void;
    get hvn2Input(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _peeringId?;
    get peeringId(): string;
    set peeringId(value: string);
    get peeringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    private _timeouts;
    get timeouts(): DataHcpHvnPeeringConnectionTimeoutsOutputReference;
    putTimeouts(value: DataHcpHvnPeeringConnectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpHvnPeeringConnectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
