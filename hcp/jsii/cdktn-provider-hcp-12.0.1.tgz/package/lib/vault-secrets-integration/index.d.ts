/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * AWS IAM key pair used to authenticate against the target AWS account. Cannot be used with `federated_workload_identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#aws_access_keys VaultSecretsIntegration#aws_access_keys}
    */
    readonly awsAccessKeys?: VaultSecretsIntegrationAwsAccessKeys;
    /**
    * (Recommended) Federated identity configuration to authenticate against the target AWS account. Cannot be used with `access_keys`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#aws_federated_workload_identity VaultSecretsIntegration#aws_federated_workload_identity}
    */
    readonly awsFederatedWorkloadIdentity?: VaultSecretsIntegrationAwsFederatedWorkloadIdentity;
    /**
    * Azure client secret used to authenticate against the target Azure application. Cannot be used with `federated_workload_identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#azure_client_secret VaultSecretsIntegration#azure_client_secret}
    */
    readonly azureClientSecret?: VaultSecretsIntegrationAzureClientSecret;
    /**
    * (Recommended) Federated identity configuration to authenticate against the target Azure application. Cannot be used with `client_secret`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#azure_federated_workload_identity VaultSecretsIntegration#azure_federated_workload_identity}
    */
    readonly azureFederatedWorkloadIdentity?: VaultSecretsIntegrationAzureFederatedWorkloadIdentity;
    /**
    * Capabilities enabled for the integration. See the Vault Secrets documentation for the list of supported capabilities per provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#capabilities VaultSecretsIntegration#capabilities}
    */
    readonly capabilities: string[];
    /**
    * Confluent API key used to authenticate for cloud apis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#confluent_static_credentials VaultSecretsIntegration#confluent_static_credentials}
    */
    readonly confluentStaticCredentials?: VaultSecretsIntegrationConfluentStaticCredentials;
    /**
    * (Recommended) Federated identity configuration to authenticate against the target GCP project. Cannot be used with `service_account_key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#gcp_federated_workload_identity VaultSecretsIntegration#gcp_federated_workload_identity}
    */
    readonly gcpFederatedWorkloadIdentity?: VaultSecretsIntegrationGcpFederatedWorkloadIdentity;
    /**
    * GCP service account key used to authenticate against the target GCP project. Cannot be used with `federated_workload_identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#gcp_service_account_key VaultSecretsIntegration#gcp_service_account_key}
    */
    readonly gcpServiceAccountKey?: VaultSecretsIntegrationGcpServiceAccountKey;
    /**
    * GitLab access token used to authenticate against the target GitLab account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#gitlab_access VaultSecretsIntegration#gitlab_access}
    */
    readonly gitlabAccess?: VaultSecretsIntegrationGitlabAccess;
    /**
    * MongoDB Atlas API key used to authenticate against the target project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#mongodb_atlas_static_credentials VaultSecretsIntegration#mongodb_atlas_static_credentials}
    */
    readonly mongodbAtlasStaticCredentials?: VaultSecretsIntegrationMongodbAtlasStaticCredentials;
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#name VaultSecretsIntegration#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#project_id VaultSecretsIntegration#project_id}
    */
    readonly projectId?: string;
    /**
    * The provider or 3rd party platform the integration is for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#provider_type VaultSecretsIntegration#provider_type}
    */
    readonly providerType: string;
    /**
    * Twilio API key parts used to authenticate against the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#twilio_static_credentials VaultSecretsIntegration#twilio_static_credentials}
    */
    readonly twilioStaticCredentials?: VaultSecretsIntegrationTwilioStaticCredentials;
}
export interface VaultSecretsIntegrationAwsAccessKeys {
    /**
    * Key ID used with the secret key to authenticate against the target AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#access_key_id VaultSecretsIntegration#access_key_id}
    */
    readonly accessKeyId: string;
    /**
    * Secret key used with the key ID to authenticate against the target AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#secret_access_key VaultSecretsIntegration#secret_access_key}
    */
    readonly secretAccessKey: string;
}
export declare function vaultSecretsIntegrationAwsAccessKeysToTerraform(struct?: VaultSecretsIntegrationAwsAccessKeys | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAwsAccessKeysToHclTerraform(struct?: VaultSecretsIntegrationAwsAccessKeys | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAwsAccessKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAwsAccessKeys | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAwsAccessKeys | cdktn.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    get secretAccessKeyInput(): string | undefined;
}
export interface VaultSecretsIntegrationAwsFederatedWorkloadIdentity {
    /**
    * Audience configured on the AWS IAM identity provider to federate access with HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#audience VaultSecretsIntegration#audience}
    */
    readonly audience: string;
    /**
    * AWS IAM role ARN the integration will assume to carry operations for the appropriate capabilities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#role_arn VaultSecretsIntegration#role_arn}
    */
    readonly roleArn: string;
}
export declare function vaultSecretsIntegrationAwsFederatedWorkloadIdentityToTerraform(struct?: VaultSecretsIntegrationAwsFederatedWorkloadIdentity | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAwsFederatedWorkloadIdentityToHclTerraform(struct?: VaultSecretsIntegrationAwsFederatedWorkloadIdentity | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAwsFederatedWorkloadIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAwsFederatedWorkloadIdentity | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAwsFederatedWorkloadIdentity | cdktn.IResolvable | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    get audienceInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface VaultSecretsIntegrationAzureClientSecret {
    /**
    * Azure client ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#client_id VaultSecretsIntegration#client_id}
    */
    readonly clientId: string;
    /**
    * Secret value corresponding to the Azure client secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#client_secret VaultSecretsIntegration#client_secret}
    */
    readonly clientSecret: string;
    /**
    * Azure tenant ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#tenant_id VaultSecretsIntegration#tenant_id}
    */
    readonly tenantId: string;
}
export declare function vaultSecretsIntegrationAzureClientSecretToTerraform(struct?: VaultSecretsIntegrationAzureClientSecret | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAzureClientSecretToHclTerraform(struct?: VaultSecretsIntegrationAzureClientSecret | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAzureClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAzureClientSecret | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAzureClientSecret | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
}
export interface VaultSecretsIntegrationAzureFederatedWorkloadIdentity {
    /**
    * Audience configured on the Azure federated identity credentials to federate access with HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#audience VaultSecretsIntegration#audience}
    */
    readonly audience: string;
    /**
    * Azure client ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#client_id VaultSecretsIntegration#client_id}
    */
    readonly clientId: string;
    /**
    * Azure tenant ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#tenant_id VaultSecretsIntegration#tenant_id}
    */
    readonly tenantId: string;
}
export declare function vaultSecretsIntegrationAzureFederatedWorkloadIdentityToTerraform(struct?: VaultSecretsIntegrationAzureFederatedWorkloadIdentity | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAzureFederatedWorkloadIdentityToHclTerraform(struct?: VaultSecretsIntegrationAzureFederatedWorkloadIdentity | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAzureFederatedWorkloadIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAzureFederatedWorkloadIdentity | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAzureFederatedWorkloadIdentity | cdktn.IResolvable | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    get audienceInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
}
export interface VaultSecretsIntegrationConfluentStaticCredentials {
    /**
    * Public key used alongside the private key to authenticate for cloud apis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#cloud_api_key_id VaultSecretsIntegration#cloud_api_key_id}
    */
    readonly cloudApiKeyId: string;
    /**
    * Private key used alongside the public key to authenticate for cloud apis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#cloud_api_secret VaultSecretsIntegration#cloud_api_secret}
    */
    readonly cloudApiSecret: string;
}
export declare function vaultSecretsIntegrationConfluentStaticCredentialsToTerraform(struct?: VaultSecretsIntegrationConfluentStaticCredentials | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationConfluentStaticCredentialsToHclTerraform(struct?: VaultSecretsIntegrationConfluentStaticCredentials | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationConfluentStaticCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationConfluentStaticCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationConfluentStaticCredentials | cdktn.IResolvable | undefined);
    private _cloudApiKeyId?;
    get cloudApiKeyId(): string;
    set cloudApiKeyId(value: string);
    get cloudApiKeyIdInput(): string | undefined;
    private _cloudApiSecret?;
    get cloudApiSecret(): string;
    set cloudApiSecret(value: string);
    get cloudApiSecretInput(): string | undefined;
}
export interface VaultSecretsIntegrationGcpFederatedWorkloadIdentity {
    /**
    * Audience configured on the GCP identity provider to federate access with HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#audience VaultSecretsIntegration#audience}
    */
    readonly audience: string;
    /**
    * GCP service account email that HVS will impersonate to carry operations for the appropriate capabilities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#service_account_email VaultSecretsIntegration#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function vaultSecretsIntegrationGcpFederatedWorkloadIdentityToTerraform(struct?: VaultSecretsIntegrationGcpFederatedWorkloadIdentity | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationGcpFederatedWorkloadIdentityToHclTerraform(struct?: VaultSecretsIntegrationGcpFederatedWorkloadIdentity | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationGcpFederatedWorkloadIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationGcpFederatedWorkloadIdentity | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationGcpFederatedWorkloadIdentity | cdktn.IResolvable | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    get audienceInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
export interface VaultSecretsIntegrationGcpServiceAccountKey {
    /**
    * JSON or base64 encoded service account key received from GCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#credentials VaultSecretsIntegration#credentials}
    */
    readonly credentials: string;
}
export declare function vaultSecretsIntegrationGcpServiceAccountKeyToTerraform(struct?: VaultSecretsIntegrationGcpServiceAccountKey | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationGcpServiceAccountKeyToHclTerraform(struct?: VaultSecretsIntegrationGcpServiceAccountKey | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationGcpServiceAccountKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationGcpServiceAccountKey | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationGcpServiceAccountKey | cdktn.IResolvable | undefined);
    get clientEmail(): string;
    private _credentials?;
    get credentials(): string;
    set credentials(value: string);
    get credentialsInput(): string | undefined;
    get projectId(): string;
}
export interface VaultSecretsIntegrationGitlabAccess {
    /**
    * Access token used to authenticate against the target GitLab account. This token must have privilege to create CI/CD variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#token VaultSecretsIntegration#token}
    */
    readonly token: string;
}
export declare function vaultSecretsIntegrationGitlabAccessToTerraform(struct?: VaultSecretsIntegrationGitlabAccess | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationGitlabAccessToHclTerraform(struct?: VaultSecretsIntegrationGitlabAccess | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationGitlabAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationGitlabAccess | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationGitlabAccess | cdktn.IResolvable | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
export interface VaultSecretsIntegrationMongodbAtlasStaticCredentials {
    /**
    * Private key used alongside the public key to authenticate against the target project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#api_private_key VaultSecretsIntegration#api_private_key}
    */
    readonly apiPrivateKey: string;
    /**
    * Public key used alongside the private key to authenticate against the target project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#api_public_key VaultSecretsIntegration#api_public_key}
    */
    readonly apiPublicKey: string;
}
export declare function vaultSecretsIntegrationMongodbAtlasStaticCredentialsToTerraform(struct?: VaultSecretsIntegrationMongodbAtlasStaticCredentials | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationMongodbAtlasStaticCredentialsToHclTerraform(struct?: VaultSecretsIntegrationMongodbAtlasStaticCredentials | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationMongodbAtlasStaticCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationMongodbAtlasStaticCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationMongodbAtlasStaticCredentials | cdktn.IResolvable | undefined);
    private _apiPrivateKey?;
    get apiPrivateKey(): string;
    set apiPrivateKey(value: string);
    get apiPrivateKeyInput(): string | undefined;
    private _apiPublicKey?;
    get apiPublicKey(): string;
    set apiPublicKey(value: string);
    get apiPublicKeyInput(): string | undefined;
}
export interface VaultSecretsIntegrationTwilioStaticCredentials {
    /**
    * Account SID for the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#account_sid VaultSecretsIntegration#account_sid}
    */
    readonly accountSid: string;
    /**
    * Api key secret used with the api key SID to authenticate against the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#api_key_secret VaultSecretsIntegration#api_key_secret}
    */
    readonly apiKeySecret: string;
    /**
    * Api key SID to authenticate against the target Twilio account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#api_key_sid VaultSecretsIntegration#api_key_sid}
    */
    readonly apiKeySid: string;
}
export declare function vaultSecretsIntegrationTwilioStaticCredentialsToTerraform(struct?: VaultSecretsIntegrationTwilioStaticCredentials | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationTwilioStaticCredentialsToHclTerraform(struct?: VaultSecretsIntegrationTwilioStaticCredentials | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationTwilioStaticCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationTwilioStaticCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationTwilioStaticCredentials | cdktn.IResolvable | undefined);
    private _accountSid?;
    get accountSid(): string;
    set accountSid(value: string);
    get accountSidInput(): string | undefined;
    private _apiKeySecret?;
    get apiKeySecret(): string;
    set apiKeySecret(value: string);
    get apiKeySecretInput(): string | undefined;
    private _apiKeySid?;
    get apiKeySid(): string;
    set apiKeySid(value: string);
    get apiKeySidInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration hcp_vault_secrets_integration}
*/
export declare class VaultSecretsIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_integration";
    /**
    * Generates CDKTN code for importing a VaultSecretsIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsIntegration to import
    * @param importFromId The id of the existing VaultSecretsIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_secrets_integration hcp_vault_secrets_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsIntegrationConfig);
    private _awsAccessKeys;
    get awsAccessKeys(): VaultSecretsIntegrationAwsAccessKeysOutputReference;
    putAwsAccessKeys(value: VaultSecretsIntegrationAwsAccessKeys): void;
    resetAwsAccessKeys(): void;
    get awsAccessKeysInput(): cdktn.IResolvable | VaultSecretsIntegrationAwsAccessKeys | undefined;
    private _awsFederatedWorkloadIdentity;
    get awsFederatedWorkloadIdentity(): VaultSecretsIntegrationAwsFederatedWorkloadIdentityOutputReference;
    putAwsFederatedWorkloadIdentity(value: VaultSecretsIntegrationAwsFederatedWorkloadIdentity): void;
    resetAwsFederatedWorkloadIdentity(): void;
    get awsFederatedWorkloadIdentityInput(): cdktn.IResolvable | VaultSecretsIntegrationAwsFederatedWorkloadIdentity | undefined;
    private _azureClientSecret;
    get azureClientSecret(): VaultSecretsIntegrationAzureClientSecretOutputReference;
    putAzureClientSecret(value: VaultSecretsIntegrationAzureClientSecret): void;
    resetAzureClientSecret(): void;
    get azureClientSecretInput(): cdktn.IResolvable | VaultSecretsIntegrationAzureClientSecret | undefined;
    private _azureFederatedWorkloadIdentity;
    get azureFederatedWorkloadIdentity(): VaultSecretsIntegrationAzureFederatedWorkloadIdentityOutputReference;
    putAzureFederatedWorkloadIdentity(value: VaultSecretsIntegrationAzureFederatedWorkloadIdentity): void;
    resetAzureFederatedWorkloadIdentity(): void;
    get azureFederatedWorkloadIdentityInput(): cdktn.IResolvable | VaultSecretsIntegrationAzureFederatedWorkloadIdentity | undefined;
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _confluentStaticCredentials;
    get confluentStaticCredentials(): VaultSecretsIntegrationConfluentStaticCredentialsOutputReference;
    putConfluentStaticCredentials(value: VaultSecretsIntegrationConfluentStaticCredentials): void;
    resetConfluentStaticCredentials(): void;
    get confluentStaticCredentialsInput(): cdktn.IResolvable | VaultSecretsIntegrationConfluentStaticCredentials | undefined;
    private _gcpFederatedWorkloadIdentity;
    get gcpFederatedWorkloadIdentity(): VaultSecretsIntegrationGcpFederatedWorkloadIdentityOutputReference;
    putGcpFederatedWorkloadIdentity(value: VaultSecretsIntegrationGcpFederatedWorkloadIdentity): void;
    resetGcpFederatedWorkloadIdentity(): void;
    get gcpFederatedWorkloadIdentityInput(): cdktn.IResolvable | VaultSecretsIntegrationGcpFederatedWorkloadIdentity | undefined;
    private _gcpServiceAccountKey;
    get gcpServiceAccountKey(): VaultSecretsIntegrationGcpServiceAccountKeyOutputReference;
    putGcpServiceAccountKey(value: VaultSecretsIntegrationGcpServiceAccountKey): void;
    resetGcpServiceAccountKey(): void;
    get gcpServiceAccountKeyInput(): cdktn.IResolvable | VaultSecretsIntegrationGcpServiceAccountKey | undefined;
    private _gitlabAccess;
    get gitlabAccess(): VaultSecretsIntegrationGitlabAccessOutputReference;
    putGitlabAccess(value: VaultSecretsIntegrationGitlabAccess): void;
    resetGitlabAccess(): void;
    get gitlabAccessInput(): cdktn.IResolvable | VaultSecretsIntegrationGitlabAccess | undefined;
    private _mongodbAtlasStaticCredentials;
    get mongodbAtlasStaticCredentials(): VaultSecretsIntegrationMongodbAtlasStaticCredentialsOutputReference;
    putMongodbAtlasStaticCredentials(value: VaultSecretsIntegrationMongodbAtlasStaticCredentials): void;
    resetMongodbAtlasStaticCredentials(): void;
    get mongodbAtlasStaticCredentialsInput(): cdktn.IResolvable | VaultSecretsIntegrationMongodbAtlasStaticCredentials | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    get providerTypeInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    private _twilioStaticCredentials;
    get twilioStaticCredentials(): VaultSecretsIntegrationTwilioStaticCredentialsOutputReference;
    putTwilioStaticCredentials(value: VaultSecretsIntegrationTwilioStaticCredentials): void;
    resetTwilioStaticCredentials(): void;
    get twilioStaticCredentialsInput(): cdktn.IResolvable | VaultSecretsIntegrationTwilioStaticCredentials | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
