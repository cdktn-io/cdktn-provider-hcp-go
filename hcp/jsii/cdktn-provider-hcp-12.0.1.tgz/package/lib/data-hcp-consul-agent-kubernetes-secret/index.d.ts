/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpConsulAgentKubernetesSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Consul cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret#cluster_id DataHcpConsulAgentKubernetesSecret#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret#id DataHcpConsulAgentKubernetesSecret#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the HCP Consul cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret#project_id DataHcpConsulAgentKubernetesSecret#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret#timeouts DataHcpConsulAgentKubernetesSecret#timeouts}
    */
    readonly timeouts?: DataHcpConsulAgentKubernetesSecretTimeouts;
}
export interface DataHcpConsulAgentKubernetesSecretTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret#default DataHcpConsulAgentKubernetesSecret#default}
    */
    readonly default?: string;
}
export declare function dataHcpConsulAgentKubernetesSecretTimeoutsToTerraform(struct?: DataHcpConsulAgentKubernetesSecretTimeouts | cdktn.IResolvable): any;
export declare function dataHcpConsulAgentKubernetesSecretTimeoutsToHclTerraform(struct?: DataHcpConsulAgentKubernetesSecretTimeouts | cdktn.IResolvable): any;
export declare class DataHcpConsulAgentKubernetesSecretTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpConsulAgentKubernetesSecretTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpConsulAgentKubernetesSecretTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret hcp_consul_agent_kubernetes_secret}
*/
export declare class DataHcpConsulAgentKubernetesSecret extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_consul_agent_kubernetes_secret";
    /**
    * Generates CDKTN code for importing a DataHcpConsulAgentKubernetesSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpConsulAgentKubernetesSecret to import
    * @param importFromId The id of the existing DataHcpConsulAgentKubernetesSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpConsulAgentKubernetesSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/consul_agent_kubernetes_secret hcp_consul_agent_kubernetes_secret} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpConsulAgentKubernetesSecretConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpConsulAgentKubernetesSecretConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get secret(): string;
    private _timeouts;
    get timeouts(): DataHcpConsulAgentKubernetesSecretTimeoutsOutputReference;
    putTimeouts(value: DataHcpConsulAgentKubernetesSecretTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpConsulAgentKubernetesSecretTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
