/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaypointTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of actions by 'ID' to assign to this Template. Applications created from this Template will have these actions assigned to them. Only 'ID' is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#actions WaypointTemplate#actions}
    */
    readonly actions?: string[];
    /**
    * A description of the template, along with when and why it should be used, up to 500 characters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#description WaypointTemplate#description}
    */
    readonly description?: string;
    /**
    * List of labels attached to this Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#labels WaypointTemplate#labels}
    */
    readonly labels?: string[];
    /**
    * The name of the Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#name WaypointTemplate#name}
    */
    readonly name: string;
    /**
    * The ID of the HCP project where the Waypoint Template is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#project_id WaypointTemplate#project_id}
    */
    readonly projectId?: string;
    /**
    * Instructions for using the template (markdown format supported).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#readme_markdown_template WaypointTemplate#readme_markdown_template}
    */
    readonly readmeMarkdownTemplate?: string;
    /**
    * A brief description of the template, up to 110 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#summary WaypointTemplate#summary}
    */
    readonly summary: string;
    /**
    * The ID of the agent pool to use for Terraform operations, for workspaces created for applications using this template. Required if terraform_execution_mode is set to 'agent'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#terraform_agent_pool_id WaypointTemplate#terraform_agent_pool_id}
    */
    readonly terraformAgentPoolId?: string;
    /**
    * Terraform Cloud Workspace details
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#terraform_cloud_workspace_details WaypointTemplate#terraform_cloud_workspace_details}
    */
    readonly terraformCloudWorkspaceDetails?: WaypointTemplateTerraformCloudWorkspaceDetails;
    /**
    * The execution mode of the HCP Terraform workspaces created for applications using this template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#terraform_execution_mode WaypointTemplate#terraform_execution_mode}
    */
    readonly terraformExecutionMode?: string;
    /**
    * The ID of the Terraform no-code module to use for running Terraform operations. This is in the format of 'nocode-<ID>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#terraform_no_code_module_id WaypointTemplate#terraform_no_code_module_id}
    */
    readonly terraformNoCodeModuleId: string;
    /**
    * Terraform Cloud No-Code Module details
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#terraform_no_code_module_source WaypointTemplate#terraform_no_code_module_source}
    */
    readonly terraformNoCodeModuleSource: string;
    /**
    * The ID of the Terraform Cloud Project to create workspaces in. The ID is found on the Terraform Cloud Project settings page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#terraform_project_id WaypointTemplate#terraform_project_id}
    */
    readonly terraformProjectId: string;
    /**
    * If true, will auto-import the readme form the Terraform module used. If this is set to true, users should not also set `readme_markdown_template`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#use_module_readme WaypointTemplate#use_module_readme}
    */
    readonly useModuleReadme?: boolean | cdktn.IResolvable;
    /**
    * List of variable options for the template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#variable_options WaypointTemplate#variable_options}
    */
    readonly variableOptions?: WaypointTemplateVariableOptions[] | cdktn.IResolvable;
}
export interface WaypointTemplateTerraformCloudWorkspaceDetails {
    /**
    * Name of the Terraform Cloud Project
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#name WaypointTemplate#name}
    */
    readonly name: string;
    /**
    * Terraform Cloud Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#terraform_project_id WaypointTemplate#terraform_project_id}
    */
    readonly terraformProjectId: string;
}
export declare function waypointTemplateTerraformCloudWorkspaceDetailsToTerraform(struct?: WaypointTemplateTerraformCloudWorkspaceDetails | cdktn.IResolvable): any;
export declare function waypointTemplateTerraformCloudWorkspaceDetailsToHclTerraform(struct?: WaypointTemplateTerraformCloudWorkspaceDetails | cdktn.IResolvable): any;
export declare class WaypointTemplateTerraformCloudWorkspaceDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WaypointTemplateTerraformCloudWorkspaceDetails | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointTemplateTerraformCloudWorkspaceDetails | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _terraformProjectId?;
    get terraformProjectId(): string;
    set terraformProjectId(value: string);
    get terraformProjectIdInput(): string | undefined;
}
export interface WaypointTemplateVariableOptions {
    /**
    * Variable name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#name WaypointTemplate#name}
    */
    readonly name: string;
    /**
    * List of options
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#options WaypointTemplate#options}
    */
    readonly options?: string[];
    /**
    * Whether the variable is editable by the user creating an application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#user_editable WaypointTemplate#user_editable}
    */
    readonly userEditable?: boolean | cdktn.IResolvable;
    /**
    * Variable type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#variable_type WaypointTemplate#variable_type}
    */
    readonly variableType: string;
}
export declare function waypointTemplateVariableOptionsToTerraform(struct?: WaypointTemplateVariableOptions | cdktn.IResolvable): any;
export declare function waypointTemplateVariableOptionsToHclTerraform(struct?: WaypointTemplateVariableOptions | cdktn.IResolvable): any;
export declare class WaypointTemplateVariableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointTemplateVariableOptions | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointTemplateVariableOptions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options?;
    get options(): string[];
    set options(value: string[]);
    resetOptions(): void;
    get optionsInput(): string[] | undefined;
    private _userEditable?;
    get userEditable(): boolean | cdktn.IResolvable;
    set userEditable(value: boolean | cdktn.IResolvable);
    resetUserEditable(): void;
    get userEditableInput(): boolean | cdktn.IResolvable | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    get variableTypeInput(): string | undefined;
}
export declare class WaypointTemplateVariableOptionsList extends cdktn.ComplexList {
    internalValue?: WaypointTemplateVariableOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointTemplateVariableOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template hcp_waypoint_template}
*/
export declare class WaypointTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_waypoint_template";
    /**
    * Generates CDKTN code for importing a WaypointTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaypointTemplate to import
    * @param importFromId The id of the existing WaypointTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaypointTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/waypoint_template hcp_waypoint_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaypointTemplateConfig
    */
    constructor(scope: Construct, id: string, config: WaypointTemplateConfig);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    resetActions(): void;
    get actionsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _readmeMarkdownTemplate?;
    get readmeMarkdownTemplate(): string;
    set readmeMarkdownTemplate(value: string);
    resetReadmeMarkdownTemplate(): void;
    get readmeMarkdownTemplateInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    get summaryInput(): string | undefined;
    private _terraformAgentPoolId?;
    get terraformAgentPoolId(): string;
    set terraformAgentPoolId(value: string);
    resetTerraformAgentPoolId(): void;
    get terraformAgentPoolIdInput(): string | undefined;
    private _terraformCloudWorkspaceDetails;
    get terraformCloudWorkspaceDetails(): WaypointTemplateTerraformCloudWorkspaceDetailsOutputReference;
    putTerraformCloudWorkspaceDetails(value: WaypointTemplateTerraformCloudWorkspaceDetails): void;
    resetTerraformCloudWorkspaceDetails(): void;
    get terraformCloudWorkspaceDetailsInput(): cdktn.IResolvable | WaypointTemplateTerraformCloudWorkspaceDetails | undefined;
    private _terraformExecutionMode?;
    get terraformExecutionMode(): string;
    set terraformExecutionMode(value: string);
    resetTerraformExecutionMode(): void;
    get terraformExecutionModeInput(): string | undefined;
    private _terraformNoCodeModuleId?;
    get terraformNoCodeModuleId(): string;
    set terraformNoCodeModuleId(value: string);
    get terraformNoCodeModuleIdInput(): string | undefined;
    private _terraformNoCodeModuleSource?;
    get terraformNoCodeModuleSource(): string;
    set terraformNoCodeModuleSource(value: string);
    get terraformNoCodeModuleSourceInput(): string | undefined;
    private _terraformProjectId?;
    get terraformProjectId(): string;
    set terraformProjectId(value: string);
    get terraformProjectIdInput(): string | undefined;
    private _useModuleReadme?;
    get useModuleReadme(): boolean | cdktn.IResolvable;
    set useModuleReadme(value: boolean | cdktn.IResolvable);
    resetUseModuleReadme(): void;
    get useModuleReadmeInput(): boolean | cdktn.IResolvable | undefined;
    private _variableOptions;
    get variableOptions(): WaypointTemplateVariableOptionsList;
    putVariableOptions(value: WaypointTemplateVariableOptions[] | cdktn.IResolvable): void;
    resetVariableOptions(): void;
    get variableOptionsInput(): cdktn.IResolvable | WaypointTemplateVariableOptions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
