/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Vault cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#cluster_id VaultCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * The ID of the HVN this HCP Vault cluster is associated to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#hvn_id VaultCluster#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#id VaultCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The minimum Vault version to use when creating the cluster. If not specified, it is defaulted to the version that is currently recommended by HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#min_vault_version VaultCluster#min_vault_version}
    */
    readonly minVaultVersion?: string;
    /**
    * The performance replication [paths filter](https://developer.hashicorp.com/vault/tutorials/cloud-ops/vault-replication-terraform). Applies to performance replication secondaries only and operates in "deny" mode only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#paths_filter VaultCluster#paths_filter}
    */
    readonly pathsFilter?: string[];
    /**
    * The `self_link` of the HCP Vault Plus tier cluster which is the primary in the performance replication setup with this HCP Vault Plus tier cluster. If not specified, it is a standalone Plus tier HCP Vault cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#primary_link VaultCluster#primary_link}
    */
    readonly primaryLink?: string;
    /**
    *
    * The ID of the HCP project where the Vault cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#project_id VaultCluster#project_id}
    */
    readonly projectId?: string;
    /**
    * Denotes that the cluster has a proxy endpoint. Valid options are `ENABLED`, `DISABLED`. Defaults to `DISABLED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#proxy_endpoint VaultCluster#proxy_endpoint}
    */
    readonly proxyEndpoint?: string;
    /**
    * Denotes that the cluster has a public endpoint. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#public_endpoint VaultCluster#public_endpoint}
    */
    readonly publicEndpoint?: boolean | cdktn.IResolvable;
    /**
    * Tier of the HCP Vault cluster. Valid options for tiers - `dev`, `standard_small`, `standard_medium`, `standard_large`, `plus_small`, `plus_medium`, `plus_large`. See [pricing information](https://www.hashicorp.com/products/vault/pricing). Changing a cluster's size or tier is only available to admins. See [Scale a cluster](https://registry.terraform.io/providers/hashicorp/hcp/latest/docs/guides/vault-scaling).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#tier VaultCluster#tier}
    */
    readonly tier?: string;
    /**
    * audit_log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#audit_log_config VaultCluster#audit_log_config}
    */
    readonly auditLogConfig?: VaultClusterAuditLogConfig;
    /**
    * ip_allowlist block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#ip_allowlist VaultCluster#ip_allowlist}
    */
    readonly ipAllowlist?: VaultClusterIpAllowlistStruct[] | cdktn.IResolvable;
    /**
    * major_version_upgrade_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#major_version_upgrade_config VaultCluster#major_version_upgrade_config}
    */
    readonly majorVersionUpgradeConfig?: VaultClusterMajorVersionUpgradeConfig;
    /**
    * metrics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#metrics_config VaultCluster#metrics_config}
    */
    readonly metricsConfig?: VaultClusterMetricsConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#timeouts VaultCluster#timeouts}
    */
    readonly timeouts?: VaultClusterTimeouts;
}
export interface VaultClusterAuditLogConfig {
    /**
    * CloudWatch access key ID for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#cloudwatch_access_key_id VaultCluster#cloudwatch_access_key_id}
    */
    readonly cloudwatchAccessKeyId?: string;
    /**
    * CloudWatch region for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#cloudwatch_region VaultCluster#cloudwatch_region}
    */
    readonly cloudwatchRegion?: string;
    /**
    * CloudWatch secret access key for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#cloudwatch_secret_access_key VaultCluster#cloudwatch_secret_access_key}
    */
    readonly cloudwatchSecretAccessKey?: string;
    /**
    * Datadog api key for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#datadog_api_key VaultCluster#datadog_api_key}
    */
    readonly datadogApiKey?: string;
    /**
    * Datadog region for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#datadog_region VaultCluster#datadog_region}
    */
    readonly datadogRegion?: string;
    /**
    * ElasticSearch endpoint for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#elasticsearch_endpoint VaultCluster#elasticsearch_endpoint}
    */
    readonly elasticsearchEndpoint?: string;
    /**
    * ElasticSearch password for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#elasticsearch_password VaultCluster#elasticsearch_password}
    */
    readonly elasticsearchPassword?: string;
    /**
    * ElasticSearch user for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#elasticsearch_user VaultCluster#elasticsearch_user}
    */
    readonly elasticsearchUser?: string;
    /**
    * Grafana endpoint for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#grafana_endpoint VaultCluster#grafana_endpoint}
    */
    readonly grafanaEndpoint?: string;
    /**
    * Grafana password for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#grafana_password VaultCluster#grafana_password}
    */
    readonly grafanaPassword?: string;
    /**
    * Grafana user for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#grafana_user VaultCluster#grafana_user}
    */
    readonly grafanaUser?: string;
    /**
    * HTTP basic authentication password for streaming audit logs, one of the two available authentication methods, can be specified only if http_basic_user is also provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_basic_password VaultCluster#http_basic_password}
    */
    readonly httpBasicPassword?: string;
    /**
    * HTTP basic authentication username for streaming audit logs, one of the two available authentication methods, can be specified only if http_basic_password is also provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_basic_user VaultCluster#http_basic_user}
    */
    readonly httpBasicUser?: string;
    /**
    * HTTP bearer authentication token for streaming audit logs, one of the two available authentication methods, can be specified only if http_basic_user and http_basic_password are not provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_bearer_token VaultCluster#http_bearer_token}
    */
    readonly httpBearerToken?: string;
    /**
    * HTTP codec for streaming audit logs, allowed values are JSON and NDJSON
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_codec VaultCluster#http_codec}
    */
    readonly httpCodec?: string;
    /**
    * HTTP compression flag for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_compression VaultCluster#http_compression}
    */
    readonly httpCompression?: boolean | cdktn.IResolvable;
    /**
    * HTTP headers for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_headers VaultCluster#http_headers}
    */
    readonly httpHeaders?: {
        [key: string]: string;
    };
    /**
    * HTTP payload method for streaming audit logs, , allowed values are PATCH, POST, or PUT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_method VaultCluster#http_method}
    */
    readonly httpMethod?: string;
    /**
    * HTTP payload prefix for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_payload_prefix VaultCluster#http_payload_prefix}
    */
    readonly httpPayloadPrefix?: string;
    /**
    * HTTP payload suffix for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_payload_suffix VaultCluster#http_payload_suffix}
    */
    readonly httpPayloadSuffix?: string;
    /**
    * HTTP URI for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_uri VaultCluster#http_uri}
    */
    readonly httpUri?: string;
    /**
    * NewRelic Account ID for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#newrelic_account_id VaultCluster#newrelic_account_id}
    */
    readonly newrelicAccountId?: string;
    /**
    * NewRelic license key for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#newrelic_license_key VaultCluster#newrelic_license_key}
    */
    readonly newrelicLicenseKey?: string;
    /**
    * NewRelic region for streaming audit logs, allowed values are "US" and "EU"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#newrelic_region VaultCluster#newrelic_region}
    */
    readonly newrelicRegion?: string;
    /**
    * Splunk endpoint for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#splunk_hecendpoint VaultCluster#splunk_hecendpoint}
    */
    readonly splunkHecendpoint?: string;
    /**
    * Splunk token for streaming audit logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#splunk_token VaultCluster#splunk_token}
    */
    readonly splunkToken?: string;
}
export declare function vaultClusterAuditLogConfigToTerraform(struct?: VaultClusterAuditLogConfigOutputReference | VaultClusterAuditLogConfig): any;
export declare function vaultClusterAuditLogConfigToHclTerraform(struct?: VaultClusterAuditLogConfigOutputReference | VaultClusterAuditLogConfig): any;
export declare class VaultClusterAuditLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultClusterAuditLogConfig | undefined;
    set internalValue(value: VaultClusterAuditLogConfig | undefined);
    private _cloudwatchAccessKeyId?;
    get cloudwatchAccessKeyId(): string;
    set cloudwatchAccessKeyId(value: string);
    resetCloudwatchAccessKeyId(): void;
    get cloudwatchAccessKeyIdInput(): string | undefined;
    get cloudwatchGroupName(): string;
    private _cloudwatchRegion?;
    get cloudwatchRegion(): string;
    set cloudwatchRegion(value: string);
    resetCloudwatchRegion(): void;
    get cloudwatchRegionInput(): string | undefined;
    private _cloudwatchSecretAccessKey?;
    get cloudwatchSecretAccessKey(): string;
    set cloudwatchSecretAccessKey(value: string);
    resetCloudwatchSecretAccessKey(): void;
    get cloudwatchSecretAccessKeyInput(): string | undefined;
    get cloudwatchStreamName(): string;
    private _datadogApiKey?;
    get datadogApiKey(): string;
    set datadogApiKey(value: string);
    resetDatadogApiKey(): void;
    get datadogApiKeyInput(): string | undefined;
    private _datadogRegion?;
    get datadogRegion(): string;
    set datadogRegion(value: string);
    resetDatadogRegion(): void;
    get datadogRegionInput(): string | undefined;
    get elasticsearchDataset(): string;
    private _elasticsearchEndpoint?;
    get elasticsearchEndpoint(): string;
    set elasticsearchEndpoint(value: string);
    resetElasticsearchEndpoint(): void;
    get elasticsearchEndpointInput(): string | undefined;
    private _elasticsearchPassword?;
    get elasticsearchPassword(): string;
    set elasticsearchPassword(value: string);
    resetElasticsearchPassword(): void;
    get elasticsearchPasswordInput(): string | undefined;
    private _elasticsearchUser?;
    get elasticsearchUser(): string;
    set elasticsearchUser(value: string);
    resetElasticsearchUser(): void;
    get elasticsearchUserInput(): string | undefined;
    private _grafanaEndpoint?;
    get grafanaEndpoint(): string;
    set grafanaEndpoint(value: string);
    resetGrafanaEndpoint(): void;
    get grafanaEndpointInput(): string | undefined;
    private _grafanaPassword?;
    get grafanaPassword(): string;
    set grafanaPassword(value: string);
    resetGrafanaPassword(): void;
    get grafanaPasswordInput(): string | undefined;
    private _grafanaUser?;
    get grafanaUser(): string;
    set grafanaUser(value: string);
    resetGrafanaUser(): void;
    get grafanaUserInput(): string | undefined;
    private _httpBasicPassword?;
    get httpBasicPassword(): string;
    set httpBasicPassword(value: string);
    resetHttpBasicPassword(): void;
    get httpBasicPasswordInput(): string | undefined;
    private _httpBasicUser?;
    get httpBasicUser(): string;
    set httpBasicUser(value: string);
    resetHttpBasicUser(): void;
    get httpBasicUserInput(): string | undefined;
    private _httpBearerToken?;
    get httpBearerToken(): string;
    set httpBearerToken(value: string);
    resetHttpBearerToken(): void;
    get httpBearerTokenInput(): string | undefined;
    private _httpCodec?;
    get httpCodec(): string;
    set httpCodec(value: string);
    resetHttpCodec(): void;
    get httpCodecInput(): string | undefined;
    private _httpCompression?;
    get httpCompression(): boolean | cdktn.IResolvable;
    set httpCompression(value: boolean | cdktn.IResolvable);
    resetHttpCompression(): void;
    get httpCompressionInput(): boolean | cdktn.IResolvable | undefined;
    private _httpHeaders?;
    get httpHeaders(): {
        [key: string]: string;
    };
    set httpHeaders(value: {
        [key: string]: string;
    });
    resetHttpHeaders(): void;
    get httpHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    resetHttpMethod(): void;
    get httpMethodInput(): string | undefined;
    private _httpPayloadPrefix?;
    get httpPayloadPrefix(): string;
    set httpPayloadPrefix(value: string);
    resetHttpPayloadPrefix(): void;
    get httpPayloadPrefixInput(): string | undefined;
    private _httpPayloadSuffix?;
    get httpPayloadSuffix(): string;
    set httpPayloadSuffix(value: string);
    resetHttpPayloadSuffix(): void;
    get httpPayloadSuffixInput(): string | undefined;
    private _httpUri?;
    get httpUri(): string;
    set httpUri(value: string);
    resetHttpUri(): void;
    get httpUriInput(): string | undefined;
    private _newrelicAccountId?;
    get newrelicAccountId(): string;
    set newrelicAccountId(value: string);
    resetNewrelicAccountId(): void;
    get newrelicAccountIdInput(): string | undefined;
    private _newrelicLicenseKey?;
    get newrelicLicenseKey(): string;
    set newrelicLicenseKey(value: string);
    resetNewrelicLicenseKey(): void;
    get newrelicLicenseKeyInput(): string | undefined;
    private _newrelicRegion?;
    get newrelicRegion(): string;
    set newrelicRegion(value: string);
    resetNewrelicRegion(): void;
    get newrelicRegionInput(): string | undefined;
    private _splunkHecendpoint?;
    get splunkHecendpoint(): string;
    set splunkHecendpoint(value: string);
    resetSplunkHecendpoint(): void;
    get splunkHecendpointInput(): string | undefined;
    private _splunkToken?;
    get splunkToken(): string;
    set splunkToken(value: string);
    resetSplunkToken(): void;
    get splunkTokenInput(): string | undefined;
}
export interface VaultClusterIpAllowlistStruct {
    /**
    * IP address range in CIDR notation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#address VaultCluster#address}
    */
    readonly address: string;
    /**
    * Description to help identify source (maximum 255 chars).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#description VaultCluster#description}
    */
    readonly description?: string;
}
export declare function vaultClusterIpAllowlistStructToTerraform(struct?: VaultClusterIpAllowlistStruct | cdktn.IResolvable): any;
export declare function vaultClusterIpAllowlistStructToHclTerraform(struct?: VaultClusterIpAllowlistStruct | cdktn.IResolvable): any;
export declare class VaultClusterIpAllowlistStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VaultClusterIpAllowlistStruct | cdktn.IResolvable | undefined;
    set internalValue(value: VaultClusterIpAllowlistStruct | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
}
export declare class VaultClusterIpAllowlistStructList extends cdktn.ComplexList {
    internalValue?: VaultClusterIpAllowlistStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VaultClusterIpAllowlistStructOutputReference;
}
export interface VaultClusterMajorVersionUpgradeConfig {
    /**
    * The maintenance day of the week for scheduled upgrades. Valid options for maintenance window day - `MONDAY`, `TUESDAY`, `WEDNESDAY`, `THURSDAY`, `FRIDAY`, `SATURDAY`, `SUNDAY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#maintenance_window_day VaultCluster#maintenance_window_day}
    */
    readonly maintenanceWindowDay?: string;
    /**
    * The maintenance time frame for scheduled upgrades. Valid options for maintenance window time - `WINDOW_12AM_4AM`, `WINDOW_6AM_10AM`, `WINDOW_12PM_4PM`, `WINDOW_6PM_10PM`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#maintenance_window_time VaultCluster#maintenance_window_time}
    */
    readonly maintenanceWindowTime?: string;
    /**
    * The major upgrade type for the cluster. Valid options for upgrade type - `AUTOMATIC`, `SCHEDULED`, `MANUAL`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#upgrade_type VaultCluster#upgrade_type}
    */
    readonly upgradeType: string;
}
export declare function vaultClusterMajorVersionUpgradeConfigToTerraform(struct?: VaultClusterMajorVersionUpgradeConfigOutputReference | VaultClusterMajorVersionUpgradeConfig): any;
export declare function vaultClusterMajorVersionUpgradeConfigToHclTerraform(struct?: VaultClusterMajorVersionUpgradeConfigOutputReference | VaultClusterMajorVersionUpgradeConfig): any;
export declare class VaultClusterMajorVersionUpgradeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultClusterMajorVersionUpgradeConfig | undefined;
    set internalValue(value: VaultClusterMajorVersionUpgradeConfig | undefined);
    private _maintenanceWindowDay?;
    get maintenanceWindowDay(): string;
    set maintenanceWindowDay(value: string);
    resetMaintenanceWindowDay(): void;
    get maintenanceWindowDayInput(): string | undefined;
    private _maintenanceWindowTime?;
    get maintenanceWindowTime(): string;
    set maintenanceWindowTime(value: string);
    resetMaintenanceWindowTime(): void;
    get maintenanceWindowTimeInput(): string | undefined;
    private _upgradeType?;
    get upgradeType(): string;
    set upgradeType(value: string);
    get upgradeTypeInput(): string | undefined;
}
export interface VaultClusterMetricsConfig {
    /**
    * CloudWatch access key ID for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#cloudwatch_access_key_id VaultCluster#cloudwatch_access_key_id}
    */
    readonly cloudwatchAccessKeyId?: string;
    /**
    * CloudWatch region for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#cloudwatch_region VaultCluster#cloudwatch_region}
    */
    readonly cloudwatchRegion?: string;
    /**
    * CloudWatch secret access key for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#cloudwatch_secret_access_key VaultCluster#cloudwatch_secret_access_key}
    */
    readonly cloudwatchSecretAccessKey?: string;
    /**
    * Datadog api key for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#datadog_api_key VaultCluster#datadog_api_key}
    */
    readonly datadogApiKey?: string;
    /**
    * Datadog region for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#datadog_region VaultCluster#datadog_region}
    */
    readonly datadogRegion?: string;
    /**
    * ElasticSearch endpoint for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#elasticsearch_endpoint VaultCluster#elasticsearch_endpoint}
    */
    readonly elasticsearchEndpoint?: string;
    /**
    * ElasticSearch password for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#elasticsearch_password VaultCluster#elasticsearch_password}
    */
    readonly elasticsearchPassword?: string;
    /**
    * ElasticSearch user for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#elasticsearch_user VaultCluster#elasticsearch_user}
    */
    readonly elasticsearchUser?: string;
    /**
    * Grafana endpoint for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#grafana_endpoint VaultCluster#grafana_endpoint}
    */
    readonly grafanaEndpoint?: string;
    /**
    * Grafana password for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#grafana_password VaultCluster#grafana_password}
    */
    readonly grafanaPassword?: string;
    /**
    * Grafana user for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#grafana_user VaultCluster#grafana_user}
    */
    readonly grafanaUser?: string;
    /**
    * HTTP basic authentication password for streaming metrics, one of the two available authentication methods, can be specified only if http_basic_user is also specified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_basic_password VaultCluster#http_basic_password}
    */
    readonly httpBasicPassword?: string;
    /**
    * HTTP basic authentication username for streaming metrics, one of the two available authentication methods, can be specified only if http_basic_password is also specified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_basic_user VaultCluster#http_basic_user}
    */
    readonly httpBasicUser?: string;
    /**
    * HTTP bearer authentication token for streaming metrics, one of the two available authentication methods, can be specified only if http_basic_user and http_basic_password are not provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_bearer_token VaultCluster#http_bearer_token}
    */
    readonly httpBearerToken?: string;
    /**
    * HTTP codec for streaming metrics, allowed values are JSON and NDJSON
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_codec VaultCluster#http_codec}
    */
    readonly httpCodec?: string;
    /**
    * HTTP compression flag for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_compression VaultCluster#http_compression}
    */
    readonly httpCompression?: boolean | cdktn.IResolvable;
    /**
    * HTTP headers for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_headers VaultCluster#http_headers}
    */
    readonly httpHeaders?: {
        [key: string]: string;
    };
    /**
    * HTTP payload method for streaming metrics, allowed values are PATCH, POST, or PUT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_method VaultCluster#http_method}
    */
    readonly httpMethod?: string;
    /**
    * HTTP payload prefix for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_payload_prefix VaultCluster#http_payload_prefix}
    */
    readonly httpPayloadPrefix?: string;
    /**
    * HTTP payload suffix for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_payload_suffix VaultCluster#http_payload_suffix}
    */
    readonly httpPayloadSuffix?: string;
    /**
    * HTTP URI for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#http_uri VaultCluster#http_uri}
    */
    readonly httpUri?: string;
    /**
    * NewRelic Account ID for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#newrelic_account_id VaultCluster#newrelic_account_id}
    */
    readonly newrelicAccountId?: string;
    /**
    * NewRelic license key for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#newrelic_license_key VaultCluster#newrelic_license_key}
    */
    readonly newrelicLicenseKey?: string;
    /**
    * NewRelic region for streaming metrics, allowed values are "US" and "EU"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#newrelic_region VaultCluster#newrelic_region}
    */
    readonly newrelicRegion?: string;
    /**
    * Splunk endpoint for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#splunk_hecendpoint VaultCluster#splunk_hecendpoint}
    */
    readonly splunkHecendpoint?: string;
    /**
    * Splunk token for streaming metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#splunk_token VaultCluster#splunk_token}
    */
    readonly splunkToken?: string;
}
export declare function vaultClusterMetricsConfigToTerraform(struct?: VaultClusterMetricsConfigOutputReference | VaultClusterMetricsConfig): any;
export declare function vaultClusterMetricsConfigToHclTerraform(struct?: VaultClusterMetricsConfigOutputReference | VaultClusterMetricsConfig): any;
export declare class VaultClusterMetricsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultClusterMetricsConfig | undefined;
    set internalValue(value: VaultClusterMetricsConfig | undefined);
    private _cloudwatchAccessKeyId?;
    get cloudwatchAccessKeyId(): string;
    set cloudwatchAccessKeyId(value: string);
    resetCloudwatchAccessKeyId(): void;
    get cloudwatchAccessKeyIdInput(): string | undefined;
    get cloudwatchNamespace(): string;
    private _cloudwatchRegion?;
    get cloudwatchRegion(): string;
    set cloudwatchRegion(value: string);
    resetCloudwatchRegion(): void;
    get cloudwatchRegionInput(): string | undefined;
    private _cloudwatchSecretAccessKey?;
    get cloudwatchSecretAccessKey(): string;
    set cloudwatchSecretAccessKey(value: string);
    resetCloudwatchSecretAccessKey(): void;
    get cloudwatchSecretAccessKeyInput(): string | undefined;
    private _datadogApiKey?;
    get datadogApiKey(): string;
    set datadogApiKey(value: string);
    resetDatadogApiKey(): void;
    get datadogApiKeyInput(): string | undefined;
    private _datadogRegion?;
    get datadogRegion(): string;
    set datadogRegion(value: string);
    resetDatadogRegion(): void;
    get datadogRegionInput(): string | undefined;
    get elasticsearchDataset(): string;
    private _elasticsearchEndpoint?;
    get elasticsearchEndpoint(): string;
    set elasticsearchEndpoint(value: string);
    resetElasticsearchEndpoint(): void;
    get elasticsearchEndpointInput(): string | undefined;
    private _elasticsearchPassword?;
    get elasticsearchPassword(): string;
    set elasticsearchPassword(value: string);
    resetElasticsearchPassword(): void;
    get elasticsearchPasswordInput(): string | undefined;
    private _elasticsearchUser?;
    get elasticsearchUser(): string;
    set elasticsearchUser(value: string);
    resetElasticsearchUser(): void;
    get elasticsearchUserInput(): string | undefined;
    private _grafanaEndpoint?;
    get grafanaEndpoint(): string;
    set grafanaEndpoint(value: string);
    resetGrafanaEndpoint(): void;
    get grafanaEndpointInput(): string | undefined;
    private _grafanaPassword?;
    get grafanaPassword(): string;
    set grafanaPassword(value: string);
    resetGrafanaPassword(): void;
    get grafanaPasswordInput(): string | undefined;
    private _grafanaUser?;
    get grafanaUser(): string;
    set grafanaUser(value: string);
    resetGrafanaUser(): void;
    get grafanaUserInput(): string | undefined;
    private _httpBasicPassword?;
    get httpBasicPassword(): string;
    set httpBasicPassword(value: string);
    resetHttpBasicPassword(): void;
    get httpBasicPasswordInput(): string | undefined;
    private _httpBasicUser?;
    get httpBasicUser(): string;
    set httpBasicUser(value: string);
    resetHttpBasicUser(): void;
    get httpBasicUserInput(): string | undefined;
    private _httpBearerToken?;
    get httpBearerToken(): string;
    set httpBearerToken(value: string);
    resetHttpBearerToken(): void;
    get httpBearerTokenInput(): string | undefined;
    private _httpCodec?;
    get httpCodec(): string;
    set httpCodec(value: string);
    resetHttpCodec(): void;
    get httpCodecInput(): string | undefined;
    private _httpCompression?;
    get httpCompression(): boolean | cdktn.IResolvable;
    set httpCompression(value: boolean | cdktn.IResolvable);
    resetHttpCompression(): void;
    get httpCompressionInput(): boolean | cdktn.IResolvable | undefined;
    private _httpHeaders?;
    get httpHeaders(): {
        [key: string]: string;
    };
    set httpHeaders(value: {
        [key: string]: string;
    });
    resetHttpHeaders(): void;
    get httpHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    resetHttpMethod(): void;
    get httpMethodInput(): string | undefined;
    private _httpPayloadPrefix?;
    get httpPayloadPrefix(): string;
    set httpPayloadPrefix(value: string);
    resetHttpPayloadPrefix(): void;
    get httpPayloadPrefixInput(): string | undefined;
    private _httpPayloadSuffix?;
    get httpPayloadSuffix(): string;
    set httpPayloadSuffix(value: string);
    resetHttpPayloadSuffix(): void;
    get httpPayloadSuffixInput(): string | undefined;
    private _httpUri?;
    get httpUri(): string;
    set httpUri(value: string);
    resetHttpUri(): void;
    get httpUriInput(): string | undefined;
    private _newrelicAccountId?;
    get newrelicAccountId(): string;
    set newrelicAccountId(value: string);
    resetNewrelicAccountId(): void;
    get newrelicAccountIdInput(): string | undefined;
    private _newrelicLicenseKey?;
    get newrelicLicenseKey(): string;
    set newrelicLicenseKey(value: string);
    resetNewrelicLicenseKey(): void;
    get newrelicLicenseKeyInput(): string | undefined;
    private _newrelicRegion?;
    get newrelicRegion(): string;
    set newrelicRegion(value: string);
    resetNewrelicRegion(): void;
    get newrelicRegionInput(): string | undefined;
    private _splunkHecendpoint?;
    get splunkHecendpoint(): string;
    set splunkHecendpoint(value: string);
    resetSplunkHecendpoint(): void;
    get splunkHecendpointInput(): string | undefined;
    private _splunkToken?;
    get splunkToken(): string;
    set splunkToken(value: string);
    resetSplunkToken(): void;
    get splunkTokenInput(): string | undefined;
}
export interface VaultClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#create VaultCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#default VaultCluster#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#delete VaultCluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#update VaultCluster#update}
    */
    readonly update?: string;
}
export declare function vaultClusterTimeoutsToTerraform(struct?: VaultClusterTimeouts | cdktn.IResolvable): any;
export declare function vaultClusterTimeoutsToHclTerraform(struct?: VaultClusterTimeouts | cdktn.IResolvable): any;
export declare class VaultClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: VaultClusterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster hcp_vault_cluster}
*/
export declare class VaultCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_cluster";
    /**
    * Generates CDKTN code for importing a VaultCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultCluster to import
    * @param importFromId The id of the existing VaultCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_cluster hcp_vault_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultClusterConfig
    */
    constructor(scope: Construct, id: string, config: VaultClusterConfig);
    get cloudProvider(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get createdAt(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _minVaultVersion?;
    get minVaultVersion(): string;
    set minVaultVersion(value: string);
    resetMinVaultVersion(): void;
    get minVaultVersionInput(): string | undefined;
    get namespace(): string;
    get organizationId(): string;
    private _pathsFilter?;
    get pathsFilter(): string[];
    set pathsFilter(value: string[]);
    resetPathsFilter(): void;
    get pathsFilterInput(): string[] | undefined;
    private _primaryLink?;
    get primaryLink(): string;
    set primaryLink(value: string);
    resetPrimaryLink(): void;
    get primaryLinkInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _proxyEndpoint?;
    get proxyEndpoint(): string;
    set proxyEndpoint(value: string);
    resetProxyEndpoint(): void;
    get proxyEndpointInput(): string | undefined;
    private _publicEndpoint?;
    get publicEndpoint(): boolean | cdktn.IResolvable;
    set publicEndpoint(value: boolean | cdktn.IResolvable);
    resetPublicEndpoint(): void;
    get publicEndpointInput(): boolean | cdktn.IResolvable | undefined;
    get region(): string;
    get selfLink(): string;
    get state(): string;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    get vaultPrivateEndpointUrl(): string;
    get vaultProxyEndpointUrl(): string;
    get vaultPublicEndpointUrl(): string;
    get vaultVersion(): string;
    private _auditLogConfig;
    get auditLogConfig(): VaultClusterAuditLogConfigOutputReference;
    putAuditLogConfig(value: VaultClusterAuditLogConfig): void;
    resetAuditLogConfig(): void;
    get auditLogConfigInput(): VaultClusterAuditLogConfig | undefined;
    private _ipAllowlist;
    get ipAllowlist(): VaultClusterIpAllowlistStructList;
    putIpAllowlist(value: VaultClusterIpAllowlistStruct[] | cdktn.IResolvable): void;
    resetIpAllowlist(): void;
    get ipAllowlistInput(): cdktn.IResolvable | VaultClusterIpAllowlistStruct[] | undefined;
    private _majorVersionUpgradeConfig;
    get majorVersionUpgradeConfig(): VaultClusterMajorVersionUpgradeConfigOutputReference;
    putMajorVersionUpgradeConfig(value: VaultClusterMajorVersionUpgradeConfig): void;
    resetMajorVersionUpgradeConfig(): void;
    get majorVersionUpgradeConfigInput(): VaultClusterMajorVersionUpgradeConfig | undefined;
    private _metricsConfig;
    get metricsConfig(): VaultClusterMetricsConfigOutputReference;
    putMetricsConfig(value: VaultClusterMetricsConfig): void;
    resetMetricsConfig(): void;
    get metricsConfigInput(): VaultClusterMetricsConfig | undefined;
    private _timeouts;
    get timeouts(): VaultClusterTimeoutsOutputReference;
    putTimeouts(value: VaultClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | VaultClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
