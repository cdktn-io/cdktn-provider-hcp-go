/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpAwsTransitGatewayAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#hvn_id DataHcpAwsTransitGatewayAttachment#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#id DataHcpAwsTransitGatewayAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the transit gateway attachment is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#project_id DataHcpAwsTransitGatewayAttachment#project_id}
    */
    readonly projectId?: string;
    /**
    * The user-settable name of the transit gateway attachment in HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#transit_gateway_attachment_id DataHcpAwsTransitGatewayAttachment#transit_gateway_attachment_id}
    */
    readonly transitGatewayAttachmentId: string;
    /**
    * If `true`, Terraform will wait for the transit gateway attachment to reach an `ACTIVE` state before continuing. Default `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#wait_for_active_state DataHcpAwsTransitGatewayAttachment#wait_for_active_state}
    */
    readonly waitForActiveState?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#timeouts DataHcpAwsTransitGatewayAttachment#timeouts}
    */
    readonly timeouts?: DataHcpAwsTransitGatewayAttachmentTimeouts;
}
export interface DataHcpAwsTransitGatewayAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#default DataHcpAwsTransitGatewayAttachment#default}
    */
    readonly default?: string;
}
export declare function dataHcpAwsTransitGatewayAttachmentTimeoutsToTerraform(struct?: DataHcpAwsTransitGatewayAttachmentTimeouts | cdktn.IResolvable): any;
export declare function dataHcpAwsTransitGatewayAttachmentTimeoutsToHclTerraform(struct?: DataHcpAwsTransitGatewayAttachmentTimeouts | cdktn.IResolvable): any;
export declare class DataHcpAwsTransitGatewayAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpAwsTransitGatewayAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpAwsTransitGatewayAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment hcp_aws_transit_gateway_attachment}
*/
export declare class DataHcpAwsTransitGatewayAttachment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_aws_transit_gateway_attachment";
    /**
    * Generates CDKTN code for importing a DataHcpAwsTransitGatewayAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpAwsTransitGatewayAttachment to import
    * @param importFromId The id of the existing DataHcpAwsTransitGatewayAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpAwsTransitGatewayAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/aws_transit_gateway_attachment hcp_aws_transit_gateway_attachment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpAwsTransitGatewayAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpAwsTransitGatewayAttachmentConfig);
    get createdAt(): string;
    get expiresAt(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get providerTransitGatewayAttachmentId(): string;
    get selfLink(): string;
    get state(): string;
    private _transitGatewayAttachmentId?;
    get transitGatewayAttachmentId(): string;
    set transitGatewayAttachmentId(value: string);
    get transitGatewayAttachmentIdInput(): string | undefined;
    get transitGatewayId(): string;
    private _waitForActiveState?;
    get waitForActiveState(): boolean | cdktn.IResolvable;
    set waitForActiveState(value: boolean | cdktn.IResolvable);
    resetWaitForActiveState(): void;
    get waitForActiveStateInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): DataHcpAwsTransitGatewayAttachmentTimeoutsOutputReference;
    putTimeouts(value: DataHcpAwsTransitGatewayAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpAwsTransitGatewayAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
