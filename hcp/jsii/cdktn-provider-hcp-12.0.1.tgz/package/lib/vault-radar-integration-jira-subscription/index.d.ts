/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultRadarIntegrationJiraSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the Jira user who will be assigned the ticket. In case of Jira Cloud, this will be the Atlassian Account ID of the user. Example: 71509:11bb945b-c0de-4bac-9d57-9f09db2f7bc9
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#assignee VaultRadarIntegrationJiraSubscription#assignee}
    */
    readonly assignee?: string;
    /**
    * id of the integration jira connection to use for the subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#connection_id VaultRadarIntegrationJiraSubscription#connection_id}
    */
    readonly connectionId: string;
    /**
    * The type of issue to be created from the event(s). Example: Task
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#issue_type VaultRadarIntegrationJiraSubscription#issue_type}
    */
    readonly issueType: string;
    /**
    * The name of the project under which the jira issue will be created. Example: OPS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#jira_project_key VaultRadarIntegrationJiraSubscription#jira_project_key}
    */
    readonly jiraProjectKey: string;
    /**
    * This message will be included in the ticket description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#message VaultRadarIntegrationJiraSubscription#message}
    */
    readonly message?: string;
    /**
    * Name of subscription. Name must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#name VaultRadarIntegrationJiraSubscription#name}
    */
    readonly name: string;
    /**
    * The ID of the HCP project where Vault Radar is located. If not specified, the project specified in the HCP Provider config block will be used, if configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#project_id VaultRadarIntegrationJiraSubscription#project_id}
    */
    readonly projectId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription hcp_vault_radar_integration_jira_subscription}
*/
export declare class VaultRadarIntegrationJiraSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_radar_integration_jira_subscription";
    /**
    * Generates CDKTN code for importing a VaultRadarIntegrationJiraSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultRadarIntegrationJiraSubscription to import
    * @param importFromId The id of the existing VaultRadarIntegrationJiraSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultRadarIntegrationJiraSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_integration_jira_subscription hcp_vault_radar_integration_jira_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultRadarIntegrationJiraSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: VaultRadarIntegrationJiraSubscriptionConfig);
    private _assignee?;
    get assignee(): string;
    set assignee(value: string);
    resetAssignee(): void;
    get assigneeInput(): string | undefined;
    private _connectionId?;
    get connectionId(): string;
    set connectionId(value: string);
    get connectionIdInput(): string | undefined;
    get id(): string;
    private _issueType?;
    get issueType(): string;
    set issueType(value: string);
    get issueTypeInput(): string | undefined;
    private _jiraProjectKey?;
    get jiraProjectKey(): string;
    set jiraProjectKey(value: string);
    get jiraProjectKeyInput(): string | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
