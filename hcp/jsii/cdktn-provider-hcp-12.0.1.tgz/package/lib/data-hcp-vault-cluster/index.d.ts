/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpVaultClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Vault cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#cluster_id DataHcpVaultCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#id DataHcpVaultCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the Vault cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#project_id DataHcpVaultCluster#project_id}
    */
    readonly projectId?: string;
    /**
    * audit_log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#audit_log_config DataHcpVaultCluster#audit_log_config}
    */
    readonly auditLogConfig?: DataHcpVaultClusterAuditLogConfig[] | cdktn.IResolvable;
    /**
    * metrics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#metrics_config DataHcpVaultCluster#metrics_config}
    */
    readonly metricsConfig?: DataHcpVaultClusterMetricsConfig[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#timeouts DataHcpVaultCluster#timeouts}
    */
    readonly timeouts?: DataHcpVaultClusterTimeouts;
}
export interface DataHcpVaultClusterIpAllowlistStruct {
}
export declare function dataHcpVaultClusterIpAllowlistStructToTerraform(struct?: DataHcpVaultClusterIpAllowlistStruct): any;
export declare function dataHcpVaultClusterIpAllowlistStructToHclTerraform(struct?: DataHcpVaultClusterIpAllowlistStruct): any;
export declare class DataHcpVaultClusterIpAllowlistStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpVaultClusterIpAllowlistStruct | undefined;
    set internalValue(value: DataHcpVaultClusterIpAllowlistStruct | undefined);
    get address(): string;
    get description(): string;
}
export declare class DataHcpVaultClusterIpAllowlistStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpVaultClusterIpAllowlistStructOutputReference;
}
export interface DataHcpVaultClusterMajorVersionUpgradeConfig {
}
export declare function dataHcpVaultClusterMajorVersionUpgradeConfigToTerraform(struct?: DataHcpVaultClusterMajorVersionUpgradeConfig): any;
export declare function dataHcpVaultClusterMajorVersionUpgradeConfigToHclTerraform(struct?: DataHcpVaultClusterMajorVersionUpgradeConfig): any;
export declare class DataHcpVaultClusterMajorVersionUpgradeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpVaultClusterMajorVersionUpgradeConfig | undefined;
    set internalValue(value: DataHcpVaultClusterMajorVersionUpgradeConfig | undefined);
    get maintenanceWindowDay(): string;
    get maintenanceWindowTime(): string;
    get upgradeType(): string;
}
export declare class DataHcpVaultClusterMajorVersionUpgradeConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpVaultClusterMajorVersionUpgradeConfigOutputReference;
}
export interface DataHcpVaultClusterAuditLogConfig {
}
export declare function dataHcpVaultClusterAuditLogConfigToTerraform(struct?: DataHcpVaultClusterAuditLogConfig | cdktn.IResolvable): any;
export declare function dataHcpVaultClusterAuditLogConfigToHclTerraform(struct?: DataHcpVaultClusterAuditLogConfig | cdktn.IResolvable): any;
export declare class DataHcpVaultClusterAuditLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpVaultClusterAuditLogConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpVaultClusterAuditLogConfig | cdktn.IResolvable | undefined);
    get cloudwatchAccessKeyId(): string;
    get cloudwatchGroupName(): string;
    get cloudwatchRegion(): string;
    get cloudwatchSecretAccessKey(): string;
    get cloudwatchStreamName(): string;
    get datadogRegion(): string;
    get elasticsearchDataset(): string;
    get elasticsearchEndpoint(): string;
    get elasticsearchPassword(): string;
    get elasticsearchUser(): string;
    get grafanaEndpoint(): string;
    get grafanaUser(): string;
    get httpBasicPassword(): string;
    get httpBasicUser(): string;
    get httpBearerToken(): string;
    get httpCodec(): string;
    get httpCompression(): cdktn.IResolvable;
    private _httpHeaders;
    get httpHeaders(): cdktn.StringMap;
    get httpMethod(): string;
    get httpPayloadPrefix(): string;
    get httpPayloadSuffix(): string;
    get httpUri(): string;
    get newrelicAccountId(): string;
    get newrelicLicenseKey(): string;
    get newrelicRegion(): string;
    get splunkHecendpoint(): string;
}
export declare class DataHcpVaultClusterAuditLogConfigList extends cdktn.ComplexList {
    internalValue?: DataHcpVaultClusterAuditLogConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpVaultClusterAuditLogConfigOutputReference;
}
export interface DataHcpVaultClusterMetricsConfig {
}
export declare function dataHcpVaultClusterMetricsConfigToTerraform(struct?: DataHcpVaultClusterMetricsConfig | cdktn.IResolvable): any;
export declare function dataHcpVaultClusterMetricsConfigToHclTerraform(struct?: DataHcpVaultClusterMetricsConfig | cdktn.IResolvable): any;
export declare class DataHcpVaultClusterMetricsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpVaultClusterMetricsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpVaultClusterMetricsConfig | cdktn.IResolvable | undefined);
    get cloudwatchAccessKeyId(): string;
    get cloudwatchNamespace(): string;
    get cloudwatchRegion(): string;
    get cloudwatchSecretAccessKey(): string;
    get datadogRegion(): string;
    get elasticsearchDataset(): string;
    get elasticsearchEndpoint(): string;
    get elasticsearchPassword(): string;
    get elasticsearchUser(): string;
    get grafanaEndpoint(): string;
    get grafanaUser(): string;
    get httpBasicPassword(): string;
    get httpBasicUser(): string;
    get httpBearerToken(): string;
    get httpCodec(): string;
    get httpCompression(): cdktn.IResolvable;
    private _httpHeaders;
    get httpHeaders(): cdktn.StringMap;
    get httpMethod(): string;
    get httpPayloadPrefix(): string;
    get httpPayloadSuffix(): string;
    get httpUri(): string;
    get newrelicAccountId(): string;
    get newrelicLicenseKey(): string;
    get newrelicRegion(): string;
    get splunkHecendpoint(): string;
}
export declare class DataHcpVaultClusterMetricsConfigList extends cdktn.ComplexList {
    internalValue?: DataHcpVaultClusterMetricsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpVaultClusterMetricsConfigOutputReference;
}
export interface DataHcpVaultClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#default DataHcpVaultCluster#default}
    */
    readonly default?: string;
}
export declare function dataHcpVaultClusterTimeoutsToTerraform(struct?: DataHcpVaultClusterTimeouts | cdktn.IResolvable): any;
export declare function dataHcpVaultClusterTimeoutsToHclTerraform(struct?: DataHcpVaultClusterTimeouts | cdktn.IResolvable): any;
export declare class DataHcpVaultClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpVaultClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpVaultClusterTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster hcp_vault_cluster}
*/
export declare class DataHcpVaultCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_vault_cluster";
    /**
    * Generates CDKTN code for importing a DataHcpVaultCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpVaultCluster to import
    * @param importFromId The id of the existing DataHcpVaultCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpVaultCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/data-sources/vault_cluster hcp_vault_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpVaultClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpVaultClusterConfig);
    get cloudProvider(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get createdAt(): string;
    get hvnId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAllowlist;
    get ipAllowlist(): DataHcpVaultClusterIpAllowlistStructList;
    private _majorVersionUpgradeConfig;
    get majorVersionUpgradeConfig(): DataHcpVaultClusterMajorVersionUpgradeConfigList;
    get minVaultVersion(): string;
    get namespace(): string;
    get organizationId(): string;
    get pathsFilter(): string[];
    get primaryLink(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get proxyEndpoint(): string;
    get publicEndpoint(): cdktn.IResolvable;
    get region(): string;
    get selfLink(): string;
    get state(): string;
    get tier(): string;
    get vaultPrivateEndpointUrl(): string;
    get vaultProxyEndpointUrl(): string;
    get vaultPublicEndpointUrl(): string;
    get vaultVersion(): string;
    private _auditLogConfig;
    get auditLogConfig(): DataHcpVaultClusterAuditLogConfigList;
    putAuditLogConfig(value: DataHcpVaultClusterAuditLogConfig[] | cdktn.IResolvable): void;
    resetAuditLogConfig(): void;
    get auditLogConfigInput(): cdktn.IResolvable | DataHcpVaultClusterAuditLogConfig[] | undefined;
    private _metricsConfig;
    get metricsConfig(): DataHcpVaultClusterMetricsConfigList;
    putMetricsConfig(value: DataHcpVaultClusterMetricsConfig[] | cdktn.IResolvable): void;
    resetMetricsConfig(): void;
    get metricsConfigInput(): cdktn.IResolvable | DataHcpVaultClusterMetricsConfig[] | undefined;
    private _timeouts;
    get timeouts(): DataHcpVaultClusterTimeoutsOutputReference;
    putTimeouts(value: DataHcpVaultClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpVaultClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
