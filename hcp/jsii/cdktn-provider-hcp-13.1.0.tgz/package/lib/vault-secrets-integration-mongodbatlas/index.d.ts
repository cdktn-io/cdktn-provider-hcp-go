/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsIntegrationMongodbatlasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Capabilities enabled for the integration. See the Vault Secrets documentation for the list of supported capabilities per provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas#capabilities VaultSecretsIntegrationMongodbatlas#capabilities}
    */
    readonly capabilities: string[];
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas#name VaultSecretsIntegrationMongodbatlas#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas#project_id VaultSecretsIntegrationMongodbatlas#project_id}
    */
    readonly projectId?: string;
    /**
    * MongoDB Atlas API key used to authenticate against the target project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas#static_credential_details VaultSecretsIntegrationMongodbatlas#static_credential_details}
    */
    readonly staticCredentialDetails?: VaultSecretsIntegrationMongodbatlasStaticCredentialDetails;
}
export interface VaultSecretsIntegrationMongodbatlasStaticCredentialDetails {
    /**
    * Private key used alongside the public key to authenticate against the target project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas#api_private_key VaultSecretsIntegrationMongodbatlas#api_private_key}
    */
    readonly apiPrivateKey: string;
    /**
    * Public key used alongside the private key to authenticate against the target project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas#api_public_key VaultSecretsIntegrationMongodbatlas#api_public_key}
    */
    readonly apiPublicKey: string;
}
export declare function vaultSecretsIntegrationMongodbatlasStaticCredentialDetailsToTerraform(struct?: VaultSecretsIntegrationMongodbatlasStaticCredentialDetails | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationMongodbatlasStaticCredentialDetailsToHclTerraform(struct?: VaultSecretsIntegrationMongodbatlasStaticCredentialDetails | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationMongodbatlasStaticCredentialDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationMongodbatlasStaticCredentialDetails | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationMongodbatlasStaticCredentialDetails | cdktn.IResolvable | undefined);
    private _apiPrivateKey?;
    get apiPrivateKey(): string;
    set apiPrivateKey(value: string);
    get apiPrivateKeyInput(): string | undefined;
    private _apiPublicKey?;
    get apiPublicKey(): string;
    set apiPublicKey(value: string);
    get apiPublicKeyInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas hcp_vault_secrets_integration_mongodbatlas}
*/
export declare class VaultSecretsIntegrationMongodbatlas extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_integration_mongodbatlas";
    /**
    * Generates CDKTN code for importing a VaultSecretsIntegrationMongodbatlas resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsIntegrationMongodbatlas to import
    * @param importFromId The id of the existing VaultSecretsIntegrationMongodbatlas that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsIntegrationMongodbatlas to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_mongodbatlas hcp_vault_secrets_integration_mongodbatlas} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsIntegrationMongodbatlasConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsIntegrationMongodbatlasConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    private _staticCredentialDetails;
    get staticCredentialDetails(): VaultSecretsIntegrationMongodbatlasStaticCredentialDetailsOutputReference;
    putStaticCredentialDetails(value: VaultSecretsIntegrationMongodbatlasStaticCredentialDetails): void;
    resetStaticCredentialDetails(): void;
    get staticCredentialDetailsInput(): cdktn.IResolvable | VaultSecretsIntegrationMongodbatlasStaticCredentialDetails | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
