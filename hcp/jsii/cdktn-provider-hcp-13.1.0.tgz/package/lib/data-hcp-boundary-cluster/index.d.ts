/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpBoundaryClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Boundary cluster
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster#cluster_id DataHcpBoundaryCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster#id DataHcpBoundaryCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the Boundary cluster is located. If not specified, the project configured in the HCP provider config block will be used.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster#project_id DataHcpBoundaryCluster#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster#timeouts DataHcpBoundaryCluster#timeouts}
    */
    readonly timeouts?: DataHcpBoundaryClusterTimeouts;
}
export interface DataHcpBoundaryClusterMaintenanceWindowConfig {
}
export declare function dataHcpBoundaryClusterMaintenanceWindowConfigToTerraform(struct?: DataHcpBoundaryClusterMaintenanceWindowConfig): any;
export declare function dataHcpBoundaryClusterMaintenanceWindowConfigToHclTerraform(struct?: DataHcpBoundaryClusterMaintenanceWindowConfig): any;
export declare class DataHcpBoundaryClusterMaintenanceWindowConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpBoundaryClusterMaintenanceWindowConfig | undefined;
    set internalValue(value: DataHcpBoundaryClusterMaintenanceWindowConfig | undefined);
    get day(): string;
    get end(): number;
    get start(): number;
    get upgradeType(): string;
}
export declare class DataHcpBoundaryClusterMaintenanceWindowConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpBoundaryClusterMaintenanceWindowConfigOutputReference;
}
export interface DataHcpBoundaryClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster#default DataHcpBoundaryCluster#default}
    */
    readonly default?: string;
}
export declare function dataHcpBoundaryClusterTimeoutsToTerraform(struct?: DataHcpBoundaryClusterTimeouts | cdktn.IResolvable): any;
export declare function dataHcpBoundaryClusterTimeoutsToHclTerraform(struct?: DataHcpBoundaryClusterTimeouts | cdktn.IResolvable): any;
export declare class DataHcpBoundaryClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpBoundaryClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpBoundaryClusterTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster hcp_boundary_cluster}
*/
export declare class DataHcpBoundaryCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_boundary_cluster";
    /**
    * Generates CDKTN code for importing a DataHcpBoundaryCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpBoundaryCluster to import
    * @param importFromId The id of the existing DataHcpBoundaryCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpBoundaryCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/boundary_cluster hcp_boundary_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpBoundaryClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpBoundaryClusterConfig);
    get authTokenTimeToLive(): string;
    get authTokenTimeToStale(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get clusterUrl(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maintenanceWindowConfig;
    get maintenanceWindowConfig(): DataHcpBoundaryClusterMaintenanceWindowConfigList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get state(): string;
    get tier(): string;
    get version(): string;
    private _timeouts;
    get timeouts(): DataHcpBoundaryClusterTimeoutsOutputReference;
    putTimeouts(value: DataHcpBoundaryClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpBoundaryClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
