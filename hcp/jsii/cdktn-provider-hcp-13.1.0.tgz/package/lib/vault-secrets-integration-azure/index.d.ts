/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsIntegrationAzureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Capabilities enabled for the integration. See the Vault Secrets documentation for the list of supported capabilities per provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#capabilities VaultSecretsIntegrationAzure#capabilities}
    */
    readonly capabilities: string[];
    /**
    * Azure client secret used to authenticate against the target Azure application. Cannot be used with `federated_workload_identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#client_secret VaultSecretsIntegrationAzure#client_secret}
    */
    readonly clientSecret?: VaultSecretsIntegrationAzureClientSecretA;
    /**
    * (Recommended) Federated identity configuration to authenticate against the target Azure application. Cannot be used with `client_secret`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#federated_workload_identity VaultSecretsIntegrationAzure#federated_workload_identity}
    */
    readonly federatedWorkloadIdentity?: VaultSecretsIntegrationAzureFederatedWorkloadIdentityA;
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#name VaultSecretsIntegrationAzure#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#project_id VaultSecretsIntegrationAzure#project_id}
    */
    readonly projectId?: string;
}
export interface VaultSecretsIntegrationAzureClientSecretA {
    /**
    * Azure client ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#client_id VaultSecretsIntegrationAzure#client_id}
    */
    readonly clientId: string;
    /**
    * Secret value corresponding to the Azure client secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#client_secret VaultSecretsIntegrationAzure#client_secret}
    */
    readonly clientSecret: string;
    /**
    * Azure tenant ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#tenant_id VaultSecretsIntegrationAzure#tenant_id}
    */
    readonly tenantId: string;
}
export declare function vaultSecretsIntegrationAzureClientSecretAToTerraform(struct?: VaultSecretsIntegrationAzureClientSecretA | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAzureClientSecretAToHclTerraform(struct?: VaultSecretsIntegrationAzureClientSecretA | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAzureClientSecretAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAzureClientSecretA | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAzureClientSecretA | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
}
export interface VaultSecretsIntegrationAzureFederatedWorkloadIdentityA {
    /**
    * Audience configured on the Azure federated identity credentials to federate access with HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#audience VaultSecretsIntegrationAzure#audience}
    */
    readonly audience: string;
    /**
    * Azure client ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#client_id VaultSecretsIntegrationAzure#client_id}
    */
    readonly clientId: string;
    /**
    * Azure tenant ID corresponding to the Azure application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#tenant_id VaultSecretsIntegrationAzure#tenant_id}
    */
    readonly tenantId: string;
}
export declare function vaultSecretsIntegrationAzureFederatedWorkloadIdentityAToTerraform(struct?: VaultSecretsIntegrationAzureFederatedWorkloadIdentityA | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationAzureFederatedWorkloadIdentityAToHclTerraform(struct?: VaultSecretsIntegrationAzureFederatedWorkloadIdentityA | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationAzureFederatedWorkloadIdentityAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationAzureFederatedWorkloadIdentityA | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationAzureFederatedWorkloadIdentityA | cdktn.IResolvable | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    get audienceInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure hcp_vault_secrets_integration_azure}
*/
export declare class VaultSecretsIntegrationAzure extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_integration_azure";
    /**
    * Generates CDKTN code for importing a VaultSecretsIntegrationAzure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsIntegrationAzure to import
    * @param importFromId The id of the existing VaultSecretsIntegrationAzure that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsIntegrationAzure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_azure hcp_vault_secrets_integration_azure} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsIntegrationAzureConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsIntegrationAzureConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _clientSecret;
    get clientSecret(): VaultSecretsIntegrationAzureClientSecretAOutputReference;
    putClientSecret(value: VaultSecretsIntegrationAzureClientSecretA): void;
    resetClientSecret(): void;
    get clientSecretInput(): cdktn.IResolvable | VaultSecretsIntegrationAzureClientSecretA | undefined;
    private _federatedWorkloadIdentity;
    get federatedWorkloadIdentity(): VaultSecretsIntegrationAzureFederatedWorkloadIdentityAOutputReference;
    putFederatedWorkloadIdentity(value: VaultSecretsIntegrationAzureFederatedWorkloadIdentityA): void;
    resetFederatedWorkloadIdentity(): void;
    get federatedWorkloadIdentityInput(): cdktn.IResolvable | VaultSecretsIntegrationAzureFederatedWorkloadIdentityA | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
