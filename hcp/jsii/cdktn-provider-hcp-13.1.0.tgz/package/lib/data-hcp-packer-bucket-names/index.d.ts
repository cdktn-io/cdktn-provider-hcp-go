/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpPackerBucketNamesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_bucket_names#id DataHcpPackerBucketNames#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the HCP project where the HCP Packer registry is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_bucket_names#project_id DataHcpPackerBucketNames#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_bucket_names#timeouts DataHcpPackerBucketNames#timeouts}
    */
    readonly timeouts?: DataHcpPackerBucketNamesTimeouts;
}
export interface DataHcpPackerBucketNamesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_bucket_names#default DataHcpPackerBucketNames#default}
    */
    readonly default?: string;
}
export declare function dataHcpPackerBucketNamesTimeoutsToTerraform(struct?: DataHcpPackerBucketNamesTimeouts | cdktn.IResolvable): any;
export declare function dataHcpPackerBucketNamesTimeoutsToHclTerraform(struct?: DataHcpPackerBucketNamesTimeouts | cdktn.IResolvable): any;
export declare class DataHcpPackerBucketNamesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpPackerBucketNamesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpPackerBucketNamesTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_bucket_names hcp_packer_bucket_names}
*/
export declare class DataHcpPackerBucketNames extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_packer_bucket_names";
    /**
    * Generates CDKTN code for importing a DataHcpPackerBucketNames resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpPackerBucketNames to import
    * @param importFromId The id of the existing DataHcpPackerBucketNames that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_bucket_names#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpPackerBucketNames to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_bucket_names hcp_packer_bucket_names} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpPackerBucketNamesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpPackerBucketNamesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get names(): string[];
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataHcpPackerBucketNamesTimeoutsOutputReference;
    putTimeouts(value: DataHcpPackerBucketNamesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpPackerBucketNamesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
