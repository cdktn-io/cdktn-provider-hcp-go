/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BoundaryClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The time to live for the auth token in golang's time.Duration string format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#auth_token_time_to_live BoundaryCluster#auth_token_time_to_live}
    */
    readonly authTokenTimeToLive?: string;
    /**
    * The time to stale for the auth token in golang's time.Duration string format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#auth_token_time_to_stale BoundaryCluster#auth_token_time_to_stale}
    */
    readonly authTokenTimeToStale?: string;
    /**
    * The ID of the Boundary cluster
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#cluster_id BoundaryCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#id BoundaryCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The password of the initial admin user. This must be at least 8 characters in length. Note that this may show up in logs, and it will be stored in the state file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#password BoundaryCluster#password}
    */
    readonly password: string;
    /**
    *
    * The ID of the HCP project where the Boundary cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#project_id BoundaryCluster#project_id}
    */
    readonly projectId?: string;
    /**
    * The tier that the HCP Boundary cluster will be provisioned as, 'Standard' or 'Plus'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#tier BoundaryCluster#tier}
    */
    readonly tier: string;
    /**
    * The username of the initial admin user. This must be at least 3 characters in length, alphanumeric, hyphen, or period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#username BoundaryCluster#username}
    */
    readonly username: string;
    /**
    * maintenance_window_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#maintenance_window_config BoundaryCluster#maintenance_window_config}
    */
    readonly maintenanceWindowConfig?: BoundaryClusterMaintenanceWindowConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#timeouts BoundaryCluster#timeouts}
    */
    readonly timeouts?: BoundaryClusterTimeouts;
}
export interface BoundaryClusterMaintenanceWindowConfig {
    /**
    * The maintenance day of the week for scheduled upgrades. Valid options for maintenance window day - `MONDAY`, `TUESDAY`, `WEDNESDAY`, `THURSDAY`, `FRIDAY`, `SATURDAY`, `SUNDAY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#day BoundaryCluster#day}
    */
    readonly day?: string;
    /**
    * The end time which upgrades can be performed. Uses 24H clock and must be in UTC time zone. Valid options include - 1 to 24 (inclusive)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#end BoundaryCluster#end}
    */
    readonly end?: number;
    /**
    * The start time which upgrades can be performed. Uses 24H clock and must be in UTC time zone. Valid options include - 0 to 23 (inclusive)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#start BoundaryCluster#start}
    */
    readonly start?: number;
    /**
    * The upgrade type for the cluster. Valid options for upgrade type - `AUTOMATIC`, `SCHEDULED`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#upgrade_type BoundaryCluster#upgrade_type}
    */
    readonly upgradeType?: string;
}
export declare function boundaryClusterMaintenanceWindowConfigToTerraform(struct?: BoundaryClusterMaintenanceWindowConfigOutputReference | BoundaryClusterMaintenanceWindowConfig): any;
export declare function boundaryClusterMaintenanceWindowConfigToHclTerraform(struct?: BoundaryClusterMaintenanceWindowConfigOutputReference | BoundaryClusterMaintenanceWindowConfig): any;
export declare class BoundaryClusterMaintenanceWindowConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BoundaryClusterMaintenanceWindowConfig | undefined;
    set internalValue(value: BoundaryClusterMaintenanceWindowConfig | undefined);
    private _day?;
    get day(): string;
    set day(value: string);
    resetDay(): void;
    get dayInput(): string | undefined;
    private _end?;
    get end(): number;
    set end(value: number);
    resetEnd(): void;
    get endInput(): number | undefined;
    private _start?;
    get start(): number;
    set start(value: number);
    resetStart(): void;
    get startInput(): number | undefined;
    private _upgradeType?;
    get upgradeType(): string;
    set upgradeType(value: string);
    resetUpgradeType(): void;
    get upgradeTypeInput(): string | undefined;
}
export interface BoundaryClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#create BoundaryCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#default BoundaryCluster#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#delete BoundaryCluster#delete}
    */
    readonly delete?: string;
}
export declare function boundaryClusterTimeoutsToTerraform(struct?: BoundaryClusterTimeouts | cdktn.IResolvable): any;
export declare function boundaryClusterTimeoutsToHclTerraform(struct?: BoundaryClusterTimeouts | cdktn.IResolvable): any;
export declare class BoundaryClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BoundaryClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BoundaryClusterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster hcp_boundary_cluster}
*/
export declare class BoundaryCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_boundary_cluster";
    /**
    * Generates CDKTN code for importing a BoundaryCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BoundaryCluster to import
    * @param importFromId The id of the existing BoundaryCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BoundaryCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/boundary_cluster hcp_boundary_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BoundaryClusterConfig
    */
    constructor(scope: Construct, id: string, config: BoundaryClusterConfig);
    private _authTokenTimeToLive?;
    get authTokenTimeToLive(): string;
    set authTokenTimeToLive(value: string);
    resetAuthTokenTimeToLive(): void;
    get authTokenTimeToLiveInput(): string | undefined;
    private _authTokenTimeToStale?;
    get authTokenTimeToStale(): string;
    set authTokenTimeToStale(value: string);
    resetAuthTokenTimeToStale(): void;
    get authTokenTimeToStaleInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get clusterUrl(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get state(): string;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    get tierInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    get version(): string;
    private _maintenanceWindowConfig;
    get maintenanceWindowConfig(): BoundaryClusterMaintenanceWindowConfigOutputReference;
    putMaintenanceWindowConfig(value: BoundaryClusterMaintenanceWindowConfig): void;
    resetMaintenanceWindowConfig(): void;
    get maintenanceWindowConfigInput(): BoundaryClusterMaintenanceWindowConfig | undefined;
    private _timeouts;
    get timeouts(): BoundaryClusterTimeoutsOutputReference;
    putTimeouts(value: BoundaryClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BoundaryClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
