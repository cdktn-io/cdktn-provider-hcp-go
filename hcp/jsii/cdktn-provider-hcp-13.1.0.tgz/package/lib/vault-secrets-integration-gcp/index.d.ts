/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultSecretsIntegrationGcpConfig extends cdktn.TerraformMetaArguments {
    /**
    * Capabilities enabled for the integration. See the Vault Secrets documentation for the list of supported capabilities per provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#capabilities VaultSecretsIntegrationGcp#capabilities}
    */
    readonly capabilities: string[];
    /**
    * (Recommended) Federated identity configuration to authenticate against the target GCP project. Cannot be used with `service_account_key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#federated_workload_identity VaultSecretsIntegrationGcp#federated_workload_identity}
    */
    readonly federatedWorkloadIdentity?: VaultSecretsIntegrationGcpFederatedWorkloadIdentityA;
    /**
    * The Vault Secrets integration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#name VaultSecretsIntegrationGcp#name}
    */
    readonly name: string;
    /**
    * HCP project ID that owns the HCP Vault Secrets integration. Inferred from the provider configuration if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#project_id VaultSecretsIntegrationGcp#project_id}
    */
    readonly projectId?: string;
    /**
    * GCP service account key used to authenticate against the target GCP project. Cannot be used with `federated_workload_identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#service_account_key VaultSecretsIntegrationGcp#service_account_key}
    */
    readonly serviceAccountKey?: VaultSecretsIntegrationGcpServiceAccountKeyA;
}
export interface VaultSecretsIntegrationGcpFederatedWorkloadIdentityA {
    /**
    * Audience configured on the GCP identity provider to federate access with HCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#audience VaultSecretsIntegrationGcp#audience}
    */
    readonly audience: string;
    /**
    * GCP service account email that HVS will impersonate to carry operations for the appropriate capabilities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#service_account_email VaultSecretsIntegrationGcp#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function vaultSecretsIntegrationGcpFederatedWorkloadIdentityAToTerraform(struct?: VaultSecretsIntegrationGcpFederatedWorkloadIdentityA | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationGcpFederatedWorkloadIdentityAToHclTerraform(struct?: VaultSecretsIntegrationGcpFederatedWorkloadIdentityA | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationGcpFederatedWorkloadIdentityAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationGcpFederatedWorkloadIdentityA | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationGcpFederatedWorkloadIdentityA | cdktn.IResolvable | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    get audienceInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
export interface VaultSecretsIntegrationGcpServiceAccountKeyA {
    /**
    * JSON or base64 encoded service account key received from GCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#credentials VaultSecretsIntegrationGcp#credentials}
    */
    readonly credentials: string;
}
export declare function vaultSecretsIntegrationGcpServiceAccountKeyAToTerraform(struct?: VaultSecretsIntegrationGcpServiceAccountKeyA | cdktn.IResolvable): any;
export declare function vaultSecretsIntegrationGcpServiceAccountKeyAToHclTerraform(struct?: VaultSecretsIntegrationGcpServiceAccountKeyA | cdktn.IResolvable): any;
export declare class VaultSecretsIntegrationGcpServiceAccountKeyAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultSecretsIntegrationGcpServiceAccountKeyA | cdktn.IResolvable | undefined;
    set internalValue(value: VaultSecretsIntegrationGcpServiceAccountKeyA | cdktn.IResolvable | undefined);
    get clientEmail(): string;
    private _credentials?;
    get credentials(): string;
    set credentials(value: string);
    get credentialsInput(): string | undefined;
    get projectId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp hcp_vault_secrets_integration_gcp}
*/
export declare class VaultSecretsIntegrationGcp extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_secrets_integration_gcp";
    /**
    * Generates CDKTN code for importing a VaultSecretsIntegrationGcp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultSecretsIntegrationGcp to import
    * @param importFromId The id of the existing VaultSecretsIntegrationGcp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultSecretsIntegrationGcp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/vault_secrets_integration_gcp hcp_vault_secrets_integration_gcp} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultSecretsIntegrationGcpConfig
    */
    constructor(scope: Construct, id: string, config: VaultSecretsIntegrationGcpConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _federatedWorkloadIdentity;
    get federatedWorkloadIdentity(): VaultSecretsIntegrationGcpFederatedWorkloadIdentityAOutputReference;
    putFederatedWorkloadIdentity(value: VaultSecretsIntegrationGcpFederatedWorkloadIdentityA): void;
    resetFederatedWorkloadIdentity(): void;
    get federatedWorkloadIdentityInput(): cdktn.IResolvable | VaultSecretsIntegrationGcpFederatedWorkloadIdentityA | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get resourceId(): string;
    get resourceName(): string;
    private _serviceAccountKey;
    get serviceAccountKey(): VaultSecretsIntegrationGcpServiceAccountKeyAOutputReference;
    putServiceAccountKey(value: VaultSecretsIntegrationGcpServiceAccountKeyA): void;
    resetServiceAccountKey(): void;
    get serviceAccountKeyInput(): cdktn.IResolvable | VaultSecretsIntegrationGcpServiceAccountKeyA | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
