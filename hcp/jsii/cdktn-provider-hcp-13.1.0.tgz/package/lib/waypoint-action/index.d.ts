/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaypointActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the Action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#description WaypointAction#description}
    */
    readonly description?: string;
    /**
    * The name of the Action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#name WaypointAction#name}
    */
    readonly name: string;
    /**
    * The ID of the HCP project where the Action is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#project_id WaypointAction#project_id}
    */
    readonly projectId?: string;
    /**
    * The kind of HTTP request this should trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#request WaypointAction#request}
    */
    readonly request: WaypointActionRequest;
}
export interface WaypointActionRequestAgent {
    /**
    * An optional action run id. If specified the agent will interact with the actions subsystem.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#action_run_id WaypointAction#action_run_id}
    */
    readonly actionRunId?: string;
    /**
    * Arguments to the operation, specified as JSON.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#body WaypointAction#body}
    */
    readonly body?: string;
    /**
    * The name of the group that the operation is in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#group WaypointAction#group}
    */
    readonly group: string;
    /**
    * The identifying name of the operation in the agent config file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#operation_id WaypointAction#operation_id}
    */
    readonly operationId: string;
}
export declare function waypointActionRequestAgentToTerraform(struct?: WaypointActionRequestAgent | cdktn.IResolvable): any;
export declare function waypointActionRequestAgentToHclTerraform(struct?: WaypointActionRequestAgent | cdktn.IResolvable): any;
export declare class WaypointActionRequestAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WaypointActionRequestAgent | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointActionRequestAgent | cdktn.IResolvable | undefined);
    private _actionRunId?;
    get actionRunId(): string;
    set actionRunId(value: string);
    resetActionRunId(): void;
    get actionRunIdInput(): string | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _operationId?;
    get operationId(): string;
    set operationId(value: string);
    get operationIdInput(): string | undefined;
}
export interface WaypointActionRequestCustom {
    /**
    * The body to be submitted with the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#body WaypointAction#body}
    */
    readonly body?: string;
    /**
    * Key value headers to send with the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#headers WaypointAction#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * The HTTP method to use for the request. Must be one of: 'GET', 'POST', 'PUT', 'DELETE', or 'PATCH'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#method WaypointAction#method}
    */
    readonly method: string;
    /**
    * The full URL this request should make when invoked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#url WaypointAction#url}
    */
    readonly url?: string;
}
export declare function waypointActionRequestCustomToTerraform(struct?: WaypointActionRequestCustom | cdktn.IResolvable): any;
export declare function waypointActionRequestCustomToHclTerraform(struct?: WaypointActionRequestCustom | cdktn.IResolvable): any;
export declare class WaypointActionRequestCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WaypointActionRequestCustom | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointActionRequestCustom | cdktn.IResolvable | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface WaypointActionRequest {
    /**
    * Agent mode allows users to define the agent to use for the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#agent WaypointAction#agent}
    */
    readonly agent?: WaypointActionRequestAgent;
    /**
    * Custom mode allows users to define the HTTP method, the request body, etc.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#custom WaypointAction#custom}
    */
    readonly custom?: WaypointActionRequestCustom;
}
export declare function waypointActionRequestToTerraform(struct?: WaypointActionRequest | cdktn.IResolvable): any;
export declare function waypointActionRequestToHclTerraform(struct?: WaypointActionRequest | cdktn.IResolvable): any;
export declare class WaypointActionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WaypointActionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointActionRequest | cdktn.IResolvable | undefined);
    private _agent;
    get agent(): WaypointActionRequestAgentOutputReference;
    putAgent(value: WaypointActionRequestAgent): void;
    resetAgent(): void;
    get agentInput(): cdktn.IResolvable | WaypointActionRequestAgent | undefined;
    private _custom;
    get custom(): WaypointActionRequestCustomOutputReference;
    putCustom(value: WaypointActionRequestCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | WaypointActionRequestCustom | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action hcp_waypoint_action}
*/
export declare class WaypointAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_waypoint_action";
    /**
    * Generates CDKTN code for importing a WaypointAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaypointAction to import
    * @param importFromId The id of the existing WaypointAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaypointAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/waypoint_action hcp_waypoint_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaypointActionConfig
    */
    constructor(scope: Construct, id: string, config: WaypointActionConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _request;
    get request(): WaypointActionRequestOutputReference;
    putRequest(value: WaypointActionRequest): void;
    get requestInput(): cdktn.IResolvable | WaypointActionRequest | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
