/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PackerBucketIamBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * The principal to bind to the given role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/packer_bucket_iam_binding#principal_id PackerBucketIamBinding#principal_id}
    */
    readonly principalId: string;
    /**
    * The bucket's resource name in the format packer/project/<project ID>/bucket/<bucket name>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/packer_bucket_iam_binding#resource_name PackerBucketIamBinding#resource_name}
    */
    readonly resourceName: string;
    /**
    * The role name to bind to the given principal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/packer_bucket_iam_binding#role PackerBucketIamBinding#role}
    */
    readonly role: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/packer_bucket_iam_binding hcp_packer_bucket_iam_binding}
*/
export declare class PackerBucketIamBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_packer_bucket_iam_binding";
    /**
    * Generates CDKTN code for importing a PackerBucketIamBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PackerBucketIamBinding to import
    * @param importFromId The id of the existing PackerBucketIamBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/packer_bucket_iam_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PackerBucketIamBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/packer_bucket_iam_binding hcp_packer_bucket_iam_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PackerBucketIamBindingConfig
    */
    constructor(scope: Construct, id: string, config: PackerBucketIamBindingConfig);
    private _principalId?;
    get principalId(): string;
    set principalId(value: string);
    get principalIdInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
