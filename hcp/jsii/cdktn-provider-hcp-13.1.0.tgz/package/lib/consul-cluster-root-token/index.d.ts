/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConsulClusterRootTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Consul cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token#cluster_id ConsulClusterRootToken#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token#id ConsulClusterRootToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the HCP Consul cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token#project_id ConsulClusterRootToken#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token#timeouts ConsulClusterRootToken#timeouts}
    */
    readonly timeouts?: ConsulClusterRootTokenTimeouts;
}
export interface ConsulClusterRootTokenTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token#default ConsulClusterRootToken#default}
    */
    readonly default?: string;
}
export declare function consulClusterRootTokenTimeoutsToTerraform(struct?: ConsulClusterRootTokenTimeouts | cdktn.IResolvable): any;
export declare function consulClusterRootTokenTimeoutsToHclTerraform(struct?: ConsulClusterRootTokenTimeouts | cdktn.IResolvable): any;
export declare class ConsulClusterRootTokenTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConsulClusterRootTokenTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ConsulClusterRootTokenTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token hcp_consul_cluster_root_token}
*/
export declare class ConsulClusterRootToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_consul_cluster_root_token";
    /**
    * Generates CDKTN code for importing a ConsulClusterRootToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConsulClusterRootToken to import
    * @param importFromId The id of the existing ConsulClusterRootToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConsulClusterRootToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/consul_cluster_root_token hcp_consul_cluster_root_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConsulClusterRootTokenConfig
    */
    constructor(scope: Construct, id: string, config: ConsulClusterRootTokenConfig);
    get accessorId(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kubernetesSecret(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get secretId(): string;
    private _timeouts;
    get timeouts(): ConsulClusterRootTokenTimeoutsOutputReference;
    putTimeouts(value: ConsulClusterRootTokenTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ConsulClusterRootTokenTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
