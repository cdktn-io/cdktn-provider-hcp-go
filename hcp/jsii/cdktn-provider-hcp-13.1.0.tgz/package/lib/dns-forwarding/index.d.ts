/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsForwardingConfig extends cdktn.TerraformMetaArguments {
    /**
    * The connection type for DNS forwarding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#connection_type DnsForwarding#connection_type}
    */
    readonly connectionType: string;
    /**
    * The ID of the DNS forwarding configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#dns_forwarding_id DnsForwarding#dns_forwarding_id}
    */
    readonly dnsForwardingId: string;
    /**
    * The ID of the HVN that this DNS forwarding belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#hvn_id DnsForwarding#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#id DnsForwarding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the peering connection for DNS forwarding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#peering_id DnsForwarding#peering_id}
    */
    readonly peeringId: string;
    /**
    *
    * The ID of the HCP project where the DNS forwarding is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#project_id DnsForwarding#project_id}
    */
    readonly projectId?: string;
    /**
    * forwarding_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#forwarding_rule DnsForwarding#forwarding_rule}
    */
    readonly forwardingRule: DnsForwardingForwardingRule;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#timeouts DnsForwarding#timeouts}
    */
    readonly timeouts?: DnsForwardingTimeouts;
}
export interface DnsForwardingForwardingRule {
    /**
    * The domain name for DNS forwarding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#domain_name DnsForwarding#domain_name}
    */
    readonly domainName: string;
    /**
    * The list of inbound endpoint IP addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#inbound_endpoint_ips DnsForwarding#inbound_endpoint_ips}
    */
    readonly inboundEndpointIps: string[];
    /**
    * The ID of the forwarding rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#rule_id DnsForwarding#rule_id}
    */
    readonly ruleId: string;
}
export declare function dnsForwardingForwardingRuleToTerraform(struct?: DnsForwardingForwardingRuleOutputReference | DnsForwardingForwardingRule): any;
export declare function dnsForwardingForwardingRuleToHclTerraform(struct?: DnsForwardingForwardingRuleOutputReference | DnsForwardingForwardingRule): any;
export declare class DnsForwardingForwardingRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DnsForwardingForwardingRule | undefined;
    set internalValue(value: DnsForwardingForwardingRule | undefined);
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _inboundEndpointIps?;
    get inboundEndpointIps(): string[];
    set inboundEndpointIps(value: string[]);
    get inboundEndpointIpsInput(): string[] | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
}
export interface DnsForwardingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#create DnsForwarding#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#default DnsForwarding#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#delete DnsForwarding#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#read DnsForwarding#read}
    */
    readonly read?: string;
}
export declare function dnsForwardingTimeoutsToTerraform(struct?: DnsForwardingTimeouts | cdktn.IResolvable): any;
export declare function dnsForwardingTimeoutsToHclTerraform(struct?: DnsForwardingTimeouts | cdktn.IResolvable): any;
export declare class DnsForwardingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DnsForwardingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DnsForwardingTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding hcp_dns_forwarding}
*/
export declare class DnsForwarding extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_dns_forwarding";
    /**
    * Generates CDKTN code for importing a DnsForwarding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsForwarding to import
    * @param importFromId The id of the existing DnsForwarding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsForwarding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/dns_forwarding hcp_dns_forwarding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsForwardingConfig
    */
    constructor(scope: Construct, id: string, config: DnsForwardingConfig);
    private _connectionType?;
    get connectionType(): string;
    set connectionType(value: string);
    get connectionTypeInput(): string | undefined;
    get createdAt(): string;
    private _dnsForwardingId?;
    get dnsForwardingId(): string;
    set dnsForwardingId(value: string);
    get dnsForwardingIdInput(): string | undefined;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _peeringId?;
    get peeringId(): string;
    set peeringId(value: string);
    get peeringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    private _forwardingRule;
    get forwardingRule(): DnsForwardingForwardingRuleOutputReference;
    putForwardingRule(value: DnsForwardingForwardingRule): void;
    get forwardingRuleInput(): DnsForwardingForwardingRule | undefined;
    private _timeouts;
    get timeouts(): DnsForwardingTimeoutsOutputReference;
    putTimeouts(value: DnsForwardingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DnsForwardingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
