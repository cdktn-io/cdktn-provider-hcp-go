/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpWaypointApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of actions by 'ID' to assign to this Template. Applications created from this Template will have these actions assigned to them. Only 'ID' is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application#actions DataHcpWaypointApplication#actions}
    */
    readonly actions?: string[];
    /**
    * The ID of the Application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application#id DataHcpWaypointApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Input variables for the Application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application#input_variables DataHcpWaypointApplication#input_variables}
    */
    readonly inputVariables?: DataHcpWaypointApplicationInputVariables[] | cdktn.IResolvable;
    /**
    * The name of the Application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application#name DataHcpWaypointApplication#name}
    */
    readonly name?: string;
    /**
    * The ID of the HCP project where the Waypoint Application is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application#project_id DataHcpWaypointApplication#project_id}
    */
    readonly projectId?: string;
}
export interface DataHcpWaypointApplicationInputVariables {
}
export declare function dataHcpWaypointApplicationInputVariablesToTerraform(struct?: DataHcpWaypointApplicationInputVariables | cdktn.IResolvable): any;
export declare function dataHcpWaypointApplicationInputVariablesToHclTerraform(struct?: DataHcpWaypointApplicationInputVariables | cdktn.IResolvable): any;
export declare class DataHcpWaypointApplicationInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpWaypointApplicationInputVariables | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpWaypointApplicationInputVariables | cdktn.IResolvable | undefined);
    get name(): string;
    get value(): string;
    get variableType(): string;
}
export declare class DataHcpWaypointApplicationInputVariablesList extends cdktn.ComplexList {
    internalValue?: DataHcpWaypointApplicationInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpWaypointApplicationInputVariablesOutputReference;
}
export interface DataHcpWaypointApplicationOutputValues {
}
export declare function dataHcpWaypointApplicationOutputValuesToTerraform(struct?: DataHcpWaypointApplicationOutputValues): any;
export declare function dataHcpWaypointApplicationOutputValuesToHclTerraform(struct?: DataHcpWaypointApplicationOutputValues): any;
export declare class DataHcpWaypointApplicationOutputValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpWaypointApplicationOutputValues | undefined;
    set internalValue(value: DataHcpWaypointApplicationOutputValues | undefined);
    get name(): string;
    get sensitive(): cdktn.IResolvable;
    get type(): string;
    get value(): string;
}
export declare class DataHcpWaypointApplicationOutputValuesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpWaypointApplicationOutputValuesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application hcp_waypoint_application}
*/
export declare class DataHcpWaypointApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_waypoint_application";
    /**
    * Generates CDKTN code for importing a DataHcpWaypointApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpWaypointApplication to import
    * @param importFromId The id of the existing DataHcpWaypointApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpWaypointApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_application hcp_waypoint_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpWaypointApplicationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpWaypointApplicationConfig);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    resetActions(): void;
    get actionsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputVariables;
    get inputVariables(): DataHcpWaypointApplicationInputVariablesList;
    putInputVariables(value: DataHcpWaypointApplicationInputVariables[] | cdktn.IResolvable): void;
    resetInputVariables(): void;
    get inputVariablesInput(): cdktn.IResolvable | DataHcpWaypointApplicationInputVariables[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get namespaceId(): string;
    get organizationId(): string;
    private _outputValues;
    get outputValues(): DataHcpWaypointApplicationOutputValuesList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get readmeMarkdown(): string;
    get templateId(): string;
    get templateName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
