/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkPeeringConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#hvn_id AwsNetworkPeering#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#id AwsNetworkPeering#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The account ID of the peer VPC in AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#peer_account_id AwsNetworkPeering#peer_account_id}
    */
    readonly peerAccountId: string;
    /**
    * The ID of the peer VPC in AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#peer_vpc_id AwsNetworkPeering#peer_vpc_id}
    */
    readonly peerVpcId: string;
    /**
    * The region of the peer VPC in AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#peer_vpc_region AwsNetworkPeering#peer_vpc_region}
    */
    readonly peerVpcRegion: string;
    /**
    * The ID of the network peering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#peering_id AwsNetworkPeering#peering_id}
    */
    readonly peeringId: string;
    /**
    *
    * The ID of the HCP project where the network peering is located. Always matches the HVN's project.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#project_id AwsNetworkPeering#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#timeouts AwsNetworkPeering#timeouts}
    */
    readonly timeouts?: AwsNetworkPeeringTimeouts;
}
export interface AwsNetworkPeeringTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#create AwsNetworkPeering#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#default AwsNetworkPeering#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#delete AwsNetworkPeering#delete}
    */
    readonly delete?: string;
}
export declare function awsNetworkPeeringTimeoutsToTerraform(struct?: AwsNetworkPeeringTimeouts | cdktn.IResolvable): any;
export declare function awsNetworkPeeringTimeoutsToHclTerraform(struct?: AwsNetworkPeeringTimeouts | cdktn.IResolvable): any;
export declare class AwsNetworkPeeringTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AwsNetworkPeeringTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AwsNetworkPeeringTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering hcp_aws_network_peering}
*/
export declare class AwsNetworkPeering extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_aws_network_peering";
    /**
    * Generates CDKTN code for importing a AwsNetworkPeering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkPeering to import
    * @param importFromId The id of the existing AwsNetworkPeering that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkPeering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/resources/aws_network_peering hcp_aws_network_peering} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkPeeringConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkPeeringConfig);
    get createdAt(): string;
    get expiresAt(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _peerAccountId?;
    get peerAccountId(): string;
    set peerAccountId(value: string);
    get peerAccountIdInput(): string | undefined;
    private _peerVpcId?;
    get peerVpcId(): string;
    set peerVpcId(value: string);
    get peerVpcIdInput(): string | undefined;
    private _peerVpcRegion?;
    get peerVpcRegion(): string;
    set peerVpcRegion(value: string);
    get peerVpcRegionInput(): string | undefined;
    private _peeringId?;
    get peeringId(): string;
    set peeringId(value: string);
    get peeringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get providerPeeringId(): string;
    get selfLink(): string;
    get state(): string;
    private _timeouts;
    get timeouts(): AwsNetworkPeeringTimeoutsOutputReference;
    putTimeouts(value: AwsNetworkPeeringTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsNetworkPeeringTimeouts | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
