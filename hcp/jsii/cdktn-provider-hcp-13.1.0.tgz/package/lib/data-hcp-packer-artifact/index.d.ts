/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpPackerArtifactConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the HCP Packer Bucket where the Artifact is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#bucket_name DataHcpPackerArtifact#bucket_name}
    */
    readonly bucketName: string;
    /**
    *
    * The name of the HCP Packer Channel the Version containing this Artifact is assigned to.
    * The Version currently assigned to the Channel will be fetched.
    * Exactly one of `channel_name` or `version_fingerprint` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#channel_name DataHcpPackerArtifact#channel_name}
    */
    readonly channelName?: string;
    /**
    * Name of the Packer builder that built this Artifact. Ex: `amazon-ebs.example`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#component_type DataHcpPackerArtifact#component_type}
    */
    readonly componentType?: string;
    /**
    * When set (non-empty) with `channel_name`, the data source uses **GetImageByBuildLabels**: the channel's current version is scanned for builds whose labels contain every key/value you supply.
    *
    * If more than one build matches, the HCP Packer API returns the **first** candidate in **`updated_at` descending** order that also matches the **`platform`** and **`region`** you configure (sent as cloud provider and region). Always set `platform` and `region` so the result is predictable when multiple builds or clouds exist.
    *
    * If several builds still match the same platform and region (for example different Packer sources), use **`component_type`** to disambiguate, consistent with the non-label lookup path.
    *
    * When `labels` is unset or empty, this attribute is computed from the resolved build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#labels DataHcpPackerArtifact#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the platform where the HCP Packer Artifact is stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#platform DataHcpPackerArtifact#platform}
    */
    readonly platform: string;
    /**
    * The ID of the HCP Organization where the Artifact is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#project_id DataHcpPackerArtifact#project_id}
    */
    readonly projectId?: string;
    /**
    * The Region where the HCP Packer Artifact is stored, if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#region DataHcpPackerArtifact#region}
    */
    readonly region: string;
    /**
    *
    * The fingerprint of the HCP Packer Version where the Artifact is located.
    * If provided in the config, it is used to fetch the Version.
    * Exactly one of `channel_name` or `version_fingerprint` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#version_fingerprint DataHcpPackerArtifact#version_fingerprint}
    */
    readonly versionFingerprint?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact hcp_packer_artifact}
*/
export declare class DataHcpPackerArtifact extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_packer_artifact";
    /**
    * Generates CDKTN code for importing a DataHcpPackerArtifact resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpPackerArtifact to import
    * @param importFromId The id of the existing DataHcpPackerArtifact that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpPackerArtifact to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/packer_artifact hcp_packer_artifact} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpPackerArtifactConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpPackerArtifactConfig);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    get buildId(): string;
    private _channelName?;
    get channelName(): string;
    set channelName(value: string);
    resetChannelName(): void;
    get channelNameInput(): string | undefined;
    private _componentType?;
    get componentType(): string;
    set componentType(value: string);
    resetComponentType(): void;
    get componentTypeInput(): string | undefined;
    get createdAt(): string;
    get externalIdentifier(): string;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get organizationId(): string;
    get packerRunUuid(): string;
    private _platform?;
    get platform(): string;
    set platform(value: string);
    get platformInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get revokeAt(): string;
    private _versionFingerprint?;
    get versionFingerprint(): string;
    set versionFingerprint(value: string);
    resetVersionFingerprint(): void;
    get versionFingerprintInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
