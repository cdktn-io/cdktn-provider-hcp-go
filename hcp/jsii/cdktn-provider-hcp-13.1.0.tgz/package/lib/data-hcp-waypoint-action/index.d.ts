/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpWaypointActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_action#id DataHcpWaypointAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_action#name DataHcpWaypointAction#name}
    */
    readonly name?: string;
}
export interface DataHcpWaypointActionRequestAgent {
}
export declare function dataHcpWaypointActionRequestAgentToTerraform(struct?: DataHcpWaypointActionRequestAgent | cdktn.IResolvable): any;
export declare function dataHcpWaypointActionRequestAgentToHclTerraform(struct?: DataHcpWaypointActionRequestAgent | cdktn.IResolvable): any;
export declare class DataHcpWaypointActionRequestAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpWaypointActionRequestAgent | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpWaypointActionRequestAgent | cdktn.IResolvable | undefined);
    get actionRunId(): string;
    get body(): string;
    get group(): string;
    get operationId(): string;
}
export interface DataHcpWaypointActionRequestCustom {
}
export declare function dataHcpWaypointActionRequestCustomToTerraform(struct?: DataHcpWaypointActionRequestCustom): any;
export declare function dataHcpWaypointActionRequestCustomToHclTerraform(struct?: DataHcpWaypointActionRequestCustom): any;
export declare class DataHcpWaypointActionRequestCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpWaypointActionRequestCustom | undefined;
    set internalValue(value: DataHcpWaypointActionRequestCustom | undefined);
    get body(): string;
    private _headers;
    get headers(): cdktn.StringMap;
    get method(): string;
    get url(): string;
}
export interface DataHcpWaypointActionRequest {
    /**
    * Agent mode allows users to define the agent to use for the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_action#agent DataHcpWaypointAction#agent}
    */
    readonly agent?: DataHcpWaypointActionRequestAgent;
}
export declare function dataHcpWaypointActionRequestToTerraform(struct?: DataHcpWaypointActionRequest): any;
export declare function dataHcpWaypointActionRequestToHclTerraform(struct?: DataHcpWaypointActionRequest): any;
export declare class DataHcpWaypointActionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpWaypointActionRequest | undefined;
    set internalValue(value: DataHcpWaypointActionRequest | undefined);
    private _agent;
    get agent(): DataHcpWaypointActionRequestAgentOutputReference;
    putAgent(value: DataHcpWaypointActionRequestAgent): void;
    resetAgent(): void;
    get agentInput(): cdktn.IResolvable | DataHcpWaypointActionRequestAgent | undefined;
    private _custom;
    get custom(): DataHcpWaypointActionRequestCustomOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_action hcp_waypoint_action}
*/
export declare class DataHcpWaypointAction extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_waypoint_action";
    /**
    * Generates CDKTN code for importing a DataHcpWaypointAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpWaypointAction to import
    * @param importFromId The id of the existing DataHcpWaypointAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpWaypointAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.114.0/docs/data-sources/waypoint_action hcp_waypoint_action} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpWaypointActionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpWaypointActionConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get organizationId(): string;
    get projectId(): string;
    private _request;
    get request(): DataHcpWaypointActionRequestOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
