/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpAwsNetworkPeeringConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#hvn_id DataHcpAwsNetworkPeering#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#id DataHcpAwsNetworkPeering#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the network peering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#peering_id DataHcpAwsNetworkPeering#peering_id}
    */
    readonly peeringId: string;
    /**
    *
    * The ID of the HCP project where the network peering is located. Always matches the HVN's project.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#project_id DataHcpAwsNetworkPeering#project_id}
    */
    readonly projectId?: string;
    /**
    * If `true`, Terraform will wait for the network peering to reach an `ACTIVE` state before continuing. Default `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#wait_for_active_state DataHcpAwsNetworkPeering#wait_for_active_state}
    */
    readonly waitForActiveState?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#timeouts DataHcpAwsNetworkPeering#timeouts}
    */
    readonly timeouts?: DataHcpAwsNetworkPeeringTimeouts;
}
export interface DataHcpAwsNetworkPeeringTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#read DataHcpAwsNetworkPeering#read}
    */
    readonly read?: string;
}
export declare function dataHcpAwsNetworkPeeringTimeoutsToTerraform(struct?: DataHcpAwsNetworkPeeringTimeouts | cdktn.IResolvable): any;
export declare function dataHcpAwsNetworkPeeringTimeoutsToHclTerraform(struct?: DataHcpAwsNetworkPeeringTimeouts | cdktn.IResolvable): any;
export declare class DataHcpAwsNetworkPeeringTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpAwsNetworkPeeringTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpAwsNetworkPeeringTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering hcp_aws_network_peering}
*/
export declare class DataHcpAwsNetworkPeering extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_aws_network_peering";
    /**
    * Generates CDKTN code for importing a DataHcpAwsNetworkPeering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpAwsNetworkPeering to import
    * @param importFromId The id of the existing DataHcpAwsNetworkPeering that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpAwsNetworkPeering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/aws_network_peering hcp_aws_network_peering} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpAwsNetworkPeeringConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpAwsNetworkPeeringConfig);
    get createdAt(): string;
    get expiresAt(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    get peerAccountId(): string;
    get peerVpcId(): string;
    get peerVpcRegion(): string;
    private _peeringId?;
    get peeringId(): string;
    set peeringId(value: string);
    get peeringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get providerPeeringId(): string;
    get selfLink(): string;
    get state(): string;
    private _waitForActiveState?;
    get waitForActiveState(): boolean | cdktn.IResolvable;
    set waitForActiveState(value: boolean | cdktn.IResolvable);
    resetWaitForActiveState(): void;
    get waitForActiveStateInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): DataHcpAwsNetworkPeeringTimeoutsOutputReference;
    putTimeouts(value: DataHcpAwsNetworkPeeringTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpAwsNetworkPeeringTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
