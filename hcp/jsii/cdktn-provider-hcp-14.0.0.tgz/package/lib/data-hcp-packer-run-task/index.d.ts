/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpPackerRunTaskConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/packer_run_task#id DataHcpPackerRunTask#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the HCP Packer Registry is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/packer_run_task#project_id DataHcpPackerRunTask#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/packer_run_task#timeouts DataHcpPackerRunTask#timeouts}
    */
    readonly timeouts?: DataHcpPackerRunTaskTimeouts;
}
export interface DataHcpPackerRunTaskTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/packer_run_task#default DataHcpPackerRunTask#default}
    */
    readonly default?: string;
}
export declare function dataHcpPackerRunTaskTimeoutsToTerraform(struct?: DataHcpPackerRunTaskTimeouts | cdktn.IResolvable): any;
export declare function dataHcpPackerRunTaskTimeoutsToHclTerraform(struct?: DataHcpPackerRunTaskTimeouts | cdktn.IResolvable): any;
export declare class DataHcpPackerRunTaskTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpPackerRunTaskTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpPackerRunTaskTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/packer_run_task hcp_packer_run_task}
*/
export declare class DataHcpPackerRunTask extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_packer_run_task";
    /**
    * Generates CDKTN code for importing a DataHcpPackerRunTask resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpPackerRunTask to import
    * @param importFromId The id of the existing DataHcpPackerRunTask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/packer_run_task#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpPackerRunTask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/packer_run_task hcp_packer_run_task} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpPackerRunTaskConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpPackerRunTaskConfig);
    get endpointUrl(): string;
    get hmacKey(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataHcpPackerRunTaskTimeoutsOutputReference;
    putTimeouts(value: DataHcpPackerRunTaskTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpPackerRunTaskTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
