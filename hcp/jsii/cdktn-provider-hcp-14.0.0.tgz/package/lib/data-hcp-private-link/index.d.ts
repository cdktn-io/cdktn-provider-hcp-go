/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpPrivateLinkConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HVN associated with the private link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link#hvn_id DataHcpPrivateLink#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link#id DataHcpPrivateLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the private link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link#private_link_id DataHcpPrivateLink#private_link_id}
    */
    readonly privateLinkId: string;
    /**
    * The ID of the HCP project where the private link is located. If not specified, the project configured in the provider is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link#project_id DataHcpPrivateLink#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link#timeouts DataHcpPrivateLink#timeouts}
    */
    readonly timeouts?: DataHcpPrivateLinkTimeouts;
}
export interface DataHcpPrivateLinkTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link#default DataHcpPrivateLink#default}
    */
    readonly default?: string;
}
export declare function dataHcpPrivateLinkTimeoutsToTerraform(struct?: DataHcpPrivateLinkTimeouts | cdktn.IResolvable): any;
export declare function dataHcpPrivateLinkTimeoutsToHclTerraform(struct?: DataHcpPrivateLinkTimeouts | cdktn.IResolvable): any;
export declare class DataHcpPrivateLinkTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpPrivateLinkTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpPrivateLinkTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link hcp_private_link}
*/
export declare class DataHcpPrivateLink extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_private_link";
    /**
    * Generates CDKTN code for importing a DataHcpPrivateLink resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpPrivateLink to import
    * @param importFromId The id of the existing DataHcpPrivateLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpPrivateLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/private_link hcp_private_link} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpPrivateLinkConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpPrivateLinkConfig);
    get consumerAccounts(): string[];
    get consumerIpRanges(): string[];
    get consumerRegions(): string[];
    get createdAt(): string;
    get defaultRegion(): string;
    get externalName(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _privateLinkId?;
    get privateLinkId(): string;
    set privateLinkId(value: string);
    get privateLinkIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    get updatedAt(): string;
    get vaultClusterId(): string;
    private _timeouts;
    get timeouts(): DataHcpPrivateLinkTimeoutsOutputReference;
    putTimeouts(value: DataHcpPrivateLinkTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpPrivateLinkTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
