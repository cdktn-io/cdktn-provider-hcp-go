/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HcpProviderConfig {
    /**
    * The OAuth2 Client ID for API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#client_id HcpProvider#client_id}
    */
    readonly clientId?: string;
    /**
    * The OAuth2 Client Secret for API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#client_secret HcpProvider#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The path to an HCP credential file to use to authenticate the provider to HCP. You can alternatively set the HCP_CRED_FILE environment variable to point at a credential file as well. Using a credential file allows you to authenticate the provider as a service principal via client credentials or dynamically based on Workload Identity Federation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#credential_file HcpProvider#credential_file}
    */
    readonly credentialFile?: string;
    /**
    * The geography in which HCP resources should be created. Default is `us`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#geography HcpProvider#geography}
    */
    readonly geography?: string;
    /**
    * The default project in which resources should be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#project_id HcpProvider#project_id}
    */
    readonly projectId?: string;
    /**
    * When set to true, the provider will skip checking the HCP status page for service outages or returning warnings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#skip_status_check HcpProvider#skip_status_check}
    */
    readonly skipStatusCheck?: boolean | cdktn.IResolvable;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#alias HcpProvider#alias}
    */
    readonly alias?: string;
    /**
    * workload_identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#workload_identity HcpProvider#workload_identity}
    */
    readonly workloadIdentity?: HcpProviderWorkloadIdentity[] | cdktn.IResolvable;
}
export interface HcpProviderWorkloadIdentity {
    /**
    * The resource_name of the Workload Identity Provider to exchange the token with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#resource_name HcpProvider#resource_name}
    */
    readonly resourceName: string;
    /**
    * The JWT token retrieved from an OpenID Connect (OIDC) or OAuth2 provider. At least one of `token_file` or `token` must be set, if both are set then `token` takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#token HcpProvider#token}
    */
    readonly token?: string;
    /**
    * The path to a file containing a JWT token retrieved from an OpenID Connect (OIDC) or OAuth2 provider. At least one of `token_file` or `token` must be set, if both are set then `token` takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#token_file HcpProvider#token_file}
    */
    readonly tokenFile?: string;
}
export declare function hcpProviderWorkloadIdentityToTerraform(struct?: HcpProviderWorkloadIdentity | cdktn.IResolvable): any;
export declare function hcpProviderWorkloadIdentityToHclTerraform(struct?: HcpProviderWorkloadIdentity | cdktn.IResolvable): any;
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs hcp}
*/
export declare class HcpProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "hcp";
    /**
    * Generates CDKTN code for importing a HcpProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HcpProvider to import
    * @param importFromId The id of the existing HcpProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HcpProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs hcp} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HcpProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: HcpProviderConfig);
    private _clientId?;
    get clientId(): string | undefined;
    set clientId(value: string | undefined);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string | undefined;
    set clientSecret(value: string | undefined);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _credentialFile?;
    get credentialFile(): string | undefined;
    set credentialFile(value: string | undefined);
    resetCredentialFile(): void;
    get credentialFileInput(): string | undefined;
    private _geography?;
    get geography(): string | undefined;
    set geography(value: string | undefined);
    resetGeography(): void;
    get geographyInput(): string | undefined;
    private _projectId?;
    get projectId(): string | undefined;
    set projectId(value: string | undefined);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _skipStatusCheck?;
    get skipStatusCheck(): boolean | cdktn.IResolvable | undefined;
    set skipStatusCheck(value: boolean | cdktn.IResolvable | undefined);
    resetSkipStatusCheck(): void;
    get skipStatusCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _workloadIdentity?;
    get workloadIdentity(): HcpProviderWorkloadIdentity[] | cdktn.IResolvable | undefined;
    set workloadIdentity(value: HcpProviderWorkloadIdentity[] | cdktn.IResolvable | undefined);
    resetWorkloadIdentity(): void;
    get workloadIdentityInput(): cdktn.IResolvable | HcpProviderWorkloadIdentity[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
