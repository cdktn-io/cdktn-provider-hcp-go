/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PrivateLinkConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of consumer accounts allowed to connect to the private link. In AWS, these are IAM Principals. In Azure, these are Azure Subscription/Resource IDs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#consumer_accounts PrivateLink#consumer_accounts}
    */
    readonly consumerAccounts?: string[];
    /**
    * The list of consumer IP ranges or CIDRs allowed to connect to the HVD cluster associated with the private link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#consumer_ip_ranges PrivateLink#consumer_ip_ranges}
    */
    readonly consumerIpRanges?: string[];
    /**
    * The cloud provider regions from which consumers can connect to the private link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#consumer_regions PrivateLink#consumer_regions}
    */
    readonly consumerRegions?: string[];
    /**
    * The ID of the HVN associated with the private link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#hvn_id PrivateLink#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#id PrivateLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the private link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#private_link_id PrivateLink#private_link_id}
    */
    readonly privateLinkId: string;
    /**
    * The ID of the HCP project where the private link is located. If not specified, the project configured in the provider is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#project_id PrivateLink#project_id}
    */
    readonly projectId?: string;
    /**
    * The ID of the HCP Vault cluster associated with the private link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#vault_cluster_id PrivateLink#vault_cluster_id}
    */
    readonly vaultClusterId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#timeouts PrivateLink#timeouts}
    */
    readonly timeouts?: PrivateLinkTimeouts;
}
export interface PrivateLinkTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#create PrivateLink#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#default PrivateLink#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#delete PrivateLink#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#update PrivateLink#update}
    */
    readonly update?: string;
}
export declare function privateLinkTimeoutsToTerraform(struct?: PrivateLinkTimeouts | cdktn.IResolvable): any;
export declare function privateLinkTimeoutsToHclTerraform(struct?: PrivateLinkTimeouts | cdktn.IResolvable): any;
export declare class PrivateLinkTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateLinkTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateLinkTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link hcp_private_link}
*/
export declare class PrivateLink extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_private_link";
    /**
    * Generates CDKTN code for importing a PrivateLink resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrivateLink to import
    * @param importFromId The id of the existing PrivateLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrivateLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/private_link hcp_private_link} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrivateLinkConfig
    */
    constructor(scope: Construct, id: string, config: PrivateLinkConfig);
    private _consumerAccounts?;
    get consumerAccounts(): string[];
    set consumerAccounts(value: string[]);
    resetConsumerAccounts(): void;
    get consumerAccountsInput(): string[] | undefined;
    private _consumerIpRanges?;
    get consumerIpRanges(): string[];
    set consumerIpRanges(value: string[]);
    resetConsumerIpRanges(): void;
    get consumerIpRangesInput(): string[] | undefined;
    private _consumerRegions?;
    get consumerRegions(): string[];
    set consumerRegions(value: string[]);
    resetConsumerRegions(): void;
    get consumerRegionsInput(): string[] | undefined;
    get createdAt(): string;
    get defaultRegion(): string;
    get externalName(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _privateLinkId?;
    get privateLinkId(): string;
    set privateLinkId(value: string);
    get privateLinkIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    get updatedAt(): string;
    private _vaultClusterId?;
    get vaultClusterId(): string;
    set vaultClusterId(value: string);
    get vaultClusterIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): PrivateLinkTimeoutsOutputReference;
    putTimeouts(value: PrivateLinkTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PrivateLinkTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
