/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ResourceControlPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of constraint IDs to enable for the organization. Each constraint ID must be a recognized constraint returned by ListConstraints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/resource_control_policy#enabled_constraints ResourceControlPolicy#enabled_constraints}
    */
    readonly enabledConstraints: string[];
    /**
    * The ID of the organization to manage the resource control policy for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/resource_control_policy#organization_id ResourceControlPolicy#organization_id}
    */
    readonly organizationId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/resource_control_policy hcp_resource_control_policy}
*/
export declare class ResourceControlPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_resource_control_policy";
    /**
    * Generates CDKTN code for importing a ResourceControlPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ResourceControlPolicy to import
    * @param importFromId The id of the existing ResourceControlPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/resource_control_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ResourceControlPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/resource_control_policy hcp_resource_control_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResourceControlPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ResourceControlPolicyConfig);
    private _enabledConstraints?;
    get enabledConstraints(): string[];
    set enabledConstraints(value: string[]);
    get enabledConstraintsInput(): string[] | undefined;
    get etag(): string;
    get id(): string;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
