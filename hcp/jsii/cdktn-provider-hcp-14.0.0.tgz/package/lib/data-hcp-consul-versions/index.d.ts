/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpConsulVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/consul_versions#id DataHcpConsulVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/consul_versions#timeouts DataHcpConsulVersions#timeouts}
    */
    readonly timeouts?: DataHcpConsulVersionsTimeouts;
}
export interface DataHcpConsulVersionsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/consul_versions#default DataHcpConsulVersions#default}
    */
    readonly default?: string;
}
export declare function dataHcpConsulVersionsTimeoutsToTerraform(struct?: DataHcpConsulVersionsTimeouts | cdktn.IResolvable): any;
export declare function dataHcpConsulVersionsTimeoutsToHclTerraform(struct?: DataHcpConsulVersionsTimeouts | cdktn.IResolvable): any;
export declare class DataHcpConsulVersionsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpConsulVersionsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpConsulVersionsTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/consul_versions hcp_consul_versions}
*/
export declare class DataHcpConsulVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_consul_versions";
    /**
    * Generates CDKTN code for importing a DataHcpConsulVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpConsulVersions to import
    * @param importFromId The id of the existing DataHcpConsulVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/consul_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpConsulVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/consul_versions hcp_consul_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpConsulVersionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpConsulVersionsConfig);
    get available(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get preview(): string[];
    get recommended(): string;
    private _timeouts;
    get timeouts(): DataHcpConsulVersionsTimeoutsOutputReference;
    putTimeouts(value: DataHcpConsulVersionsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpConsulVersionsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
