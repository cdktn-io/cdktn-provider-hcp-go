/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaypointAddOnConfig extends cdktn.TerraformMetaArguments {
    /**
    * Input variables set for the add-on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#add_on_input_variables WaypointAddOn#add_on_input_variables}
    */
    readonly addOnInputVariables?: WaypointAddOnAddOnInputVariables[] | cdktn.IResolvable;
    /**
    * The ID of the Application that this Add-on is created for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#application_id WaypointAddOn#application_id}
    */
    readonly applicationId: string;
    /**
    * The ID of the Add-on Definition that this Add-on is created from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#definition_id WaypointAddOn#definition_id}
    */
    readonly definitionId: string;
    /**
    * The name of the Add-on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#name WaypointAddOn#name}
    */
    readonly name: string;
    /**
    * The ID of the HCP project where the Waypoint AddOn is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#project_id WaypointAddOn#project_id}
    */
    readonly projectId?: string;
}
export interface WaypointAddOnAddOnDefinitionInputVariables {
    /**
    * Variable name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#name WaypointAddOn#name}
    */
    readonly name: string;
    /**
    * Variable value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#value WaypointAddOn#value}
    */
    readonly value: string;
    /**
    * Variable type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#variable_type WaypointAddOn#variable_type}
    */
    readonly variableType?: string;
}
export declare function waypointAddOnAddOnDefinitionInputVariablesToTerraform(struct?: WaypointAddOnAddOnDefinitionInputVariables): any;
export declare function waypointAddOnAddOnDefinitionInputVariablesToHclTerraform(struct?: WaypointAddOnAddOnDefinitionInputVariables): any;
export declare class WaypointAddOnAddOnDefinitionInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointAddOnAddOnDefinitionInputVariables | undefined;
    set internalValue(value: WaypointAddOnAddOnDefinitionInputVariables | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    resetVariableType(): void;
    get variableTypeInput(): string | undefined;
}
export declare class WaypointAddOnAddOnDefinitionInputVariablesList extends cdktn.ComplexList {
    internalValue?: WaypointAddOnAddOnDefinitionInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointAddOnAddOnDefinitionInputVariablesOutputReference;
}
export interface WaypointAddOnAddOnInputVariables {
    /**
    * Variable name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#name WaypointAddOn#name}
    */
    readonly name: string;
    /**
    * Variable value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#value WaypointAddOn#value}
    */
    readonly value: string;
    /**
    * Variable type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#variable_type WaypointAddOn#variable_type}
    */
    readonly variableType: string;
}
export declare function waypointAddOnAddOnInputVariablesToTerraform(struct?: WaypointAddOnAddOnInputVariables | cdktn.IResolvable): any;
export declare function waypointAddOnAddOnInputVariablesToHclTerraform(struct?: WaypointAddOnAddOnInputVariables | cdktn.IResolvable): any;
export declare class WaypointAddOnAddOnInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointAddOnAddOnInputVariables | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointAddOnAddOnInputVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    get variableTypeInput(): string | undefined;
}
export declare class WaypointAddOnAddOnInputVariablesList extends cdktn.ComplexList {
    internalValue?: WaypointAddOnAddOnInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointAddOnAddOnInputVariablesOutputReference;
}
export interface WaypointAddOnOutputValues {
}
export declare function waypointAddOnOutputValuesToTerraform(struct?: WaypointAddOnOutputValues): any;
export declare function waypointAddOnOutputValuesToHclTerraform(struct?: WaypointAddOnOutputValues): any;
export declare class WaypointAddOnOutputValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointAddOnOutputValues | undefined;
    set internalValue(value: WaypointAddOnOutputValues | undefined);
    get name(): string;
    get sensitive(): cdktn.IResolvable;
    get type(): string;
    get value(): string;
}
export declare class WaypointAddOnOutputValuesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointAddOnOutputValuesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on hcp_waypoint_add_on}
*/
export declare class WaypointAddOn extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_waypoint_add_on";
    /**
    * Generates CDKTN code for importing a WaypointAddOn resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaypointAddOn to import
    * @param importFromId The id of the existing WaypointAddOn that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaypointAddOn to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_add_on hcp_waypoint_add_on} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaypointAddOnConfig
    */
    constructor(scope: Construct, id: string, config: WaypointAddOnConfig);
    private _addOnDefinitionInputVariables;
    get addOnDefinitionInputVariables(): WaypointAddOnAddOnDefinitionInputVariablesList;
    private _addOnInputVariables;
    get addOnInputVariables(): WaypointAddOnAddOnInputVariablesList;
    putAddOnInputVariables(value: WaypointAddOnAddOnInputVariables[] | cdktn.IResolvable): void;
    resetAddOnInputVariables(): void;
    get addOnInputVariablesInput(): cdktn.IResolvable | WaypointAddOnAddOnInputVariables[] | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get createdBy(): string;
    private _definitionId?;
    get definitionId(): string;
    set definitionId(value: string);
    get definitionIdInput(): string | undefined;
    get description(): string;
    get id(): string;
    get installCount(): number;
    get labels(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _outputValues;
    get outputValues(): WaypointAddOnOutputValuesList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get readmeMarkdown(): string;
    get status(): number;
    get summary(): string;
    get terraformNoCodeModuleSource(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
