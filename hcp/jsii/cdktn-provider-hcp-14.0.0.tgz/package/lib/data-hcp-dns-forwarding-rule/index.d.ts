/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpDnsForwardingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the DNS forwarding configuration this rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule#dns_forwarding_id DataHcpDnsForwardingRule#dns_forwarding_id}
    */
    readonly dnsForwardingId: string;
    /**
    * The ID of the DNS forwarding rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule#dns_forwarding_rule_id DataHcpDnsForwardingRule#dns_forwarding_rule_id}
    */
    readonly dnsForwardingRuleId: string;
    /**
    * The ID of the HVN that this DNS forwarding rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule#hvn_id DataHcpDnsForwardingRule#hvn_id}
    */
    readonly hvnId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule#id DataHcpDnsForwardingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    *
    * The ID of the HCP project where the DNS forwarding rule is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule#project_id DataHcpDnsForwardingRule#project_id}
    */
    readonly projectId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule hcp_dns_forwarding_rule}
*/
export declare class DataHcpDnsForwardingRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_dns_forwarding_rule";
    /**
    * Generates CDKTN code for importing a DataHcpDnsForwardingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpDnsForwardingRule to import
    * @param importFromId The id of the existing DataHcpDnsForwardingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpDnsForwardingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/dns_forwarding_rule hcp_dns_forwarding_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpDnsForwardingRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpDnsForwardingRuleConfig);
    get createdAt(): string;
    private _dnsForwardingId?;
    get dnsForwardingId(): string;
    set dnsForwardingId(value: string);
    get dnsForwardingIdInput(): string | undefined;
    private _dnsForwardingRuleId?;
    get dnsForwardingRuleId(): string;
    set dnsForwardingRuleId(value: string);
    get dnsForwardingRuleIdInput(): string | undefined;
    get domainName(): string;
    private _hvnId?;
    get hvnId(): string;
    set hvnId(value: string);
    get hvnIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inboundEndpointIps(): string[];
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get ruleId(): string;
    get selfLink(): string;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
