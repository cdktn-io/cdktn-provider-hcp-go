/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultPluginConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the HCP Vault cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#cluster_id VaultPlugin#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#id VaultPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the plugin - Valid options for plugin name - 'venafi-pki-backend'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#plugin_name VaultPlugin#plugin_name}
    */
    readonly pluginName: string;
    /**
    * The type of the plugin - Valid options for plugin type - 'SECRET', 'AUTH', 'DATABASE'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#plugin_type VaultPlugin#plugin_type}
    */
    readonly pluginType: string;
    /**
    *
    * The ID of the HCP project where the HCP Vault cluster is located.
    * If not specified, the project specified in the HCP Provider config block will be used, if configured.
    * If a project is not configured in the HCP Provider config block, the oldest project in the organization will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#project_id VaultPlugin#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#timeouts VaultPlugin#timeouts}
    */
    readonly timeouts?: VaultPluginTimeouts;
}
export interface VaultPluginTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#default VaultPlugin#default}
    */
    readonly default?: string;
}
export declare function vaultPluginTimeoutsToTerraform(struct?: VaultPluginTimeouts | cdktn.IResolvable): any;
export declare function vaultPluginTimeoutsToHclTerraform(struct?: VaultPluginTimeouts | cdktn.IResolvable): any;
export declare class VaultPluginTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VaultPluginTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: VaultPluginTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin hcp_vault_plugin}
*/
export declare class VaultPlugin extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_vault_plugin";
    /**
    * Generates CDKTN code for importing a VaultPlugin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultPlugin to import
    * @param importFromId The id of the existing VaultPlugin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultPlugin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/vault_plugin hcp_vault_plugin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultPluginConfig
    */
    constructor(scope: Construct, id: string, config: VaultPluginConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    get pluginNameInput(): string | undefined;
    private _pluginType?;
    get pluginType(): string;
    set pluginType(value: string);
    get pluginTypeInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): VaultPluginTimeoutsOutputReference;
    putTimeouts(value: VaultPluginTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | VaultPluginTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
