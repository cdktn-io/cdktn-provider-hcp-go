/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PackerBucketIamPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The policy to apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/packer_bucket_iam_policy#policy_data PackerBucketIamPolicy#policy_data}
    */
    readonly policyData: string;
    /**
    * The bucket's resource name in the format packer/project/<project ID>/bucket/<bucket name>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/packer_bucket_iam_policy#resource_name PackerBucketIamPolicy#resource_name}
    */
    readonly resourceName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/packer_bucket_iam_policy hcp_packer_bucket_iam_policy}
*/
export declare class PackerBucketIamPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_packer_bucket_iam_policy";
    /**
    * Generates CDKTN code for importing a PackerBucketIamPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PackerBucketIamPolicy to import
    * @param importFromId The id of the existing PackerBucketIamPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/packer_bucket_iam_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PackerBucketIamPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/packer_bucket_iam_policy hcp_packer_bucket_iam_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PackerBucketIamPolicyConfig
    */
    constructor(scope: Construct, id: string, config: PackerBucketIamPolicyConfig);
    get etag(): string;
    private _policyData?;
    get policyData(): string;
    set policyData(value: string);
    get policyDataInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
