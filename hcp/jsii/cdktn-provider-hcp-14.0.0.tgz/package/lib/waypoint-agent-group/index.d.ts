/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaypointAgentGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the Agent Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_agent_group#description WaypointAgentGroup#description}
    */
    readonly description?: string;
    /**
    * The name of the Agent Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_agent_group#name WaypointAgentGroup#name}
    */
    readonly name: string;
    /**
    * The ID of the Waypoint organization to which the Agent Group belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_agent_group#organization_id WaypointAgentGroup#organization_id}
    */
    readonly organizationId?: string;
    /**
    * The ID of the Waypoint project to which the Agent Group belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_agent_group#project_id WaypointAgentGroup#project_id}
    */
    readonly projectId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_agent_group hcp_waypoint_agent_group}
*/
export declare class WaypointAgentGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_waypoint_agent_group";
    /**
    * Generates CDKTN code for importing a WaypointAgentGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaypointAgentGroup to import
    * @param importFromId The id of the existing WaypointAgentGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_agent_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaypointAgentGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_agent_group hcp_waypoint_agent_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaypointAgentGroupConfig
    */
    constructor(scope: Construct, id: string, config: WaypointAgentGroupConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    resetOrganizationId(): void;
    get organizationIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
