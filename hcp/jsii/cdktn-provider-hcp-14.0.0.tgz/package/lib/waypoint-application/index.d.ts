/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaypointApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of actions by 'ID' to assign to this Template. Applications created from this Template will have these actions assigned to them. Only 'ID' is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#actions WaypointApplication#actions}
    */
    readonly actions?: string[];
    /**
    * Input variables set for the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#application_input_variables WaypointApplication#application_input_variables}
    */
    readonly applicationInputVariables?: WaypointApplicationApplicationInputVariables[] | cdktn.IResolvable;
    /**
    * The name of the Application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#name WaypointApplication#name}
    */
    readonly name: string;
    /**
    * The ID of the HCP project where the Waypoint Application is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#project_id WaypointApplication#project_id}
    */
    readonly projectId?: string;
    /**
    * Instructions for using the Application (markdown format supported). Note: this is a base64 encoded string, and can only be set in configuration after initial creation. The initial version of the README is generated from the README Template from source Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#readme_markdown WaypointApplication#readme_markdown}
    */
    readonly readmeMarkdown?: string;
    /**
    * ID of the Template this Application is based on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#template_id WaypointApplication#template_id}
    */
    readonly templateId: string;
}
export interface WaypointApplicationApplicationInputVariables {
    /**
    * Variable name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#name WaypointApplication#name}
    */
    readonly name: string;
    /**
    * Variable value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#value WaypointApplication#value}
    */
    readonly value: string;
    /**
    * Variable type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#variable_type WaypointApplication#variable_type}
    */
    readonly variableType: string;
}
export declare function waypointApplicationApplicationInputVariablesToTerraform(struct?: WaypointApplicationApplicationInputVariables | cdktn.IResolvable): any;
export declare function waypointApplicationApplicationInputVariablesToHclTerraform(struct?: WaypointApplicationApplicationInputVariables | cdktn.IResolvable): any;
export declare class WaypointApplicationApplicationInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointApplicationApplicationInputVariables | cdktn.IResolvable | undefined;
    set internalValue(value: WaypointApplicationApplicationInputVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    get variableTypeInput(): string | undefined;
}
export declare class WaypointApplicationApplicationInputVariablesList extends cdktn.ComplexList {
    internalValue?: WaypointApplicationApplicationInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointApplicationApplicationInputVariablesOutputReference;
}
export interface WaypointApplicationOutputValues {
}
export declare function waypointApplicationOutputValuesToTerraform(struct?: WaypointApplicationOutputValues): any;
export declare function waypointApplicationOutputValuesToHclTerraform(struct?: WaypointApplicationOutputValues): any;
export declare class WaypointApplicationOutputValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointApplicationOutputValues | undefined;
    set internalValue(value: WaypointApplicationOutputValues | undefined);
    get name(): string;
    get sensitive(): cdktn.IResolvable;
    get type(): string;
    get value(): string;
}
export declare class WaypointApplicationOutputValuesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointApplicationOutputValuesOutputReference;
}
export interface WaypointApplicationTemplateInputVariables {
    /**
    * Variable name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#name WaypointApplication#name}
    */
    readonly name: string;
    /**
    * Variable value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#value WaypointApplication#value}
    */
    readonly value: string;
    /**
    * Variable type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#variable_type WaypointApplication#variable_type}
    */
    readonly variableType?: string;
}
export declare function waypointApplicationTemplateInputVariablesToTerraform(struct?: WaypointApplicationTemplateInputVariables): any;
export declare function waypointApplicationTemplateInputVariablesToHclTerraform(struct?: WaypointApplicationTemplateInputVariables): any;
export declare class WaypointApplicationTemplateInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WaypointApplicationTemplateInputVariables | undefined;
    set internalValue(value: WaypointApplicationTemplateInputVariables | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    resetVariableType(): void;
    get variableTypeInput(): string | undefined;
}
export declare class WaypointApplicationTemplateInputVariablesList extends cdktn.ComplexList {
    internalValue?: WaypointApplicationTemplateInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WaypointApplicationTemplateInputVariablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application hcp_waypoint_application}
*/
export declare class WaypointApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcp_waypoint_application";
    /**
    * Generates CDKTN code for importing a WaypointApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaypointApplication to import
    * @param importFromId The id of the existing WaypointApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaypointApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/resources/waypoint_application hcp_waypoint_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaypointApplicationConfig
    */
    constructor(scope: Construct, id: string, config: WaypointApplicationConfig);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    resetActions(): void;
    get actionsInput(): string[] | undefined;
    private _applicationInputVariables;
    get applicationInputVariables(): WaypointApplicationApplicationInputVariablesList;
    putApplicationInputVariables(value: WaypointApplicationApplicationInputVariables[] | cdktn.IResolvable): void;
    resetApplicationInputVariables(): void;
    get applicationInputVariablesInput(): cdktn.IResolvable | WaypointApplicationApplicationInputVariables[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get namespaceId(): string;
    get organizationId(): string;
    private _outputValues;
    get outputValues(): WaypointApplicationOutputValuesList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _readmeMarkdown?;
    get readmeMarkdown(): string;
    set readmeMarkdown(value: string);
    resetReadmeMarkdown(): void;
    get readmeMarkdownInput(): string | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    get templateIdInput(): string | undefined;
    private _templateInputVariables;
    get templateInputVariables(): WaypointApplicationTemplateInputVariablesList;
    get templateName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
