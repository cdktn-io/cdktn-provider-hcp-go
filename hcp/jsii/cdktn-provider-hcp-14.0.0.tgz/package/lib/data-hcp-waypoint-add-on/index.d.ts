/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpWaypointAddOnConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Add-on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/waypoint_add_on#id DataHcpWaypointAddOn#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Input variables for the Add-on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/waypoint_add_on#input_variables DataHcpWaypointAddOn#input_variables}
    */
    readonly inputVariables?: DataHcpWaypointAddOnInputVariables[] | cdktn.IResolvable;
    /**
    * The name of the Add-on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/waypoint_add_on#name DataHcpWaypointAddOn#name}
    */
    readonly name?: string;
}
export interface DataHcpWaypointAddOnInputVariables {
}
export declare function dataHcpWaypointAddOnInputVariablesToTerraform(struct?: DataHcpWaypointAddOnInputVariables | cdktn.IResolvable): any;
export declare function dataHcpWaypointAddOnInputVariablesToHclTerraform(struct?: DataHcpWaypointAddOnInputVariables | cdktn.IResolvable): any;
export declare class DataHcpWaypointAddOnInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpWaypointAddOnInputVariables | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpWaypointAddOnInputVariables | cdktn.IResolvable | undefined);
    get name(): string;
    get value(): string;
    get variableType(): string;
}
export declare class DataHcpWaypointAddOnInputVariablesList extends cdktn.ComplexList {
    internalValue?: DataHcpWaypointAddOnInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpWaypointAddOnInputVariablesOutputReference;
}
export interface DataHcpWaypointAddOnOutputValues {
}
export declare function dataHcpWaypointAddOnOutputValuesToTerraform(struct?: DataHcpWaypointAddOnOutputValues): any;
export declare function dataHcpWaypointAddOnOutputValuesToHclTerraform(struct?: DataHcpWaypointAddOnOutputValues): any;
export declare class DataHcpWaypointAddOnOutputValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpWaypointAddOnOutputValues | undefined;
    set internalValue(value: DataHcpWaypointAddOnOutputValues | undefined);
    get name(): string;
    get sensitive(): cdktn.IResolvable;
    get type(): string;
    get value(): string;
}
export declare class DataHcpWaypointAddOnOutputValuesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpWaypointAddOnOutputValuesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/waypoint_add_on hcp_waypoint_add_on}
*/
export declare class DataHcpWaypointAddOn extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_waypoint_add_on";
    /**
    * Generates CDKTN code for importing a DataHcpWaypointAddOn resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpWaypointAddOn to import
    * @param importFromId The id of the existing DataHcpWaypointAddOn that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/waypoint_add_on#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpWaypointAddOn to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/waypoint_add_on hcp_waypoint_add_on} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpWaypointAddOnConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcpWaypointAddOnConfig);
    get applicationId(): string;
    get createdBy(): string;
    get definitionId(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputVariables;
    get inputVariables(): DataHcpWaypointAddOnInputVariablesList;
    putInputVariables(value: DataHcpWaypointAddOnInputVariables[] | cdktn.IResolvable): void;
    resetInputVariables(): void;
    get inputVariablesInput(): cdktn.IResolvable | DataHcpWaypointAddOnInputVariables[] | undefined;
    get installCount(): number;
    get labels(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _outputValues;
    get outputValues(): DataHcpWaypointAddOnOutputValuesList;
    get projectId(): string;
    get readmeMarkdown(): string;
    get status(): number;
    get summary(): string;
    get terraformNoCodeModuleSource(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
