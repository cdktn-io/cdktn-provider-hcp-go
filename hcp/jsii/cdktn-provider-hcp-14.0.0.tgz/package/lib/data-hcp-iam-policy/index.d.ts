/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpIamPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A binding associates a set of principals to a role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/iam_policy#bindings DataHcpIamPolicy#bindings}
    */
    readonly bindings: DataHcpIamPolicyBindings[] | cdktn.IResolvable;
}
export interface DataHcpIamPolicyBindings {
    /**
    * The set of principals to bind to the given role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/iam_policy#principals DataHcpIamPolicy#principals}
    */
    readonly principals: string[];
    /**
    * The role name to bind to the given principals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/iam_policy#role DataHcpIamPolicy#role}
    */
    readonly role: string;
}
export declare function dataHcpIamPolicyBindingsToTerraform(struct?: DataHcpIamPolicyBindings | cdktn.IResolvable): any;
export declare function dataHcpIamPolicyBindingsToHclTerraform(struct?: DataHcpIamPolicyBindings | cdktn.IResolvable): any;
export declare class DataHcpIamPolicyBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpIamPolicyBindings | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpIamPolicyBindings | cdktn.IResolvable | undefined);
    private _principals?;
    get principals(): string[];
    set principals(value: string[]);
    get principalsInput(): string[] | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
}
export declare class DataHcpIamPolicyBindingsList extends cdktn.ComplexList {
    internalValue?: DataHcpIamPolicyBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpIamPolicyBindingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/iam_policy hcp_iam_policy}
*/
export declare class DataHcpIamPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_iam_policy";
    /**
    * Generates CDKTN code for importing a DataHcpIamPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpIamPolicy to import
    * @param importFromId The id of the existing DataHcpIamPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/iam_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpIamPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/iam_policy hcp_iam_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpIamPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpIamPolicyConfig);
    private _bindings;
    get bindings(): DataHcpIamPolicyBindingsList;
    putBindings(value: DataHcpIamPolicyBindings[] | cdktn.IResolvable): void;
    get bindingsInput(): cdktn.IResolvable | DataHcpIamPolicyBindings[] | undefined;
    get policyData(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
