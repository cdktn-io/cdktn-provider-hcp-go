/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcpHvnRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * The `self_link` of the HashiCorp Virtual Network (HVN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route#hvn_link DataHcpHvnRoute#hvn_link}
    */
    readonly hvnLink: string;
    /**
    * The ID of the HVN route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route#hvn_route_id DataHcpHvnRoute#hvn_route_id}
    */
    readonly hvnRouteId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route#id DataHcpHvnRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the HCP project where the HVN route is located. Always matches the project ID in `hvn_link`. Setting this attribute is deprecated, but it will remain usable in read-only form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route#project_id DataHcpHvnRoute#project_id}
    */
    readonly projectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route#timeouts DataHcpHvnRoute#timeouts}
    */
    readonly timeouts?: DataHcpHvnRouteTimeouts;
}
export interface DataHcpHvnRouteAzureConfig {
}
export declare function dataHcpHvnRouteAzureConfigToTerraform(struct?: DataHcpHvnRouteAzureConfig): any;
export declare function dataHcpHvnRouteAzureConfigToHclTerraform(struct?: DataHcpHvnRouteAzureConfig): any;
export declare class DataHcpHvnRouteAzureConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcpHvnRouteAzureConfig | undefined;
    set internalValue(value: DataHcpHvnRouteAzureConfig | undefined);
    get nextHopIpAddress(): string;
    get nextHopType(): string;
}
export declare class DataHcpHvnRouteAzureConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcpHvnRouteAzureConfigOutputReference;
}
export interface DataHcpHvnRouteTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route#default DataHcpHvnRoute#default}
    */
    readonly default?: string;
}
export declare function dataHcpHvnRouteTimeoutsToTerraform(struct?: DataHcpHvnRouteTimeouts | cdktn.IResolvable): any;
export declare function dataHcpHvnRouteTimeoutsToHclTerraform(struct?: DataHcpHvnRouteTimeouts | cdktn.IResolvable): any;
export declare class DataHcpHvnRouteTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcpHvnRouteTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcpHvnRouteTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route hcp_hvn_route}
*/
export declare class DataHcpHvnRoute extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcp_hvn_route";
    /**
    * Generates CDKTN code for importing a DataHcpHvnRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcpHvnRoute to import
    * @param importFromId The id of the existing DataHcpHvnRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcpHvnRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.115.0/docs/data-sources/hvn_route hcp_hvn_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcpHvnRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataHcpHvnRouteConfig);
    private _azureConfig;
    get azureConfig(): DataHcpHvnRouteAzureConfigList;
    get createdAt(): string;
    get destinationCidr(): string;
    private _hvnLink?;
    get hvnLink(): string;
    set hvnLink(value: string);
    get hvnLinkInput(): string | undefined;
    private _hvnRouteId?;
    get hvnRouteId(): string;
    set hvnRouteId(value: string);
    get hvnRouteIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    get targetLink(): string;
    private _timeouts;
    get timeouts(): DataHcpHvnRouteTimeoutsOutputReference;
    putTimeouts(value: DataHcpHvnRouteTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHcpHvnRouteTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
